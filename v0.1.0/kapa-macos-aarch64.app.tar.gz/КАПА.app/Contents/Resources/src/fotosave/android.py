from __future__ import annotations

import hashlib
import os
import platform
import shutil
import subprocess
import tempfile
import time
from datetime import datetime
from pathlib import Path
from threading import Event
from typing import Callable

from .importer import ImportCancelled, ImportSummary, import_files
from .iphone import (
    HELPER_BINARY,
    IPhoneImportError,
    PROJECT_ROOT,
    command_error,
    ensure_helper,
    native_helper_is_current,
    run_streaming_command,
    run_text_command,
    should_compile_native_helpers,
    summary_text,
)
from .store import ImportStore


ANDROID_MEDIA_EXTENSIONS = {
    ".heic",
    ".heif",
    ".jpg",
    ".jpeg",
    ".png",
    ".dng",
    ".tif",
    ".tiff",
    ".mov",
    ".mp4",
    ".m4v",
}

MTP_HELPER_SOURCE = PROJECT_ROOT / "tools" / "FotoSaveMTPImport.c"
MTP_HELPER_BINARY = PROJECT_ROOT / "bin" / "FotoSaveMTPImport"
WINDOWS_HELPER_SOURCE = PROJECT_ROOT / "tools" / "android_windows_shell.ps1"
MTP_PERMISSION_ERROR_MARKERS = (
    "MTP_OPEN_FAILED",
    "MTP_OPEN_TIMEOUT",
    "failed to open session",
    "Unable to initialize device",
    "libusb_claim_interface",
)


class AndroidImportError(RuntimeError):
    pass


ProgressCallback = Callable[[str], None]


def list_android_files(*, limit: int = 30) -> str:
    if platform.system() == "Windows":
        return list_android_files_windows(limit=limit)
    ensure_macos_android_backend()
    mtp_output = list_android_files_via_mtp(limit=limit)
    if mtp_output is not None:
        return mtp_output

    ptp_output = list_android_files_via_ptp(limit=limit)
    if ptp_output is not None:
        return ptp_output

    raise AndroidImportError(
        android_mtp_error_text("MTP-устройство не открылось, а системный PTP-fallback тоже не увидел Android.")
    )


def import_from_android(
    dest: Path,
    *,
    limit: int | None = None,
    media_filter: str = "all",
    conversion_mode: str = "original",
    progress: ProgressCallback | None = None,
    cancel_event: Event | None = None,
    full_check: bool = False,
) -> tuple[str, ImportSummary]:
    if platform.system() == "Windows":
        return import_from_android_windows(
            dest,
            limit=limit,
            media_filter=media_filter,
            conversion_mode=conversion_mode,
            progress=progress,
            cancel_event=cancel_event,
            full_check=full_check,
        )
    ensure_macos_android_backend()
    try:
        return import_from_android_via_mtp(
            dest,
            limit=limit,
            media_filter=media_filter,
            conversion_mode=conversion_mode,
            progress=progress,
            cancel_event=cancel_event,
        )
    except AndroidImportError as mtp_error:
        ptp_output = list_android_files_via_ptp(limit=1, timeout=8)
        if ptp_output is None:
            raise mtp_error
        if progress:
            progress("MTP не открылся, пробую ограниченный режим Передача фото/PTP...")
        return import_from_android_via_ptp(
            dest,
            limit=limit,
            media_filter=media_filter,
            conversion_mode=conversion_mode,
            progress=progress,
            cancel_event=cancel_event,
        )


def list_android_files_via_mtp(*, limit: int = 30) -> str | None:
    ensure_macos_android_backend()
    try:
        ensure_mtp_helper()
    except AndroidImportError:
        return None
    command = [str(MTP_HELPER_BINARY), "list", "--limit", str(limit)]
    result = run_text_command(command)
    if result.returncode != 0:
        return None
    output = result.stdout.strip()
    if not output or "ERROR:" in output:
        return None
    return output


def import_from_android_via_mtp(
    dest: Path,
    *,
    limit: int | None = None,
    media_filter: str = "all",
    conversion_mode: str = "original",
    progress: ProgressCallback | None = None,
    cancel_event: Event | None = None,
) -> tuple[str, ImportSummary]:
    ensure_macos_android_backend()
    ensure_mtp_helper()
    dest = dest.expanduser().resolve()
    staging = resume_android_staging_folder(dest) or android_staging_folder(dest)
    staging.mkdir(parents=True, exist_ok=True)
    summary = ImportSummary(0, 0, 0, 0, 0, 0)

    with ImportStore(dest) as store:
        session_id = store.create_session(
            source_type="android",
            source_path="Android MTP",
            archive_path=dest,
            staging_path=staging,
        )

    if progress:
        if any(staging.rglob("*")):
            progress(f"Продолжаю с временной папки: {staging}")
        else:
            progress(f"Временная папка: {staging}")
        progress("Ищу Android через Передача файлов / MTP...")

    command = [
        str(MTP_HELPER_BINARY),
        "download",
        "--output",
        str(staging),
    ]
    if limit is not None:
        command.extend(["--limit", str(limit)])
    if media_filter != "all":
        command.extend(["--media", media_filter])

    try:
        result = run_mtp_download_with_permission_retry(command, progress=progress, cancel_event=cancel_event)
        if result.returncode != 0:
            summary = import_partial_android_staging(
                staging,
                dest,
                media_filter=media_filter,
                conversion_mode=conversion_mode,
                session_id=session_id,
            )
            detail = command_error("Не удалось скачать файлы с Android через MTP.", command, result)
            if summary.media_found > 0:
                detail += "\n\nЧастично разложено:\n" + summary_text(summary)
            raise AndroidImportError(android_mtp_error_text(detail))

        if progress:
            progress("Раскладываю скачанные файлы по архиву...")
        _items, summary = import_files(
            staging,
            dest,
            move=True,
            media_filter=media_filter,
            conversion_mode=conversion_mode,
            progress=progress,
            cancel_check=cancel_event.is_set if cancel_event else None,
            source_type="android",
            session_id=session_id,
            staging_path=staging,
            finish_session=False,
        )
        if summary.media_found == 0:
            staging_files = sorted(str(path.relative_to(staging)) for path in staging.rglob("*") if path.is_file())
            sample = "\n".join(staging_files[:30])
            shutil.rmtree(staging, ignore_errors=True)
            detail = result.stdout.strip()
            if sample:
                detail = f"{detail}\n\nФайлы во временной папке:\n{sample}"
            raise AndroidImportError("Файлы с Android скачались, но Мой Архив не нашёл среди них фото/видео.\n" + detail)

        shutil.rmtree(staging, ignore_errors=True)
        with ImportStore(dest) as store:
            store.finish_session(session_id, status="completed", summary=summary, staging_path=staging)
        if progress:
            progress("Временная папка очищена.")
        return result.stdout.strip(), summary
    except ImportCancelled:
        with ImportStore(dest) as store:
            store.finish_session(session_id, status="stopped", summary=summary, error_text="Импорт остановлен пользователем.", staging_path=staging)
        raise
    except Exception as exc:
        with ImportStore(dest) as store:
            store.finish_session(session_id, status="error", summary=summary, error_text=str(exc), staging_path=staging)
        raise


def list_android_files_via_ptp(*, limit: int = 30, timeout: int = 20) -> str | None:
    ensure_macos_android_backend()
    try:
        ensure_helper()
    except IPhoneImportError:
        return None
    result = run_text_command(
        [str(HELPER_BINARY), "list", "--timeout", str(timeout), "--limit", str(limit)],
    )
    if result.returncode != 0:
        return None
    output = result.stdout.strip()
    if not output or "BROWSER_DEVICES: 0" in output:
        return None
    return output


def import_from_android_via_ptp(
    dest: Path,
    *,
    limit: int | None = None,
    media_filter: str = "all",
    conversion_mode: str = "original",
    timeout: int = 600,
    progress: ProgressCallback | None = None,
    cancel_event: Event | None = None,
) -> tuple[str, ImportSummary]:
    ensure_macos_android_backend()
    try:
        ensure_helper()
    except IPhoneImportError as exc:
        raise AndroidImportError(str(exc)) from exc
    dest = dest.expanduser().resolve()
    staging = resume_android_staging_folder(dest) or android_staging_folder(dest)
    staging.mkdir(parents=True, exist_ok=True)
    summary = ImportSummary(0, 0, 0, 0, 0, 0)

    with ImportStore(dest) as store:
        session_id = store.create_session(
            source_type="android",
            source_path="Android PTP",
            archive_path=dest,
            staging_path=staging,
        )

    if progress:
        if any(staging.rglob("*")):
            progress(f"Продолжаю с временной папки: {staging}")
        else:
            progress(f"Временная папка: {staging}")
        progress("Ищу Android через системный импорт фото/PTP...")

    command = [
        str(HELPER_BINARY),
        "download",
        "--output",
        str(staging),
        "--timeout",
        str(timeout),
    ]
    if limit is not None:
        command.extend(["--limit", str(limit)])

    try:
        result = run_streaming_command(command, progress=progress, cancel_event=cancel_event)
        if result.returncode != 0:
            summary = import_partial_android_staging(
                staging,
                dest,
                media_filter=media_filter,
                conversion_mode=conversion_mode,
                session_id=session_id,
            )
            detail = command_error("Не удалось скачать файлы с Android через системный импорт фото/PTP.", command, result)
            if summary.media_found > 0:
                detail += "\n\nЧастично разложено:\n" + summary_text(summary)
            raise AndroidImportError(android_ptp_error_text(detail))

        if progress:
            progress("Раскладываю скачанные файлы по архиву...")
        _items, summary = import_files(
            staging,
            dest,
            move=True,
            media_filter=media_filter,
            conversion_mode=conversion_mode,
            progress=progress,
            cancel_check=cancel_event.is_set if cancel_event else None,
            source_type="android",
            session_id=session_id,
            staging_path=staging,
            finish_session=False,
        )
        if summary.media_found == 0:
            staging_files = sorted(str(path.relative_to(staging)) for path in staging.rglob("*") if path.is_file())
            sample = "\n".join(staging_files[:30])
            shutil.rmtree(staging, ignore_errors=True)
            detail = result.stdout.strip()
            if sample:
                detail = f"{detail}\n\nФайлы во временной папке:\n{sample}"
            raise AndroidImportError("Файлы с Android скачались, но Мой Архив не нашёл среди них фото/видео.\n" + detail)

        shutil.rmtree(staging, ignore_errors=True)
        with ImportStore(dest) as store:
            store.finish_session(session_id, status="completed", summary=summary, staging_path=staging)
        if progress:
            progress("Временная папка очищена.")
        return result.stdout.strip(), summary
    except ImportCancelled as exc:
        with ImportStore(dest) as store:
            store.finish_session(session_id, status="stopped", summary=summary, error_text=str(exc), staging_path=staging)
        raise
    except Exception as exc:
        with ImportStore(dest) as store:
            store.finish_session(session_id, status="error", summary=summary, error_text=str(exc), staging_path=staging)
        raise


def android_ptp_error_text(text: str) -> str:
    return (
        "Android не отдал фото через обычный системный режим macOS.\n\n"
        "На телефоне откройте уведомление USB и выберите «Передача фото / PTP» "
        "или похожий пункт. Экран телефона должен быть разблокирован.\n\n"
        "Режим «Передача файлов / MTP» требует отдельного MTP-backend, который на macOS нужно доделать отдельно.\n\n"
        f"Технические детали:\n{text}"
    )


def android_mtp_error_text(text: str) -> str:
    return (
        "Android не отдал файлы через режим «Передача файлов / MTP».\n\n"
        "На телефоне разблокируйте экран, закройте предупреждение кнопкой «ДА», "
        "откройте USB-уведомление и выберите «Передача файлов / MTP». "
        "После сбоя MTP часто помогает отключить кабель и подключить его снова.\n\n"
        "Для этого пути достаточно обычного USB-режима телефона.\n\n"
        f"Технические детали:\n{text}"
    )


def is_android_mtp_permission_error(text: str) -> bool:
    return any(marker in text for marker in MTP_PERMISSION_ERROR_MARKERS)


def is_xiaomi_mtp_reconnect_error(text: str) -> bool:
    return is_android_mtp_permission_error(text) and (
        "VID=2717" in text or "Xiaomi" in text or "Redmi" in text
    )


def android_gui_retry_message(text: str) -> str:
    if is_xiaomi_mtp_reconnect_error(text):
        return (
            "Телефон Xiaomi/Redmi сейчас не отдаёт файлы повторно.\n\n"
            "Отключите кабель от телефона, подключите его снова, разблокируйте экран "
            "и выберите «Передача файлов / MTP».\n\n"
            "После этого нажмите «Далее», и Мой Архив повторит импорт."
        )

    return (
        "Телефон ждёт подтверждение доступа к файлам.\n\n"
        "Разблокируйте Android и нажмите «ДА» в запросе доступа к данным. "
        "Если запроса нет, откройте USB-уведомление и выберите «Передача файлов / MTP».\n\n"
        "После этого нажмите «Далее», и Мой Архив повторит импорт."
    )


def run_mtp_download_with_permission_retry(
    command: list[str],
    *,
    progress: ProgressCallback | None = None,
    cancel_event: Event | None = None,
) -> subprocess.CompletedProcess[str]:
    result = run_streaming_command(command, progress=progress, cancel_event=cancel_event)
    if result.returncode == 0 or not is_android_mtp_permission_error(result.stdout):
        return result

    if progress:
        progress("Подтвердите доступ к данным на телефоне кнопкой «ДА». Повторю Android MTP через 8 секунд...")

    wait_until = time.monotonic() + 8
    while time.monotonic() < wait_until:
        if cancel_event and cancel_event.is_set():
            raise ImportCancelled("Импорт остановлен пользователем.")
        time.sleep(0.2)

    if progress:
        progress("Повторяю Android MTP после подтверждения доступа...")

    retry_result = run_streaming_command(command, progress=progress, cancel_event=cancel_event)
    if retry_result.returncode != 0:
        retry_result.stdout = result.stdout + "\n--- Повтор после подтверждения доступа ---\n" + retry_result.stdout
    return retry_result


def ensure_mtp_helper() -> None:
    ensure_macos_android_backend()
    if native_helper_is_current(MTP_HELPER_BINARY, MTP_HELPER_SOURCE):
        return

    if not MTP_HELPER_SOURCE.exists():
        raise AndroidImportError(f"Не найден MTP-helper: {MTP_HELPER_SOURCE}")

    if not should_compile_native_helpers():
        raise AndroidImportError(f"Не найден MTP-helper: {MTP_HELPER_BINARY}")

    include_path = Path("/opt/homebrew/include")
    lib_path = Path("/opt/homebrew/lib")
    if not (include_path / "libmtp.h").exists() or not (lib_path / "libmtp.dylib").exists():
        raise AndroidImportError("Не найден libmtp. Установите libmtp через Homebrew: brew install libmtp")

    MTP_HELPER_BINARY.parent.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    result = run_text_command(
        [
            "clang",
            str(MTP_HELPER_SOURCE),
            "-I",
            str(include_path),
            "-L",
            str(lib_path),
            "-lmtp",
            "-o",
            str(MTP_HELPER_BINARY),
        ],
        cwd=PROJECT_ROOT,
        env=env,
    )
    if result.returncode != 0:
        raise AndroidImportError("Не удалось собрать MTP-helper:\n" + result.stdout)


def ensure_macos_android_backend() -> None:
    if platform.system() == "Darwin":
        return
    raise AndroidImportError(
        "Android-импорт на Windows еще не реализован.\n\n"
        "Следующий этап переноса: сделать адаптер android_windows для доступа к MTP/Portable Device без режима разработчика."
    )


def list_android_files_windows(*, limit: int = 30) -> str:
    ensure_windows_android_helper()
    command = windows_android_command("list", limit=limit)
    result = run_text_command(command)
    if result.returncode != 0:
        raise AndroidImportError(result.stdout.strip() or "Не удалось прочитать Android через Windows Shell.")
    return result.stdout.strip()


def import_from_android_windows(
    dest: Path,
    *,
    limit: int | None = None,
    media_filter: str = "all",
    conversion_mode: str = "original",
    progress: ProgressCallback | None = None,
    cancel_event: Event | None = None,
    full_check: bool = False,
) -> tuple[str, ImportSummary]:
    ensure_windows_android_helper()
    dest = dest.expanduser().resolve()
    staging = resume_android_staging_folder(dest) or android_staging_folder(dest)
    staging.mkdir(parents=True, exist_ok=True)
    skip_manifest = None if full_check else staging / ".kapa-known-android.txt"
    summary = ImportSummary(0, 0, 0, 0, 0, 0)

    with ImportStore(dest) as store:
        known_count = 0 if skip_manifest is None else store.write_source_skip_manifest("android", skip_manifest)
        session_id = store.create_session(
            source_type="android_windows",
            source_path="Android MTP",
            archive_path=dest,
            staging_path=staging,
        )

    if progress:
        if folder_has_files(staging):
            progress(f"Продолжаю с временной папки: {staging}")
        else:
            progress(f"Временная папка: {staging}")
        if known_count > 0:
            progress(f"Уже в журнале Android: {known_count} файлов.")
        progress("Ищу Android через Windows MTP...")

    command = windows_android_command(
        "download",
        output=staging,
        limit=limit,
        media_filter=media_filter,
        skip_manifest=skip_manifest,
    )

    try:
        result = run_streaming_command(command, progress=progress, cancel_event=cancel_event)
        if result.returncode != 0:
            summary = import_partial_android_staging(
                staging,
                dest,
                media_filter=media_filter,
                conversion_mode=conversion_mode,
                session_id=session_id,
            )
            detail = command_error("Скачивание с Android через Windows MTP прервалось.", command, result)
            if summary.media_found > 0:
                detail += "\n\nЧастично разложено:\n" + summary_text(summary)
            raise AndroidImportError(detail)

        if progress:
            progress("Раскладываю скачанные файлы по архиву...")
        _items, summary = import_files(
            staging,
            dest,
            move=True,
            media_filter=media_filter,
            conversion_mode=conversion_mode,
            progress=progress,
            cancel_check=cancel_event.is_set if cancel_event else None,
            source_type="android_windows",
            session_id=session_id,
            staging_path=staging,
            finish_session=False,
        )
        if summary.media_found == 0:
            staging_files = sorted(str(path.relative_to(staging)) for path in staging.rglob("*") if path.is_file())
            sample = "\n".join(staging_files[:30])
            shutil.rmtree(staging, ignore_errors=True)
            detail = result.stdout.strip()
            if sample:
                detail = f"{detail}\n\nФайлы во временной папке:\n{sample}"
            raise AndroidImportError("Файлы с Android скачались, но Мой Архив не нашел среди них фото/видео.\n" + detail)

        shutil.rmtree(staging, ignore_errors=True)
        with ImportStore(dest) as store:
            store.finish_session(session_id, status="completed", summary=summary, staging_path=staging)
        if progress:
            progress("Временная папка очищена.")
        return result.stdout.strip(), summary
    except ImportCancelled as exc:
        with ImportStore(dest) as store:
            store.finish_session(session_id, status="stopped", summary=summary, error_text=str(exc), staging_path=staging)
        raise
    except Exception as exc:
        with ImportStore(dest) as store:
            store.finish_session(session_id, status="error", summary=summary, error_text=str(exc), staging_path=staging)
        raise


def ensure_windows_android_helper() -> None:
    if not WINDOWS_HELPER_SOURCE.exists():
        raise AndroidImportError(f"Не найден Windows Android helper: {WINDOWS_HELPER_SOURCE}")


def windows_android_command(
    command: str,
    *,
    output: Path | None = None,
    limit: int | None = None,
    media_filter: str = "all",
    skip_manifest: Path | None = None,
) -> list[str]:
    result = [
        "powershell.exe",
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        str(WINDOWS_HELPER_SOURCE),
        command,
    ]
    if output is not None:
        result.extend(["-Output", str(output)])
    if limit is not None:
        result.extend(["-Limit", str(limit)])
    if media_filter != "all":
        result.extend(["-Media", media_filter])
    if skip_manifest is not None:
        result.extend(["-SkipManifest", str(skip_manifest)])
    return result


def import_partial_android_staging(
    staging: Path,
    dest: Path,
    *,
    media_filter: str = "all",
    conversion_mode: str = "original",
    session_id: int | None = None,
) -> ImportSummary:
    if not staging.exists():
        return ImportSummary(0, 0, 0, 0, 0, 0)
    try:
        _items, summary = import_files(
            staging,
            dest,
            move=True,
            media_filter=media_filter,
            conversion_mode=conversion_mode,
            source_type="android",
            session_id=session_id,
            staging_path=staging,
            finish_session=False,
        )
    except Exception:
        return ImportSummary(0, 0, 0, 0, 0, 0)
    return summary


def is_android_media_path(path: str) -> bool:
    normalized = path.replace("\\", "/")
    if "/Android/data/" in normalized or "/Android/obb/" in normalized:
        return False
    if "/.thumbnails/" in normalized or "/.thumbnail/" in normalized:
        return False
    return Path(path).suffix.lower() in ANDROID_MEDIA_EXTENSIONS


def android_local_path(staging: Path, remote_path: str) -> Path:
    relative = android_relative_path(remote_path)
    return staging / relative


def android_relative_path(remote_path: str) -> Path:
    for prefix in ("/storage/emulated/0/", "/sdcard/"):
        if remote_path.startswith(prefix):
            return Path(remote_path[len(prefix) :])
    return Path(remote_path.lstrip("/"))


def android_staging_folder(dest: Path) -> Path:
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    return android_staging_root() / archive_key(dest) / stamp


def resume_android_staging_folder(dest: Path) -> Path | None:
    root = android_staging_root() / archive_key(dest)
    if not root.exists():
        return None
    folders = [path for path in root.glob("*") if path.is_dir() and folder_has_files(path)]
    if not folders:
        return None
    folders.sort(key=lambda path: path.stat().st_mtime, reverse=True)
    return folders[0]


def folder_has_files(folder: Path) -> bool:
    try:
        return any(path.is_file() and not path.name.startswith(".kapa-known-") for path in folder.rglob("*"))
    except OSError:
        return False


def android_staging_root() -> Path:
    return Path(tempfile.gettempdir()) / "moy-archive" / "android-staging"


def archive_key(dest: Path) -> str:
    return hashlib.sha256(str(dest.expanduser().resolve()).encode("utf-8")).hexdigest()[:16]
