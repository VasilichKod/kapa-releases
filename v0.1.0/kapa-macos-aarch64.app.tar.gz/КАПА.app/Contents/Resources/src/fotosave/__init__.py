"""Мой Архив photo and video importer."""

__version__ = "0.1.0"
