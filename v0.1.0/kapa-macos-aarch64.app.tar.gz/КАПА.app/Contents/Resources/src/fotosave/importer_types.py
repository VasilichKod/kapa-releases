from __future__ import annotations

from typing import Protocol


class ImportSummaryLike(Protocol):
    total_seen: int
    media_found: int
    ignored: int
    new_files: int
    duplicates: int
    imported: int
