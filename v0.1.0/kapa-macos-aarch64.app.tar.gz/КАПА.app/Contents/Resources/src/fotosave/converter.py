from __future__ import annotations

import platform
import shutil
import subprocess
from pathlib import Path


HEIC_EXTENSIONS = {".heic", ".heif"}


def is_heic(path: Path) -> bool:
    return path.suffix.lower() in HEIC_EXTENSIONS


def convert_heic_to_jpeg(path: Path) -> Path | None:
    if not is_heic(path):
        return path
    if platform.system() != "Darwin":
        return None

    destination = unique_jpeg_path(path.with_suffix(".jpg"))
    result = subprocess.run(
        ["sips", "-s", "format", "jpeg", str(path), "--out", str(destination)],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0 or not destination.exists():
        if destination.exists():
            destination.unlink()
        return None

    shutil.copystat(path, destination, follow_symlinks=True)
    path.unlink()
    return destination


def unique_jpeg_path(path: Path) -> Path:
    if not path.exists():
        return path

    parent = path.parent
    stem = path.stem
    index = 1
    while True:
        candidate = parent / f"{stem}_{index}.jpg"
        if not candidate.exists():
            return candidate
        index += 1
