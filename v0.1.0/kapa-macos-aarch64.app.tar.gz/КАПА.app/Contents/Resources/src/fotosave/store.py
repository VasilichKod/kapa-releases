from __future__ import annotations

import sqlite3
import sys
import ctypes
from dataclasses import dataclass
from pathlib import Path

from .importer_types import ImportSummaryLike


@dataclass(frozen=True)
class ImportSession:
    id: int
    started_at: str
    finished_at: str
    source_type: str
    source_path: str
    archive_path: str
    staging_path: str
    status: str
    total_seen: int
    media_found: int
    ignored: int
    new_files: int
    duplicates: int
    imported: int
    error_text: str


@dataclass(frozen=True)
class ImportSessionFile:
    id: int
    session_id: int
    source_path: str
    dest_path: str
    file_name: str
    kind: str
    status: str
    date_taken: str
    date_source: str
    size: int
    sha256: str


class ImportStore:
    def __init__(self, archive_root: Path) -> None:
        self.db_path = archive_root / ".fotosave" / "imports.sqlite3"
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        hide_on_windows(self.db_path.parent)
        self._conn = sqlite3.connect(self.db_path)
        self._conn.row_factory = sqlite3.Row
        self._ensure_schema()

    def _ensure_schema(self) -> None:
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS imported_files (
                fingerprint TEXT PRIMARY KEY,
                source_path TEXT NOT NULL,
                dest_path TEXT NOT NULL,
                size INTEGER NOT NULL,
                sha256 TEXT NOT NULL,
                source_type TEXT NOT NULL DEFAULT '',
                source_key TEXT NOT NULL DEFAULT '',
                imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS imported_source_keys (
                source_type TEXT NOT NULL,
                source_key TEXT NOT NULL,
                fingerprint TEXT NOT NULL,
                source_path TEXT NOT NULL,
                imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (source_type, source_key)
            )
            """
        )
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS import_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                finished_at TEXT NOT NULL DEFAULT '',
                source_type TEXT NOT NULL,
                source_path TEXT NOT NULL DEFAULT '',
                archive_path TEXT NOT NULL,
                staging_path TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT 'running',
                total_seen INTEGER NOT NULL DEFAULT 0,
                media_found INTEGER NOT NULL DEFAULT 0,
                ignored INTEGER NOT NULL DEFAULT 0,
                new_files INTEGER NOT NULL DEFAULT 0,
                duplicates INTEGER NOT NULL DEFAULT 0,
                imported INTEGER NOT NULL DEFAULT 0,
                error_text TEXT NOT NULL DEFAULT ''
            )
            """
        )
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS import_session_files (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER NOT NULL,
                source_path TEXT NOT NULL,
                dest_path TEXT NOT NULL DEFAULT '',
                file_name TEXT NOT NULL,
                kind TEXT NOT NULL,
                status TEXT NOT NULL,
                date_taken TEXT NOT NULL DEFAULT '',
                date_source TEXT NOT NULL DEFAULT '',
                size INTEGER NOT NULL DEFAULT 0,
                sha256 TEXT NOT NULL DEFAULT '',
                FOREIGN KEY(session_id) REFERENCES import_sessions(id)
            )
            """
        )
        self._ensure_imported_files_columns()
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_imported_files_source ON imported_files(source_type, source_key)")
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_imported_source_keys_fingerprint ON imported_source_keys(fingerprint)")
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_import_sessions_started ON import_sessions(started_at DESC)")
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_import_session_files_session ON import_session_files(session_id)")
        self._conn.commit()

    def _ensure_imported_files_columns(self) -> None:
        rows = self._conn.execute("PRAGMA table_info(imported_files)").fetchall()
        existing = {str(row["name"]) for row in rows}
        if "source_type" not in existing:
            self._conn.execute("ALTER TABLE imported_files ADD COLUMN source_type TEXT NOT NULL DEFAULT ''")
        if "source_key" not in existing:
            self._conn.execute("ALTER TABLE imported_files ADD COLUMN source_key TEXT NOT NULL DEFAULT ''")
        self._backfill_source_keys_from_sessions()

    def _backfill_source_keys_from_sessions(self) -> None:
        rows = self._conn.execute(
            """
            SELECT imported_files.fingerprint,
                   imported_files.source_key,
                   import_sessions.source_type,
                   import_sessions.staging_path,
                   import_session_files.source_path,
                   import_session_files.size
            FROM imported_files
            JOIN import_session_files ON import_session_files.sha256 = imported_files.sha256
            JOIN import_sessions ON import_sessions.id = import_session_files.session_id
            WHERE imported_files.source_key = ''
              AND import_sessions.staging_path != ''
              AND import_session_files.status IN ('imported', 'duplicate')
            """
        ).fetchall()

        for row in rows:
            source_type = stable_source_type(str(row["source_type"]))
            if source_type not in {"iphone", "android"}:
                continue
            source_key = source_key_from_staging_path(
                staging_path=str(row["staging_path"]),
                source_path=str(row["source_path"]),
                size=int(row["size"]),
            )
            if not source_key:
                continue
            self._conn.execute(
                """
                UPDATE imported_files
                SET source_type = ?,
                    source_key = ?
                WHERE fingerprint = ? AND source_key = ''
                """,
                (source_type, source_key, str(row["fingerprint"])),
            )
            self._record_source_key(
                source_type=source_type,
                source_key=source_key,
                fingerprint=str(row["fingerprint"]),
                source_path=str(row["source_path"]),
            )

    def close(self) -> None:
        self._conn.close()

    def __enter__(self) -> "ImportStore":
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()

    def has_fingerprint(self, fingerprint: str) -> bool:
        row = self._conn.execute(
            "SELECT 1 FROM imported_files WHERE fingerprint = ? LIMIT 1",
            (fingerprint,),
        ).fetchone()
        return row is not None

    def has_source_key(self, source_type: str, source_key: str) -> bool:
        if not source_type or not source_key:
            return False
        row = self._conn.execute(
            """
            SELECT 1
            FROM imported_source_keys
            WHERE source_type = ? AND source_key = ?
            LIMIT 1
            """,
            (source_type, source_key),
        ).fetchone()
        if row is not None:
            return True

        row = self._conn.execute(
            """
            SELECT 1
            FROM imported_files
            WHERE source_type = ? AND source_key = ?
            LIMIT 1
            """,
            (source_type, source_key),
        ).fetchone()
        return row is not None

    def known_source_keys(self, source_type: str) -> set[str]:
        if not source_type:
            return set()
        source_rows = self._conn.execute(
            """
            SELECT source_key
            FROM imported_source_keys
            WHERE source_type = ? AND source_key != ''
            """,
            (source_type,),
        ).fetchall()
        file_rows = self._conn.execute(
            """
            SELECT source_key
            FROM imported_files
            WHERE source_type = ? AND source_key != ''
            """,
            (source_type,),
        ).fetchall()
        return {str(row["source_key"]) for row in source_rows + file_rows}

    def record(
        self,
        *,
        fingerprint: str,
        source_path: Path,
        dest_path: Path,
        size: int,
        sha256: str,
        source_type: str = "",
        source_key: str = "",
    ) -> None:
        self._conn.execute(
            """
            INSERT OR REPLACE INTO imported_files
                (fingerprint, source_path, dest_path, size, sha256, source_type, source_key)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (fingerprint, str(source_path), str(dest_path), size, sha256, source_type, source_key),
        )
        self._record_source_key(
            source_type=source_type,
            source_key=source_key,
            fingerprint=fingerprint,
            source_path=str(source_path),
        )
        self._conn.commit()

    def attach_source_key(
        self,
        *,
        fingerprint: str,
        source_type: str,
        source_key: str,
        source_path: Path | str,
    ) -> None:
        if not source_type or not source_key:
            return
        self._record_source_key(
            source_type=source_type,
            source_key=source_key,
            fingerprint=fingerprint,
            source_path=str(source_path),
        )
        self._conn.execute(
            """
            UPDATE imported_files
            SET source_type = ?,
                source_key = ?,
                source_path = ?
            WHERE fingerprint = ? AND (source_type = '' OR source_key = '')
            """,
            (source_type, source_key, str(source_path), fingerprint),
        )
        self._conn.commit()

    def _record_source_key(
        self,
        *,
        source_type: str,
        source_key: str,
        fingerprint: str,
        source_path: str,
    ) -> None:
        if not source_type or not source_key:
            return
        self._conn.execute(
            """
            INSERT OR REPLACE INTO imported_source_keys
                (source_type, source_key, fingerprint, source_path)
            VALUES (?, ?, ?, ?)
            """,
            (source_type, source_key, fingerprint, source_path),
        )

    def write_source_skip_manifest(self, source_type: str, path: Path) -> int:
        keys = sorted(self.known_source_keys(source_type))
        manifest_lines: list[str] = []
        for key in keys:
            manifest_lines.append(key)
            source_path, separator, _size = key.rpartition("|")
            if separator and source_path:
                manifest_lines.append(f"{source_path}|0")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("\n".join(manifest_lines), encoding="utf-8")
        return len(keys)

    def create_session(
        self,
        *,
        source_type: str,
        source_path: Path | str,
        archive_path: Path | str,
        staging_path: Path | str = "",
    ) -> int:
        cursor = self._conn.execute(
            """
            INSERT INTO import_sessions
                (source_type, source_path, archive_path, staging_path)
            VALUES (?, ?, ?, ?)
            """,
            (source_type, str(source_path), str(archive_path), str(staging_path)),
        )
        self._conn.commit()
        return int(cursor.lastrowid)

    def finish_session(
        self,
        session_id: int,
        *,
        status: str,
        summary: ImportSummaryLike | None = None,
        error_text: str = "",
        staging_path: Path | str | None = None,
    ) -> None:
        values = {
            "total_seen": 0,
            "media_found": 0,
            "ignored": 0,
            "new_files": 0,
            "duplicates": 0,
            "imported": 0,
        }
        if summary is not None:
            for key in values:
                values[key] = int(getattr(summary, key, 0))

        if staging_path is None:
            self._conn.execute(
                """
                UPDATE import_sessions
                SET finished_at = CURRENT_TIMESTAMP,
                    status = ?,
                    total_seen = ?,
                    media_found = ?,
                    ignored = ?,
                    new_files = ?,
                    duplicates = ?,
                    imported = ?,
                    error_text = ?
                WHERE id = ?
                """,
                (
                    status,
                    values["total_seen"],
                    values["media_found"],
                    values["ignored"],
                    values["new_files"],
                    values["duplicates"],
                    values["imported"],
                    error_text,
                    session_id,
                ),
            )
        else:
            self._conn.execute(
                """
                UPDATE import_sessions
                SET finished_at = CURRENT_TIMESTAMP,
                    status = ?,
                    total_seen = ?,
                    media_found = ?,
                    ignored = ?,
                    new_files = ?,
                    duplicates = ?,
                    imported = ?,
                    error_text = ?,
                    staging_path = ?
                WHERE id = ?
                """,
                (
                    status,
                    values["total_seen"],
                    values["media_found"],
                    values["ignored"],
                    values["new_files"],
                    values["duplicates"],
                    values["imported"],
                    error_text,
                    str(staging_path),
                    session_id,
                ),
            )
        self._conn.commit()

    def record_session_file(
        self,
        *,
        session_id: int,
        source_path: Path | str,
        dest_path: Path | str,
        file_name: str,
        kind: str,
        status: str,
        date_taken: str,
        date_source: str,
        size: int,
        sha256: str,
    ) -> None:
        self._conn.execute(
            """
            INSERT INTO import_session_files
                (session_id, source_path, dest_path, file_name, kind, status, date_taken, date_source, size, sha256)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                session_id,
                str(source_path),
                str(dest_path),
                file_name,
                kind,
                status,
                date_taken,
                date_source,
                size,
                sha256,
            ),
        )
        self._conn.commit()

    def list_sessions(self, *, limit: int = 50) -> list[ImportSession]:
        rows = self._conn.execute(
            """
            SELECT *
            FROM import_sessions
            ORDER BY started_at DESC, id DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
        return [session_from_row(row) for row in rows]

    def list_session_files(self, session_id: int, *, limit: int = 500) -> list[ImportSessionFile]:
        rows = self._conn.execute(
            """
            SELECT *
            FROM import_session_files
            WHERE session_id = ?
            ORDER BY id ASC
            LIMIT ?
            """,
            (session_id, limit),
        ).fetchall()
        return [session_file_from_row(row) for row in rows]


def session_from_row(row: sqlite3.Row) -> ImportSession:
    return ImportSession(
        id=int(row["id"]),
        started_at=str(row["started_at"]),
        finished_at=str(row["finished_at"]),
        source_type=str(row["source_type"]),
        source_path=str(row["source_path"]),
        archive_path=str(row["archive_path"]),
        staging_path=str(row["staging_path"]),
        status=str(row["status"]),
        total_seen=int(row["total_seen"]),
        media_found=int(row["media_found"]),
        ignored=int(row["ignored"]),
        new_files=int(row["new_files"]),
        duplicates=int(row["duplicates"]),
        imported=int(row["imported"]),
        error_text=str(row["error_text"]),
    )


def session_file_from_row(row: sqlite3.Row) -> ImportSessionFile:
    return ImportSessionFile(
        id=int(row["id"]),
        session_id=int(row["session_id"]),
        source_path=str(row["source_path"]),
        dest_path=str(row["dest_path"]),
        file_name=str(row["file_name"]),
        kind=str(row["kind"]),
        status=str(row["status"]),
        date_taken=str(row["date_taken"]),
        date_source=str(row["date_source"]),
        size=int(row["size"]),
        sha256=str(row["sha256"]),
    )


def hide_on_windows(path: Path) -> None:
    if sys.platform != "win32":
        return

    try:
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        current = kernel32.GetFileAttributesW(str(path))
        if current == 0xFFFFFFFF:
            return
        kernel32.SetFileAttributesW(str(path), ctypes.c_uint32(current | 0x2))
    except OSError:
        return


def stable_source_type(source_type: str) -> str:
    if source_type.startswith("iphone"):
        return "iphone"
    if source_type.startswith("android"):
        return "android"
    return source_type


def source_key_from_staging_path(*, staging_path: str, source_path: str, size: int) -> str:
    try:
        relative = Path(source_path).resolve().relative_to(Path(staging_path).resolve()).as_posix()
    except (OSError, ValueError):
        return ""
    normalized = relative.replace("\\", "/").strip("/")
    if not normalized:
        return ""
    return f"/{normalized.lower()}|{max(int(size), 0)}"
