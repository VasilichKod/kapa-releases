from __future__ import annotations

import queue
import re
import shutil
import subprocess
import threading
import time
import tkinter as tk
from datetime import datetime
from pathlib import Path
from threading import Event
from tkinter import filedialog, ttk

from .android import (
    android_gui_retry_message,
    android_staging_root,
    import_from_android,
    is_android_mtp_permission_error,
)
from .importer import ImportCancelled, import_files
from .iphone import import_from_iphone, iphone_staging_root, is_usbmuxd_error, repair_iphone_connection
from .store import ImportStore


APP_NAME = "Мой Архив"


class FotoSaveApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_NAME)
        self.geometry("1080x700")
        self.minsize(900, 600)

        self.source_var = tk.StringVar()
        self.source_mode_var = tk.StringVar(value="folder")
        self.media_all_var = tk.BooleanVar(value=True)
        self.media_photo_var = tk.BooleanVar(value=False)
        self.media_video_var = tk.BooleanVar(value=False)
        self.dest_var = tk.StringVar()
        self.move_var = tk.BooleanVar(value=False)
        self.status_var = tk.StringVar(value="Готово")
        self.progress_var = tk.StringVar(value="")
        self.stage_var = tk.StringVar(value="Ожидание")
        self.downloaded_var = tk.StringVar(value="0")
        self.skipped_existing_var = tk.StringVar(value="0")
        self.archive_files_var = tk.StringVar(value="0/0")
        self.archive_size_var = tk.StringVar(value="0 Б из 0 Б")
        self.archive_speed_var = tk.StringVar(value="—")
        self.archive_eta_var = tk.StringVar(value="—")
        self.iphone_downloaded_count = 0
        self.iphone_skipped_existing_count = 0
        self.iphone_total_files = 0
        self.iphone_total_bytes = 0
        self.iphone_downloaded_bytes = 0
        self.iphone_skipped_existing_bytes = 0
        self.iphone_active_bytes = 0
        self.iphone_active_file_size = 0
        self.progress_started_at = time.monotonic()
        self.events: queue.Queue[tuple[str, object]] = queue.Queue()
        self.cancel_event: Event | None = None

        self._build_layout()
        self.after(100, self._poll_events)

    def _build_layout(self) -> None:
        root = ttk.Frame(self, padding=16)
        root.pack(fill=tk.BOTH, expand=True)
        root.columnconfigure(2, weight=1)
        root.rowconfigure(7, weight=1)

        ttk.Label(root, text="Откуда").grid(row=0, column=0, sticky="w", padx=(0, 18), pady=(0, 10))

        ttk.Radiobutton(
            root,
            text="Папка",
            variable=self.source_mode_var,
            value="folder",
            command=self._update_source_mode,
        ).grid(row=0, column=1, sticky="w", padx=(0, 18), pady=(0, 10))
        self.source_entry = ttk.Entry(root, textvariable=self.source_var)
        self.source_entry.grid(row=0, column=2, sticky="ew", pady=(0, 10))
        self.choose_source_button = ttk.Button(root, text="Выбрать папку", command=self._choose_source)
        self.choose_source_button.grid(row=0, column=3, padx=(10, 0), pady=(0, 10))

        ttk.Radiobutton(
            root,
            text="iPhone",
            variable=self.source_mode_var,
            value="iphone",
            command=self._update_source_mode,
        ).grid(row=1, column=1, sticky="w", padx=(0, 18), pady=(0, 16))
        ttk.Radiobutton(
            root,
            text="Android",
            variable=self.source_mode_var,
            value="android",
            command=self._update_source_mode,
        ).grid(row=1, column=2, sticky="w", pady=(0, 16))

        ttk.Label(root, text="Архив").grid(row=2, column=0, sticky="w", padx=(0, 18), pady=(0, 10))
        ttk.Entry(root, textvariable=self.dest_var).grid(row=2, column=2, sticky="ew", pady=(0, 10))
        ttk.Button(root, text="Выбрать", command=self._choose_dest).grid(row=2, column=3, padx=(10, 0), pady=(0, 10))

        options = ttk.Frame(root)
        options.grid(row=3, column=0, columnspan=4, sticky="ew", pady=(0, 12))
        self.move_check = ttk.Checkbutton(options, text="Перемещать, а не копировать", variable=self.move_var)
        self.move_check.pack(side=tk.LEFT)
        ttk.Label(options, text="Импортировать").pack(side=tk.LEFT, padx=(24, 8))
        self.media_all_check = ttk.Checkbutton(
            options,
            text="Все",
            variable=self.media_all_var,
            command=self._media_all_changed,
        )
        self.media_all_check.pack(side=tk.LEFT)
        self.media_photo_check = ttk.Checkbutton(
            options,
            text="Фото",
            variable=self.media_photo_var,
            command=self._media_specific_changed,
        )
        self.media_photo_check.pack(side=tk.LEFT, padx=(12, 0))
        self.media_video_check = ttk.Checkbutton(
            options,
            text="Видео",
            variable=self.media_video_var,
            command=self._media_specific_changed,
        )
        self.media_video_check.pack(side=tk.LEFT, padx=(12, 0))

        actions = ttk.Frame(root)
        actions.grid(row=4, column=0, columnspan=4, sticky="ew", pady=(0, 12))
        self.import_button = ttk.Button(actions, text="Импортировать", command=self._import)
        self.import_button.pack(side=tk.LEFT)
        self.stop_button = ttk.Button(actions, text="Остановить", command=self._stop_import, state=tk.DISABLED)
        self.stop_button.pack(side=tk.LEFT, padx=(8, 0))
        ttk.Label(actions, textvariable=self.status_var).pack(side=tk.RIGHT)

        self._build_progress_panel(root)

        ttk.Separator(root).grid(row=6, column=0, columnspan=4, sticky="ew", pady=(0, 12))

        self.notebook = ttk.Notebook(root)
        self.notebook.grid(row=7, column=0, columnspan=4, sticky="nsew")

        log_tab = ttk.Frame(self.notebook, padding=6)
        log_tab.rowconfigure(0, weight=1)
        log_tab.columnconfigure(0, weight=1)
        self.output = tk.Text(log_tab, wrap=tk.NONE, height=18)
        self.output.grid(row=0, column=0, sticky="nsew")
        y_scroll = ttk.Scrollbar(log_tab, orient=tk.VERTICAL, command=self.output.yview)
        y_scroll.grid(row=0, column=1, sticky="ns")
        self.output.configure(yscrollcommand=y_scroll.set)
        self.notebook.add(log_tab, text="Импорт")

        self._build_history_tab()
        self._build_temp_tab()
        self._update_source_mode()
        self._refresh_history()
        self._refresh_temp_files()

    def _build_progress_panel(self, root: ttk.Frame) -> None:
        panel = ttk.LabelFrame(root, text="Ход импорта", padding=10)
        panel.grid(row=5, column=0, columnspan=4, sticky="ew", pady=(0, 12))
        panel.columnconfigure(1, weight=1)
        panel.columnconfigure(3, weight=1)
        panel.columnconfigure(5, weight=1)

        ttk.Label(panel, text="Этап").grid(row=0, column=0, sticky="w", padx=(0, 8), pady=(0, 6))
        ttk.Label(panel, textvariable=self.stage_var).grid(row=0, column=1, columnspan=5, sticky="ew", pady=(0, 6))

        self.progress_bar = ttk.Progressbar(panel, mode="determinate", maximum=100)
        self.progress_bar.grid(row=1, column=0, columnspan=6, sticky="ew", pady=(0, 8))

        ttk.Label(panel, text="Скачано").grid(row=2, column=0, sticky="w", padx=(0, 8))
        ttk.Label(panel, textvariable=self.downloaded_var).grid(row=2, column=1, sticky="w")
        ttk.Label(panel, text="Уже во временной").grid(row=2, column=2, sticky="w", padx=(16, 8))
        ttk.Label(panel, textvariable=self.skipped_existing_var).grid(row=2, column=3, sticky="w")
        ttk.Label(panel, text="Файлы").grid(row=2, column=4, sticky="w", padx=(16, 8))
        ttk.Label(panel, textvariable=self.archive_files_var).grid(row=2, column=5, sticky="w")

        ttk.Label(panel, text="Объём").grid(row=3, column=0, sticky="w", padx=(0, 8), pady=(6, 0))
        ttk.Label(panel, textvariable=self.archive_size_var).grid(row=3, column=1, sticky="w", pady=(6, 0))
        ttk.Label(panel, text="Скорость").grid(row=3, column=2, sticky="w", padx=(16, 8), pady=(6, 0))
        ttk.Label(panel, textvariable=self.archive_speed_var).grid(row=3, column=3, sticky="w", pady=(6, 0))
        ttk.Label(panel, text="Осталось").grid(row=3, column=4, sticky="w", padx=(16, 8), pady=(6, 0))
        ttk.Label(panel, textvariable=self.archive_eta_var).grid(row=3, column=5, sticky="w", pady=(6, 0))

    def _build_history_tab(self) -> None:
        history_tab = ttk.Frame(self.notebook, padding=6)
        history_tab.rowconfigure(1, weight=1)
        history_tab.rowconfigure(3, weight=1)
        history_tab.columnconfigure(0, weight=1)

        history_actions = ttk.Frame(history_tab)
        history_actions.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        ttk.Button(history_actions, text="Обновить историю", command=self._refresh_history).pack(side=tk.LEFT)

        session_columns = ("started", "source", "status", "imported", "new_files", "duplicates", "archive")
        self.history_tree = ttk.Treeview(history_tab, columns=session_columns, show="headings", height=8)
        headings = {
            "started": "Дата",
            "source": "Источник",
            "status": "Статус",
            "imported": "Импорт",
            "new_files": "Новых",
            "duplicates": "Дубли",
            "archive": "Архив",
        }
        widths = {
            "started": 150,
            "source": 90,
            "status": 110,
            "imported": 80,
            "new_files": 80,
            "duplicates": 80,
            "archive": 360,
        }
        for column in session_columns:
            self.history_tree.heading(column, text=headings[column])
            self.history_tree.column(column, width=widths[column], anchor=tk.W)
        self.history_tree.grid(row=1, column=0, sticky="nsew")
        self.history_tree.bind("<<TreeviewSelect>>", self._history_selected)
        history_scroll = ttk.Scrollbar(history_tab, orient=tk.VERTICAL, command=self.history_tree.yview)
        history_scroll.grid(row=1, column=1, sticky="ns")
        self.history_tree.configure(yscrollcommand=history_scroll.set)

        ttk.Label(history_tab, text="Файлы выбранного импорта").grid(row=2, column=0, sticky="w", pady=(10, 6))
        file_columns = ("status", "kind", "date", "date_source", "file", "dest")
        self.history_files_tree = ttk.Treeview(history_tab, columns=file_columns, show="headings", height=8)
        file_headings = {
            "status": "Статус",
            "kind": "Тип",
            "date": "Дата",
            "date_source": "Источник даты",
            "file": "Файл",
            "dest": "Куда",
        }
        file_widths = {
            "status": 100,
            "kind": 70,
            "date": 150,
            "date_source": 130,
            "file": 180,
            "dest": 420,
        }
        for column in file_columns:
            self.history_files_tree.heading(column, text=file_headings[column])
            self.history_files_tree.column(column, width=file_widths[column], anchor=tk.W)
        self.history_files_tree.grid(row=3, column=0, sticky="nsew")
        files_scroll = ttk.Scrollbar(history_tab, orient=tk.VERTICAL, command=self.history_files_tree.yview)
        files_scroll.grid(row=3, column=1, sticky="ns")
        self.history_files_tree.configure(yscrollcommand=files_scroll.set)

        self.notebook.add(history_tab, text="История")

    def _build_temp_tab(self) -> None:
        temp_tab = ttk.Frame(self.notebook, padding=6)
        temp_tab.rowconfigure(1, weight=1)
        temp_tab.columnconfigure(0, weight=1)

        temp_actions = ttk.Frame(temp_tab)
        temp_actions.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        ttk.Button(temp_actions, text="Обновить", command=self._refresh_temp_files).pack(side=tk.LEFT)
        ttk.Button(temp_actions, text="Открыть папку", command=self._open_selected_temp).pack(side=tk.LEFT, padx=(8, 0))
        ttk.Button(temp_actions, text="Очистить выбранное", command=self._clear_selected_temp).pack(side=tk.LEFT, padx=(8, 0))
        ttk.Button(temp_actions, text="Очистить всё", command=self._clear_all_temp).pack(side=tk.LEFT, padx=(8, 0))

        temp_columns = ("modified", "size", "path")
        self.temp_tree = ttk.Treeview(temp_tab, columns=temp_columns, show="headings", height=16)
        temp_headings = {
            "modified": "Изменено",
            "size": "Размер",
            "path": "Временная папка",
        }
        temp_widths = {
            "modified": 160,
            "size": 100,
            "path": 760,
        }
        for column in temp_columns:
            self.temp_tree.heading(column, text=temp_headings[column])
            self.temp_tree.column(column, width=temp_widths[column], anchor=tk.W)
        self.temp_tree.grid(row=1, column=0, sticky="nsew")
        temp_scroll = ttk.Scrollbar(temp_tab, orient=tk.VERTICAL, command=self.temp_tree.yview)
        temp_scroll.grid(row=1, column=1, sticky="ns")
        self.temp_tree.configure(yscrollcommand=temp_scroll.set)

        self.notebook.add(temp_tab, text="Временные файлы")

    def _choose_source(self) -> None:
        selected = filedialog.askdirectory(title="Выберите папку с фото и видео")
        if selected:
            self.source_mode_var.set("folder")
            self.source_var.set(selected)
            self._update_source_mode()

    def _update_source_mode(self) -> None:
        if self.source_mode_var.get() in {"iphone", "android"}:
            self.source_entry.configure(state=tk.DISABLED)
            self.choose_source_button.configure(state=tk.DISABLED)
            self.move_check.configure(state=tk.DISABLED)
            return

        self.source_entry.configure(state=tk.NORMAL)
        self.choose_source_button.configure(state=tk.NORMAL)
        self.move_check.configure(state=tk.NORMAL)

    def _choose_dest(self) -> None:
        selected = filedialog.askdirectory(title="Выберите папку архива")
        if selected:
            self.dest_var.set(selected)
            self._refresh_history()

    def _import(self) -> None:
        if self.source_mode_var.get() == "iphone":
            self._import_iphone()
            return
        if self.source_mode_var.get() == "android":
            self._import_android()
            return
        self._run_background("Импортирую...", self._import_worker)

    def _import_iphone(self) -> None:
        if not self.dest_var.get().strip():
            self._show_message(APP_NAME, "Выберите папку архива.")
            return
        self._run_background("Импортирую с iPhone...", self._import_iphone_worker, needs_source=False)

    def _import_android(self) -> None:
        if not self.dest_var.get().strip():
            self._show_message(APP_NAME, "Выберите папку архива.")
            return
        self._run_background("Импортирую с Android...", self._import_android_worker, needs_source=False)

    def _stop_import(self) -> None:
        if self.cancel_event:
            self.cancel_event.set()
        self.status_var.set("Останавливаю...")
        self.stop_button.configure(state=tk.DISABLED)
        self._append_output("Остановка запрошена. Жду завершения текущей операции...")

    def _repair_iphone(self) -> None:
        confirmed = self._ask_confirmation(
            APP_NAME,
            "Восстановить подключение iPhone?\n\n"
            "macOS попросит пароль администратора. Это нужно только для перезапуска службы, "
            "которая отвечает за USB-подключение iPhone.",
            confirm_text="Далее",
        )
        if not confirmed:
            return
        self._run_background(
            "Восстанавливаю iPhone...",
            self._repair_iphone_worker,
            needs_source=False,
            needs_dest=False,
        )

    def _run_background(
        self,
        label: str,
        worker: callable,
        *,
        needs_source: bool = True,
        needs_dest: bool = True,
    ) -> None:
        source, dest = self._validated_paths(needs_source=needs_source, needs_dest=needs_dest)
        if source is None or dest is None:
            return

        self.cancel_event = Event()
        self.status_var.set(label)
        self._reset_progress_panel(label)
        self.output.delete("1.0", tk.END)
        self._append_output(label)
        self._set_buttons_state(tk.DISABLED)
        self.stop_button.configure(state=tk.NORMAL)
        thread = threading.Thread(target=worker, args=(source, dest), daemon=True)
        thread.start()

    def _import_worker(self, source: Path, dest: Path) -> None:
        try:
            items, summary = import_files(
                source,
                dest,
                move=self.move_var.get(),
                media_filter=self._selected_media_filter(),
                progress=self._worker_log,
                cancel_check=self._is_cancelled,
            )
            self.events.put(("result", ("Импорт завершён", items, summary)))
        except ImportCancelled as exc:
            self.events.put(("cancelled", str(exc)))
        except Exception as exc:
            self.events.put(("error", exc))

    def _import_iphone_worker(self, _source: Path, dest: Path) -> None:
        try:
            helper_output, summary = import_from_iphone(
                dest,
                media_filter=self._selected_media_filter(),
                progress=self._worker_log,
                cancel_event=self.cancel_event,
            )
            self.events.put(("device_import", ("Импорт с iPhone завершён", helper_output, summary)))
        except ImportCancelled as exc:
            self.events.put(("cancelled", str(exc)))
        except Exception as exc:
            self.events.put(("error", exc))

    def _import_android_worker(self, _source: Path, dest: Path) -> None:
        try:
            helper_output, summary = import_from_android(
                dest,
                media_filter=self._selected_media_filter(),
                progress=self._worker_log,
                cancel_event=self.cancel_event,
            )
            self.events.put(("device_import", ("Импорт с Android завершён", helper_output, summary)))
        except ImportCancelled as exc:
            self.events.put(("cancelled", str(exc)))
        except Exception as exc:
            self.events.put(("error", exc))

    def _repair_iphone_worker(self, _source: Path, _dest: Path) -> None:
        try:
            output = repair_iphone_connection()
            self.events.put(("text", ("Подключение iPhone восстановлено", output)))
        except Exception as exc:
            self.events.put(("error", exc))

    def _worker_log(self, message: str) -> None:
        if message:
            self.events.put(("log", message))

    def _is_cancelled(self) -> bool:
        return bool(self.cancel_event and self.cancel_event.is_set())

    def _selected_media_filter(self) -> str:
        if self.media_all_var.get():
            return "all"
        photo = self.media_photo_var.get()
        video = self.media_video_var.get()
        if photo and not video:
            return "photo"
        if video and not photo:
            return "video"
        return "all"

    def _media_all_changed(self) -> None:
        if self.media_all_var.get():
            self.media_photo_var.set(False)
            self.media_video_var.set(False)
            return
        if not self.media_photo_var.get() and not self.media_video_var.get():
            self.media_all_var.set(True)

    def _media_specific_changed(self) -> None:
        if self.media_photo_var.get() or self.media_video_var.get():
            self.media_all_var.set(False)
            return
        self.media_all_var.set(True)

    def _validated_paths(self, *, needs_source: bool, needs_dest: bool) -> tuple[Path | None, Path | None]:
        source_text = self.source_var.get().strip()
        dest_text = self.dest_var.get().strip()
        source = Path(source_text).expanduser() if source_text else Path()
        dest = Path(dest_text).expanduser() if dest_text else Path()

        if needs_source and (not source_text or not source.is_dir()):
            self._show_message(APP_NAME, "Выберите существующую папку с фото и видео.")
            return None, None
        if needs_dest and not dest_text:
            self._show_message(APP_NAME, "Выберите папку архива.")
            return None, None
        return source, dest

    def _poll_events(self) -> None:
        try:
            while True:
                kind, payload = self.events.get_nowait()
                if kind == "result":
                    title, items, summary = payload
                    self._show_result(title, items, summary)
                    self._finish_background()
                elif kind == "text":
                    title, output = payload
                    self._show_text(title, output)
                    self._finish_background()
                elif kind == "device_import":
                    title, helper_output, summary = payload
                    self._show_device_import_result(title, helper_output, summary)
                    self._finish_background()
                elif kind == "log":
                    self._append_output(str(payload))
                elif kind == "cancelled":
                    self._append_output(str(payload))
                    self._finish_background()
                elif kind == "error":
                    self._finish_background()
                    self._show_error(payload)
        except queue.Empty:
            pass

        self.after(100, self._poll_events)

    def _finish_background(self) -> None:
        self.status_var.set("Готово")
        self.cancel_event = None
        self._set_buttons_state(tk.NORMAL)
        self._update_source_mode()
        self.stop_button.configure(state=tk.DISABLED)
        self._refresh_history()
        self._refresh_temp_files()

    def _show_error(self, error: object) -> None:
        message = str(error)
        if self.source_mode_var.get() == "android" and is_android_mtp_permission_error(message):
            should_retry = self._ask_confirmation(
                APP_NAME,
                android_gui_retry_message(message),
                confirm_text="Далее",
            )
            if should_retry:
                self._run_background("Импортирую с Android...", self._import_android_worker, needs_source=False)
            return

        if not is_usbmuxd_error(message):
            self._show_message(APP_NAME, self._human_error_message(message))
            return

        should_repair = self._ask_confirmation(
            APP_NAME,
            (
                "Mac временно потерял подключение к iPhone.\n\n"
                "Нажмите «Далее», введите пароль администратора, затем отключите и снова "
                "подключите iPhone. После этого разблокируйте iPhone и повторите импорт."
            ),
            confirm_text="Далее",
        )
        if should_repair:
            self._run_background(
                "Восстанавливаю iPhone...",
                self._repair_iphone_worker,
                needs_source=False,
                needs_dest=False,
            )

    def _human_error_message(self, message: str) -> str:
        if "Файлы с Android скачались, но Мой Архив не нашёл среди них фото/видео" in message:
            return (
                "Файлы с Android скачались, но среди них нет подходящих фото или видео.\n\n"
                "Проверьте выбранный фильтр: «Все», «Фото» или «Видео». "
                "Если выбран режим «Фото», видео будут пропущены, и наоборот."
            )
        if "Файлы с iPhone скачались, но Мой Архив не нашёл среди них фото/видео" in message:
            return (
                "Файлы с iPhone скачались, но среди них нет подходящих фото или видео.\n\n"
                "Проверьте выбранный фильтр: «Все», «Фото» или «Видео»."
            )
        if "No space left" in message or "Недостаточно места" in message:
            return "На диске недостаточно свободного места. Освободите место или выберите другую папку архива."
        if "Permission denied" in message or "Operation not permitted" in message:
            return (
                "Нет доступа к выбранной папке.\n\n"
                "Выберите другую папку архива или разрешите доступ к этой папке в настройках macOS."
            )
        if "Не найден libmtp" in message:
            return (
                "На Mac не найден компонент для импорта Android.\n\n"
                "Сообщите разработчику: нужно установить libmtp через Homebrew."
            )
        if "Не удалось собрать MTP-helper" in message or "Не удалось собрать AFC-helper" in message or "Не удалось собрать iPhone-helper" in message:
            return (
                "Не удалось подготовить служебный модуль импорта.\n\n"
                "Перезапустите приложение. Если ошибка повторится, сообщите разработчику."
            )
        if "Не найден MTP-helper" in message or "Не найден AFC-helper" in message or "Не найден Swift-helper" in message:
            return (
                "В приложении не найден служебный файл импорта.\n\n"
                "Проверьте, что проект открыт полностью, или сообщите разработчику."
            )
        if "Не удалось скачать файлы с iPhone" in message:
            return (
                "iPhone не отдал файлы.\n\n"
                "Разблокируйте iPhone, подтвердите доверие к этому Mac, если появится запрос, "
                "и повторите импорт."
            )
        if "Не удалось скачать файлы с Android" in message or "Android не отдал" in message:
            return (
                "Android не отдал файлы.\n\n"
                "Разблокируйте телефон, выберите «Передача файлов / MTP» в USB-уведомлении "
                "и повторите импорт."
            )
        if "Unknown media_filter" in message:
            return "Некорректный выбор типа импорта. Выберите «Все», «Фото» или «Видео»."

        short = message
        for marker in ("\n\nТехнические детали:", "\nТехнические детали:", "\nКод:", "\nКоманда:"):
            if marker in short:
                short = short.split(marker, 1)[0]
        short = short.strip()
        if len(short) > 700:
            return (
                "Импорт остановился с ошибкой.\n\n"
                "Попробуйте повторить импорт. Подробности сохранены в логе вкладки «Импорт»."
            )
        return short or "Импорт остановился с ошибкой. Попробуйте повторить импорт."

    def _show_message(self, title: str, message: str) -> None:
        dialog = tk.Toplevel(self)
        dialog.title(title)
        dialog.transient(self)
        dialog.resizable(False, False)
        dialog.grab_set()

        frame = ttk.Frame(dialog, padding=18)
        frame.pack(fill=tk.BOTH, expand=True)
        ttk.Label(frame, text=message, wraplength=520, justify=tk.LEFT).pack(anchor="w")
        buttons = ttk.Frame(frame)
        buttons.pack(fill=tk.X, pady=(18, 0))
        ttk.Button(buttons, text="Закрыть", command=dialog.destroy).pack(side=tk.RIGHT)

        self._center_dialog(dialog)
        self.wait_window(dialog)

    def _ask_confirmation(self, title: str, message: str, *, confirm_text: str = "Продолжить") -> bool:
        result = tk.BooleanVar(value=False)
        dialog = tk.Toplevel(self)
        dialog.title(title)
        dialog.transient(self)
        dialog.resizable(False, False)
        dialog.grab_set()

        frame = ttk.Frame(dialog, padding=18)
        frame.pack(fill=tk.BOTH, expand=True)
        ttk.Label(frame, text=message, wraplength=520, justify=tk.LEFT).pack(anchor="w")
        buttons = ttk.Frame(frame)
        buttons.pack(fill=tk.X, pady=(18, 0))

        def confirm() -> None:
            result.set(True)
            dialog.destroy()

        ttk.Button(buttons, text="Отмена", command=dialog.destroy).pack(side=tk.RIGHT)
        ttk.Button(buttons, text=confirm_text, command=confirm).pack(side=tk.RIGHT, padx=(0, 8))
        dialog.bind("<Escape>", lambda _event: dialog.destroy())

        self._center_dialog(dialog)
        self.wait_window(dialog)
        return result.get()

    def _center_dialog(self, dialog: tk.Toplevel) -> None:
        dialog.update_idletasks()
        parent_x = self.winfo_rootx()
        parent_y = self.winfo_rooty()
        parent_width = self.winfo_width()
        parent_height = self.winfo_height()
        width = dialog.winfo_width()
        height = dialog.winfo_height()
        x = parent_x + max((parent_width - width) // 2, 0)
        y = parent_y + max((parent_height - height) // 2, 0)
        dialog.geometry(f"+{x}+{y}")

    def _append_output(self, line: str) -> None:
        self._handle_progress_line(line)
        display_line = display_log_line(line)
        if display_line is None:
            return
        self.output.insert(tk.END, display_line + "\n")
        self.output.see(tk.END)

    def _reset_progress_panel(self, label: str = "Ожидание") -> None:
        self.progress_var.set("")
        self.stage_var.set(label)
        self.downloaded_var.set("0")
        self.skipped_existing_var.set("0")
        self.archive_files_var.set("0/0")
        self.archive_size_var.set("0 Б из 0 Б")
        self.archive_speed_var.set("—")
        self.archive_eta_var.set("—")
        self.iphone_downloaded_count = 0
        self.iphone_skipped_existing_count = 0
        self.iphone_total_files = 0
        self.iphone_total_bytes = 0
        self.iphone_downloaded_bytes = 0
        self.iphone_skipped_existing_bytes = 0
        self.iphone_active_bytes = 0
        self.iphone_active_file_size = 0
        self.progress_started_at = time.monotonic()
        if hasattr(self, "progress_bar"):
            self.progress_bar.configure(mode="determinate")
            self.progress_bar["value"] = 0

    def _handle_progress_line(self, line: str) -> None:
        if not line:
            return

        if line.startswith("DEVICE:"):
            self.stage_var.set(line.replace("DEVICE:", "Устройство:", 1).strip())
            return

        if line.startswith("PLAN:"):
            self._parse_iphone_plan(line)
            return

        if line.startswith("STARTED:"):
            self._parse_iphone_started(line)
            return

        if line.startswith("FILE_PROGRESS:"):
            self._parse_iphone_file_progress(line)
            return

        if line.startswith("Временная папка:"):
            self.stage_var.set("Готовлю временную папку")
            return

        if line.startswith("Продолжаю с временной папки:"):
            self.stage_var.set("Продолжаю прошлое скачивание")
            return

        if line.startswith("Подтвердите доступ к данным на телефоне"):
            self.stage_var.set("Жду подтверждение на Android")
            self.progress_var.set(line)
            return

        if line.startswith("Повторяю Android MTP"):
            self.stage_var.set("Повторяю подключение к Android")
            self.progress_var.set(line)
            return

        if line.startswith("DOWNLOADED:"):
            self._parse_iphone_downloaded(line)
            return

        if line.startswith("SKIPPED_EXISTING:"):
            self._parse_iphone_skipped(line)
            return

        if line.startswith("DONE:"):
            self._parse_download_done(line)
            self.stage_var.set("Скачивание завершено, раскладываю по архиву")
            self.progress_var.set("Скачивание завершено, раскладываю по архиву...")
            self.progress_bar["value"] = 100
            return

        if line.startswith("Раскладываю скачанные файлы по архиву"):
            self._begin_archive_layout("Готовлю раскладку по архиву")
            return

        if line.startswith("Сканирую папку:"):
            self._begin_archive_layout("Сканирую файлы для архива")
            return

        if line.startswith("Найдено медиа-файлов:"):
            self._parse_media_found(line)
            return

        if line.startswith("Сканирование готово:"):
            self._parse_scan_done(line)
            return

        if line.startswith("Проверяю дубликаты:"):
            self._parse_duplicate_check(line)
            return

        if line.startswith("План готов:"):
            self._parse_archive_plan(line)
            return

        if line.startswith("Прогресс:"):
            self.progress_var.set(line.removeprefix("Прогресс:").strip())
            self._parse_archive_progress(line)
        elif line.startswith("К импорту:"):
            self.progress_var.set(line)
            self.stage_var.set("Копирую в архив")
            self._parse_import_total(line)
        elif line.startswith("Копирую:") or line.startswith("Перемещаю:"):
            self.stage_var.set("Копирую в архив")
        elif line.startswith("Пропускаю дубликат:"):
            self.stage_var.set("Пропускаю дубликаты")
        elif line.startswith("Временная папка очищена"):
            self.stage_var.set("Готово")

    def _begin_archive_layout(self, stage: str) -> None:
        self.stage_var.set(stage)
        self.archive_files_var.set("0/0")
        self.archive_size_var.set("считаю...")
        self.archive_speed_var.set("—")
        self.archive_eta_var.set("—")
        self.progress_bar.stop()
        self.progress_bar.configure(mode="indeterminate")
        self.progress_bar["value"] = 0
        self.progress_bar.start(12)

    def _parse_media_found(self, line: str) -> None:
        match = re.search(r"Найдено медиа-файлов:\s*(\d+)", line)
        if not match:
            self.stage_var.set(line)
            return
        found = int(match.group(1))
        self.stage_var.set(f"Сканирую файлы для архива: найдено {found}")
        self.archive_files_var.set(f"найдено {found}")
        self.archive_size_var.set("считаю...")

    def _parse_scan_done(self, line: str) -> None:
        match = re.search(r"Сканирование готово:\s*файлов\s*(\d+),\s*медиа\s*(\d+),\s*пропущено\s*(\d+)", line)
        if not match:
            self.stage_var.set("Проверяю дубликаты")
            return
        total_seen, media_found, ignored = (int(value) for value in match.groups())
        self.stage_var.set(f"Сканирование готово: медиа {media_found}, пропущено {ignored}")
        self.archive_files_var.set(f"0/{media_found}")
        self.archive_size_var.set("проверяю дубликаты...")
        self.archive_eta_var.set(f"просмотрено {total_seen}")
        self.progress_bar.stop()
        self.progress_bar.configure(mode="determinate")
        self.progress_bar["value"] = 0

    def _parse_duplicate_check(self, line: str) -> None:
        match = re.search(r"Проверяю дубликаты:\s*(\d+)/(\d+)", line)
        if not match:
            self.stage_var.set(line)
            return
        done, total = (int(value) for value in match.groups())
        self.stage_var.set(f"Проверяю дубликаты: {done}/{total}")
        self.archive_files_var.set(f"{done}/{total}")
        self.archive_size_var.set("считаю объём...")
        if total > 0:
            self.progress_bar["value"] = min(done / total * 100, 100.0)

    def _parse_archive_plan(self, line: str) -> None:
        match = re.search(r"План готов:\s*фото и видео\s*(\d+),\s*новых\s*(\d+),\s*дубликатов\s*(\d+)", line)
        if not match:
            self.stage_var.set(line)
            return
        total, new_files, duplicates = (int(value) for value in match.groups())
        self.progress_bar.stop()
        self.progress_bar.configure(mode="determinate")
        self.stage_var.set(f"План архива готов: новых {new_files}, дубликатов {duplicates}")
        self.archive_files_var.set(f"0/{new_files}")
        self.archive_size_var.set("считаю объём...")
        if total > 0 and new_files == 0:
            self.progress_bar["value"] = 100
        else:
            self.progress_bar["value"] = 0

    def _parse_import_total(self, line: str) -> None:
        match = re.search(r"К импорту:\s*(\d+)\s+файлов,\s*(.+)\.", line)
        if not match:
            return
        total_files, total_size = match.groups()
        self.progress_bar.stop()
        self.progress_bar.configure(mode="determinate")
        self.archive_files_var.set(f"0/{total_files}")
        self.archive_size_var.set(f"0 Б из {total_size}")
        self.archive_speed_var.set("—")
        self.archive_eta_var.set("считаю...")
        self.progress_started_at = time.monotonic()
        self.progress_bar["value"] = 0

    def _parse_archive_progress(self, line: str) -> None:
        match = re.search(
            r"Прогресс:\s*(\d+)/(\d+)\s+файлов,\s*([\d.]+)%,\s*(.+?),\s*"
            r"скорость\s+(.+?)/с,\s*осталось\s+(.+?)\.",
            line,
        )
        if not match:
            return

        done, total, percent, size_text, speed_text, eta_text = match.groups()
        self.progress_bar.stop()
        self.progress_bar.configure(mode="determinate")
        self.stage_var.set("Раскладываю по архиву")
        self.archive_files_var.set(f"{done}/{total}")
        self.archive_size_var.set(size_text)
        self.archive_speed_var.set(f"{speed_text}/с")
        self.archive_eta_var.set(eta_text)
        self.progress_bar["value"] = min(float(percent), 100.0)

    def _parse_iphone_plan(self, line: str) -> None:
        match = re.search(r"PLAN:\s*media=(\d+)\s+bytes=(\d+)", line)
        if not match:
            return
        self.iphone_total_files = int(match.group(1))
        self.iphone_total_bytes = int(match.group(2))
        self.archive_files_var.set(f"0/{self.iphone_total_files}")
        self.archive_size_var.set(f"0 Б из {format_size(self.iphone_total_bytes)}")
        self.archive_speed_var.set("считаю...")
        self.archive_eta_var.set("считаю...")
        self.stage_var.set("План скачивания готов")
        self.progress_bar["value"] = 0

    def _parse_iphone_started(self, line: str) -> None:
        size, path = parse_helper_file_line(line, "STARTED:")
        self.iphone_active_bytes = 0
        self.iphone_active_file_size = size if size is not None and size > 0 else 0
        file_name = Path(path).name if path else "файл"
        if size is not None and size >= 0:
            self.stage_var.set(f"Скачиваю: {file_name} ({format_size(size)})")
        else:
            self.stage_var.set(f"Скачиваю: {file_name}")
        self._update_iphone_download_metrics()

    def _parse_iphone_file_progress(self, line: str) -> None:
        match = re.search(r"FILE_PROGRESS:\s*(\d+)\s+(-?\d+)\s+(.+)", line)
        if not match:
            return
        copied, expected, path = match.groups()
        self.iphone_active_bytes = int(copied)
        file_name = Path(path).name
        if int(expected) > 0:
            self.stage_var.set(f"Скачиваю: {file_name} ({format_size(int(copied))} из {format_size(int(expected))})")
        else:
            self.stage_var.set(f"Скачиваю: {file_name} ({format_size(int(copied))})")
        self._update_iphone_download_metrics()

    def _parse_iphone_downloaded(self, line: str) -> None:
        size, path = parse_helper_file_line(line, "DOWNLOADED:")
        self.iphone_downloaded_count += 1
        downloaded_size = size if size is not None and size > 0 else self.iphone_active_file_size
        if downloaded_size > 0:
            self.iphone_downloaded_bytes += downloaded_size
        self.iphone_active_bytes = 0
        self.iphone_active_file_size = 0
        file_name = Path(path).name if path else "файл"
        self.stage_var.set(f"Скачан: {file_name}")
        self._update_iphone_download_metrics()

    def _parse_iphone_skipped(self, line: str) -> None:
        size, path = parse_helper_file_line(line, "SKIPPED_EXISTING:")
        self.iphone_skipped_existing_count += 1
        skipped_size = size if size is not None and size > 0 else self.iphone_active_file_size
        if skipped_size > 0:
            self.iphone_skipped_existing_bytes += skipped_size
        self.iphone_active_bytes = 0
        self.iphone_active_file_size = 0
        file_name = Path(path).name if path else "файл"
        self.stage_var.set(f"Уже было во временной: {file_name}")
        self._update_iphone_download_metrics()

    def _update_iphone_download_metrics(self) -> None:
        done_files = self.iphone_downloaded_count + self.iphone_skipped_existing_count
        if self.iphone_total_files:
            self.archive_files_var.set(f"{done_files}/{self.iphone_total_files}")
        else:
            self.archive_files_var.set(str(done_files))

        actual_downloaded = self.iphone_downloaded_bytes + self.iphone_active_bytes
        done_bytes = actual_downloaded + self.iphone_skipped_existing_bytes
        if self.iphone_total_bytes:
            self.archive_size_var.set(f"{format_size(done_bytes)} из {format_size(self.iphone_total_bytes)}")
            self.progress_bar["value"] = min(done_bytes / self.iphone_total_bytes * 100, 100.0)
        elif actual_downloaded:
            self.archive_size_var.set(format_size(done_bytes))

        self.downloaded_var.set(f"{self.iphone_downloaded_count} ({format_size(actual_downloaded)})")
        self.skipped_existing_var.set(
            f"{self.iphone_skipped_existing_count} ({format_size(self.iphone_skipped_existing_bytes)})"
        )

        elapsed = max(time.monotonic() - self.progress_started_at, 0.001)
        speed = actual_downloaded / elapsed
        if speed > 0:
            self.archive_speed_var.set(f"{format_size(int(speed))}/с")
        else:
            self.archive_speed_var.set("—")

        if self.iphone_total_bytes and speed > 0:
            remaining = max(self.iphone_total_bytes - done_bytes, 0)
            self.archive_eta_var.set(format_duration(int(remaining / speed)))
        elif self.iphone_total_bytes:
            self.archive_eta_var.set("считаю...")

    def _parse_download_done(self, line: str) -> None:
        match = re.search(r"DONE:.*\bmedia=(\d+).*?\bdownloaded=(\d+).*?\bskipped_existing=(\d+).*?\bfailed=(\d+).*?\bbytes=(\d+)", line)
        if not match:
            return
        media, downloaded, skipped, failed, total_bytes = (int(value) for value in match.groups())
        completed = downloaded + skipped
        self.iphone_total_files = media
        self.iphone_total_bytes = total_bytes
        self.archive_files_var.set(f"{completed}/{media}")
        self.archive_size_var.set(f"{format_size(self.iphone_downloaded_bytes)} из {format_size(total_bytes)}")
        self.downloaded_var.set(f"{downloaded} ({format_size(self.iphone_downloaded_bytes)})")
        self.skipped_existing_var.set(f"{skipped} ({format_size(self.iphone_skipped_existing_bytes)})")
        self.archive_eta_var.set("—" if failed == 0 else "есть ошибки")

    def _refresh_history(self) -> None:
        if not hasattr(self, "history_tree"):
            return
        self.history_tree.delete(*self.history_tree.get_children())
        self.history_files_tree.delete(*self.history_files_tree.get_children())

        archive = self._selected_archive()
        if archive is None:
            return

        with ImportStore(archive) as store:
            sessions = store.list_sessions(limit=50)

        for session in sessions:
            self.history_tree.insert(
                "",
                tk.END,
                iid=str(session.id),
                values=(
                    session.started_at,
                    russian_source_type(session.source_type),
                    russian_session_status(session.status),
                    session.imported,
                    session.new_files,
                    session.duplicates,
                    session.archive_path,
                ),
            )

    def _history_selected(self, _event: object) -> None:
        selected = self.history_tree.selection()
        self.history_files_tree.delete(*self.history_files_tree.get_children())
        if not selected:
            return

        archive = self._selected_archive()
        if archive is None:
            return

        session_id = int(selected[0])
        with ImportStore(archive) as store:
            files = store.list_session_files(session_id, limit=500)

        for file in files:
            self.history_files_tree.insert(
                "",
                tk.END,
                values=(
                    russian_file_status(file.status),
                    russian_kind(file.kind),
                    file.date_taken,
                    russian_date_source(file.date_source),
                    file.file_name,
                    file.dest_path,
                ),
            )

    def _selected_archive(self) -> Path | None:
        text = self.dest_var.get().strip()
        if not text:
            return None
        archive = Path(text).expanduser()
        if not archive.exists():
            return None
        return archive

    def _refresh_temp_files(self) -> None:
        if not hasattr(self, "temp_tree"):
            return
        self.temp_tree.delete(*self.temp_tree.get_children())

        folders: list[Path] = []
        for root in (iphone_staging_root(), android_staging_root()):
            if root.exists():
                folders.extend(path for path in root.glob("*/*") if path.is_dir())
        folders.sort(key=lambda path: path.stat().st_mtime, reverse=True)
        for folder in folders:
            self.temp_tree.insert(
                "",
                tk.END,
                iid=str(folder),
                values=(
                    format_mtime(folder),
                    format_size(folder_size(folder)),
                    str(folder),
                ),
            )

    def _open_selected_temp(self) -> None:
        folder = self._selected_temp_folder()
        if folder is None:
            self._show_message(APP_NAME, "Выберите временную папку.")
            return
        subprocess.Popen(["open", str(folder)])

    def _clear_selected_temp(self) -> None:
        folder = self._selected_temp_folder()
        if folder is None:
            self._show_message(APP_NAME, "Выберите временную папку.")
            return
        if self.cancel_event is not None:
            self._show_message(APP_NAME, "Нельзя очищать временные файлы, пока идёт импорт.")
            return
        shutil.rmtree(folder, ignore_errors=True)
        self._refresh_temp_files()

    def _clear_all_temp(self) -> None:
        if self.cancel_event is not None:
            self._show_message(APP_NAME, "Нельзя очищать временные файлы, пока идёт импорт.")
            return
        for root in (iphone_staging_root(), android_staging_root()):
            if root.exists():
                shutil.rmtree(root, ignore_errors=True)
        self._refresh_temp_files()

    def _selected_temp_folder(self) -> Path | None:
        selected = self.temp_tree.selection()
        if not selected:
            return None
        folder = Path(selected[0])
        if not folder.exists():
            return None
        return folder

    def _show_result(self, title: str, items: list, summary: object) -> None:
        lines = [title, ""]
        labels = {
            "total_seen": "Всего файлов найдено",
            "media_found": "Фото и видео",
            "ignored": "Пропущено служебных/неподходящих",
            "new_files": "Новых к импорту",
            "duplicates": "Уже были импортированы",
            "imported": "Импортировано сейчас",
        }
        for key in ("total_seen", "media_found", "ignored", "new_files", "duplicates", "imported"):
            if hasattr(summary, key):
                lines.append(f"{labels[key]}: {getattr(summary, key)}")

        lines.append("")
        lines.append("Файлы:")
        for item in items[:200]:
            media = item.media
            status = russian_status(item.status)
            kind = russian_kind(media.kind)
            lines.append(
                f"[{status}] {media.created_at:%Y-%m-%d} "
                f"{kind} {media.path.name} -> {item.destination}"
            )
        if len(items) > 200:
            lines.append(f"... ещё {len(items) - 200}")

        self._append_output("")
        self._append_output("\n".join(lines))

    def _show_text(self, title: str, output: str) -> None:
        self._append_output("")
        self._append_output(f"{title}\n\n{output}")

    def _show_device_import_result(self, title: str, helper_output: str, summary: object) -> None:
        lines = [title, ""]
        if helper_output:
            lines.append(helper_output)
            lines.append("")

        labels = {
            "total_seen": "Скачано во временную папку",
            "media_found": "Фото и видео",
            "ignored": "Пропущено служебных/неподходящих",
            "new_files": "Новых к импорту",
            "duplicates": "Уже были импортированы",
            "imported": "Разложено по архиву",
        }
        for key in ("total_seen", "media_found", "ignored", "new_files", "duplicates", "imported"):
            if hasattr(summary, key):
                lines.append(f"{labels[key]}: {getattr(summary, key)}")

        self._append_output("")
        self._append_output("\n".join(lines))

    def _set_buttons_state(self, state: str) -> None:
        for child in self.winfo_children():
            self._set_state_recursive(child, state)

    def _set_state_recursive(self, widget: tk.Widget, state: str) -> None:
        if isinstance(widget, ttk.Button):
            widget.configure(state=state)
        for child in widget.winfo_children():
            self._set_state_recursive(child, state)


def russian_status(status: str) -> str:
    return {
        "new": "новый",
        "duplicate": "дубликат",
    }.get(status, status)


def russian_kind(kind: str) -> str:
    return {
        "photo": "фото",
        "video": "видео",
    }.get(kind, kind)


def russian_source_type(source_type: str) -> str:
    return {
        "folder": "папка",
        "iphone": "iPhone",
        "iphone_windows": "iPhone",
        "android": "Android",
        "android_windows": "Android",
    }.get(source_type, source_type)


def russian_session_status(status: str) -> str:
    return {
        "running": "идёт",
        "completed": "завершён",
        "stopped": "остановлен",
        "error": "ошибка",
    }.get(status, status)


def russian_file_status(status: str) -> str:
    return {
        "imported": "импортирован",
        "duplicate": "дубликат",
        "skipped": "пропущен",
    }.get(status, status)


def russian_date_source(date_source: str) -> str:
    return {
        "image_exif_original": "EXIF",
        "image_exif_digitized": "EXIF",
        "video_quicktime": "видео",
        "sips_creation": "sips",
        "mdls_content_creation": "mdls",
        "filesystem_mtime": "файл",
    }.get(date_source, date_source)


def folder_size(folder: Path) -> int:
    total = 0
    for path in folder.rglob("*"):
        try:
            if path.is_file():
                total += path.stat().st_size
        except OSError:
            continue
    return total


def format_size(size: int) -> str:
    if size >= 1024 * 1024 * 1024:
        return f"{size / (1024 * 1024 * 1024):.1f} ГБ"
    if size >= 1024 * 1024:
        return f"{size / (1024 * 1024):.1f} МБ"
    if size >= 1024:
        return f"{size / 1024:.1f} КБ"
    return f"{size} Б"


def format_duration(seconds: int) -> str:
    if seconds <= 0:
        return "меньше минуты"
    minutes, sec = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    if hours:
        return f"{hours} ч {minutes} мин"
    if minutes:
        return f"{minutes} мин {sec} сек"
    return f"{sec} сек"


def parse_helper_file_line(line: str, prefix: str) -> tuple[int | None, str]:
    payload = line.removeprefix(prefix).strip()
    match = re.match(r"(-?\d+)\s+(.+)", payload)
    if match:
        return int(match.group(1)), match.group(2)
    match = re.match(r"(.+?)\s+size=(\d+)$", payload)
    if match:
        path, size = match.groups()
        return int(size), path
    if " -> " in payload:
        payload = payload.split(" -> ", 1)[0]
    return None, payload


def display_log_line(line: str) -> str | None:
    if line.startswith("FILE_PROGRESS:") or line.startswith("PLAN:") or line.startswith("STARTED:"):
        return None

    if line.startswith("DEVICE:"):
        return line.replace("DEVICE:", "Устройство:", 1).strip()

    if line.startswith("DOWNLOADED:"):
        size, path = parse_helper_file_line(line, "DOWNLOADED:")
        name = Path(path).name
        if size is not None and size >= 0:
            return f"Скачан: {name} ({format_size(size)})"
        return f"Скачан: {name}"

    if line.startswith("SKIPPED_EXISTING:"):
        size, path = parse_helper_file_line(line, "SKIPPED_EXISTING:")
        name = Path(path).name
        if size is not None and size >= 0:
            return f"Уже во временной папке: {name} ({format_size(size)})"
        return f"Уже во временной папке: {name}"

    if line.startswith("DONE:"):
        match = re.search(r"media=(\d+)\s+downloaded=(\d+)(?:\s+skipped=(\d+))?\s+failed=(\d+)", line)
        if match:
            media, downloaded, skipped, failed = match.groups()
            skipped_text = skipped or "0"
            return (
                "Скачивание завершено: "
                f"медиа {media}, скачано {downloaded}, уже было {skipped_text}, ошибок {failed}."
            )

    return line


def format_mtime(path: Path) -> str:
    try:
        return datetime.fromtimestamp(path.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S")
    except OSError:
        return ""


def main() -> int:
    app = FotoSaveApp()
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
