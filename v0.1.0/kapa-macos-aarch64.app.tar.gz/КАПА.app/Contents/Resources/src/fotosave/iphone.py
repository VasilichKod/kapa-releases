from __future__ import annotations

import os
import hashlib
import platform
import queue
import select
import shutil
import subprocess
import tempfile
from datetime import datetime
from pathlib import Path
from threading import Event, Thread
from typing import Callable

from .importer import ImportCancelled, ImportSummary, import_files
from .store import ImportStore


PROJECT_ROOT = Path(__file__).resolve().parents[2]
HELPER_SOURCE = PROJECT_ROOT / "tools" / "FotoSavePhoneImport.swift"
HELPER_BINARY = PROJECT_ROOT / "bin" / "FotoSavePhoneImport"
AFC_HELPER_SOURCE = PROJECT_ROOT / "tools" / "FotoSaveAFCImport.c"
AFC_HELPER_BINARY = PROJECT_ROOT / "bin" / "FotoSaveAFCImport"
WINDOWS_HELPER_SOURCE = PROJECT_ROOT / "tools" / "iphone_windows_shell.ps1"
WINDOWS_CREATE_NO_WINDOW = 0x08000000
USBMUXD_ERROR_MARKERS = (
    "AMDeviceNotificationSubscribe status=-402653085",
    "status=-402653085",
    "0xE8000063",
)


class IPhoneImportError(RuntimeError):
    pass


ProgressCallback = Callable[[str], None]


def list_iphone_files(*, timeout: int = 60, limit: int = 30) -> str:
    if platform.system() == "Windows":
        return list_iphone_files_windows(limit=limit)
    ensure_macos_iphone_backend()
    ensure_afc_helper()
    result = run_text_command(
        [str(AFC_HELPER_BINARY), "list", "--timeout", str(timeout), "--limit", str(limit)],
    )
    if result.returncode != 0:
        raise IPhoneImportError(iphone_error_text(result.stdout.strip() or "Не удалось проверить iPhone."))
    return result.stdout.strip()


def debug_iphone_devices(*, timeout: int = 10) -> str:
    if platform.system() == "Windows":
        return list_iphone_files_windows(limit=10)
    ensure_macos_iphone_backend()
    ensure_helper()
    result = run_text_command(
        [str(HELPER_BINARY), "debug", "--timeout", str(timeout)],
    )
    if result.returncode != 0:
        raise IPhoneImportError(iphone_error_text(result.stdout.strip() or "Не удалось получить диагностику iPhone."))
    return result.stdout.strip()


def list_iphone_directory(path: str = "/", *, timeout: int = 10) -> str:
    if platform.system() == "Windows":
        raise IPhoneImportError("Просмотр произвольных папок iPhone на Windows пока не реализован. Используйте iphone-list.")
    ensure_macos_iphone_backend()
    ensure_afc_helper()
    result = run_text_command(
        [str(AFC_HELPER_BINARY), "ls", "--path", path, "--timeout", str(timeout)],
    )
    if result.returncode != 0:
        raise IPhoneImportError(iphone_error_text(result.stdout.strip() or f"Не удалось открыть папку iPhone: {path}"))
    return result.stdout.strip()


def first_iphone_media_path(*, timeout: int = 10) -> str:
    if platform.system() == "Windows":
        output = list_iphone_files_windows(limit=1)
        for line in output.splitlines():
            if line.startswith("/"):
                return line
            if " /" in line:
                return line.split(" ", 1)[1]
        raise IPhoneImportError("Не удалось найти первый медиа-файл на iPhone.")
    ensure_macos_iphone_backend()
    ensure_afc_helper()
    result = run_text_command(
        [str(AFC_HELPER_BINARY), "first", "--timeout", str(timeout)],
    )
    if result.returncode != 0:
        raise IPhoneImportError(iphone_error_text(command_error("Не удалось найти первый медиа-файл на iPhone.", [str(AFC_HELPER_BINARY), "first"], result)))
    return result.stdout.strip()


def import_from_iphone(
    dest: Path,
    *,
    timeout: int = 600,
    limit: int | None = None,
    media_filter: str = "all",
    conversion_mode: str = "original",
    progress: ProgressCallback | None = None,
    cancel_event: Event | None = None,
    full_check: bool = False,
) -> tuple[str, ImportSummary]:
    if platform.system() == "Windows":
        return import_from_iphone_windows(
            dest,
            limit=limit,
            media_filter=media_filter,
            conversion_mode=conversion_mode,
            progress=progress,
            cancel_event=cancel_event,
            full_check=full_check,
        )
    ensure_macos_iphone_backend()
    ensure_afc_helper()
    dest = dest.expanduser().resolve()
    staging = resume_staging_folder(dest) or _staging_folder(dest)
    staging.mkdir(parents=True, exist_ok=True)
    summary = ImportSummary(0, 0, 0, 0, 0, 0)
    with ImportStore(dest) as store:
        session_id = store.create_session(
            source_type="iphone",
            source_path="iPhone",
            archive_path=dest,
            staging_path=staging,
        )
    if progress:
        if any(staging.rglob("*")):
            progress(f"Продолжаю с временной папки: {staging}")
        else:
            progress(f"Временная папка: {staging}")

    command = [
        str(AFC_HELPER_BINARY),
        "download",
        "--output",
        str(staging),
        "--timeout",
        str(timeout),
    ]
    if media_filter != "all":
        command.extend(["--media", media_filter])
    if limit is not None:
        command.extend(["--limit", str(limit)])

    try:
        result = run_streaming_command(
            command,
            progress=progress,
            cancel_event=cancel_event,
        )
        if result.returncode != 0:
            summary = import_partial_staging(
                staging,
                dest,
                media_filter=media_filter,
                conversion_mode=conversion_mode,
                session_id=session_id,
            )
            if summary.media_found > 0:
                detail = command_error("Скачивание с iPhone прервалось, но часть файлов удалось разложить.", command, result)
                detail += "\n\nЧастично разложено:\n"
                detail += summary_text(summary)
                raise IPhoneImportError(iphone_error_text(detail))
            raise IPhoneImportError(iphone_error_text(command_error("Не удалось скачать файлы с iPhone.", command, result)))

        if progress:
            progress("Раскладываю скачанные файлы по архиву...")
        _items, summary = import_files(
            staging,
            dest,
            move=True,
            media_filter=media_filter,
            conversion_mode=conversion_mode,
            progress=progress,
            cancel_check=cancel_event.is_set if cancel_event else None,
            source_type="iphone",
            session_id=session_id,
            staging_path=staging,
            finish_session=False,
        )
        if summary.media_found == 0:
            staging_files = sorted(str(path.relative_to(staging)) for path in staging.rglob("*") if path.is_file())
            sample = "\n".join(staging_files[:30])
            shutil.rmtree(staging, ignore_errors=True)
            detail = result.stdout.strip()
            if sample:
                detail = f"{detail}\n\nФайлы во временной папке:\n{sample}"
            raise IPhoneImportError("Файлы с iPhone скачались, но Мой Архив не нашёл среди них фото/видео.\n" + detail)
        shutil.rmtree(staging, ignore_errors=True)
        with ImportStore(dest) as store:
            store.finish_session(session_id, status="completed", summary=summary, staging_path=staging)
        if progress:
            progress("Временная папка очищена.")
        return result.stdout.strip(), summary
    except ImportCancelled as exc:
        with ImportStore(dest) as store:
            store.finish_session(session_id, status="stopped", summary=summary, error_text=str(exc), staging_path=staging)
        raise
    except Exception as exc:
        with ImportStore(dest) as store:
            store.finish_session(session_id, status="error", summary=summary, error_text=str(exc), staging_path=staging)
        raise


def import_partial_staging(
    staging: Path,
    dest: Path,
    *,
    media_filter: str = "all",
    conversion_mode: str = "original",
    session_id: int | None = None,
) -> ImportSummary:
    if not staging.exists():
        return ImportSummary(0, 0, 0, 0, 0, 0)
    try:
        _items, summary = import_files(
            staging,
            dest,
            move=True,
            media_filter=media_filter,
            conversion_mode=conversion_mode,
            source_type="iphone",
            session_id=session_id,
            staging_path=staging,
            finish_session=False,
        )
    except Exception:
        return ImportSummary(0, 0, 0, 0, 0, 0)
    return summary


def is_usbmuxd_error(text: object) -> bool:
    error_text = str(text)
    return any(marker in error_text for marker in USBMUXD_ERROR_MARKERS)


def iphone_error_text(text: str) -> str:
    if not is_usbmuxd_error(text):
        return text
    return (
        "macOS временно потеряла службу подключения iPhone.\n\n"
        "В приложении нажмите «Восстановить iPhone», введите пароль администратора, "
        "потом отключите и снова подключите iPhone, разблокируйте его и повторите импорт.\n\n"
        f"Технические детали:\n{text}"
    )


def repair_iphone_connection() -> str:
    if platform.system() == "Windows":
        raise IPhoneImportError(
            "Восстановление usbmuxd относится только к macOS.\n\n"
            "На Windows отключите кабель, подключите iPhone снова, разблокируйте его и подтвердите доступ к фото."
        )
    ensure_macos_iphone_backend()
    command = [
        "osascript",
        "-e",
        (
            'do shell script "killall -QUIT usbmuxd" '
            'with administrator privileges '
            'with prompt "Моему Архиву нужно восстановить подключение к iPhone."'
        ),
    ]
    result = run_text_command(command)
    if result.returncode != 0:
        detail = result.stdout.strip()
        if detail:
            raise IPhoneImportError("Не удалось восстановить подключение iPhone.\n\n" + detail)
        raise IPhoneImportError("Не удалось восстановить подключение iPhone.")
    return (
        "Служба подключения iPhone перезапущена.\n\n"
        "Теперь отключите кабель, подключите iPhone снова, разблокируйте его, "
        "подтвердите доверие компьютеру, если появится запрос, и повторите импорт."
    )


def ensure_macos_iphone_backend() -> None:
    if platform.system() == "Darwin":
        return
    raise IPhoneImportError(
        "iPhone-импорт на Windows еще не реализован.\n\n"
        "Следующий этап переноса: сделать адаптер iphone_windows для доступа к DCIM через Windows Portable Device "
        "или видимую в проводнике папку Internal Storage/DCIM."
    )


def list_iphone_files_windows(*, limit: int = 30) -> str:
    ensure_windows_iphone_helper()
    command = windows_iphone_command("list", limit=limit)
    result = run_text_command(command)
    if result.returncode != 0:
        raise IPhoneImportError(result.stdout.strip() or "Не удалось прочитать iPhone через Windows Shell.")
    return result.stdout.strip()


def import_from_iphone_windows(
    dest: Path,
    *,
    limit: int | None = None,
    media_filter: str = "all",
    conversion_mode: str = "original",
    progress: ProgressCallback | None = None,
    cancel_event: Event | None = None,
    full_check: bool = False,
) -> tuple[str, ImportSummary]:
    ensure_windows_iphone_helper()
    dest = dest.expanduser().resolve()
    staging = resume_staging_folder(dest) or _staging_folder(dest)
    staging.mkdir(parents=True, exist_ok=True)
    skip_manifest = None if full_check else staging / ".kapa-known-iphone.txt"
    summary = ImportSummary(0, 0, 0, 0, 0, 0)

    with ImportStore(dest) as store:
        known_count = 0 if skip_manifest is None else store.write_source_skip_manifest("iphone", skip_manifest)
        session_id = store.create_session(
            source_type="iphone_windows",
            source_path="Apple iPhone",
            archive_path=dest,
            staging_path=staging,
        )

    if progress:
        if folder_has_files(staging):
            progress(f"Продолжаю с временной папки: {staging}")
        else:
            progress(f"Временная папка: {staging}")
        if known_count > 0:
            progress(f"Уже в журнале iPhone: {known_count} файлов.")
        progress("Ищу iPhone через Windows Shell...")
        progress("Сканирую фото и видео на iPhone...")

    command = windows_iphone_command(
        "download",
        output=staging,
        limit=limit,
        media_filter=media_filter,
        skip_manifest=skip_manifest,
    )

    try:
        result = run_streaming_command(command, progress=progress, cancel_event=cancel_event)
        if result.returncode != 0:
            summary = import_partial_staging(
                staging,
                dest,
                media_filter=media_filter,
                conversion_mode=conversion_mode,
                session_id=session_id,
            )
            detail = command_error("Скачивание с iPhone через Windows прервалось.", command, result)
            if summary.media_found > 0:
                detail += "\n\nЧастично разложено:\n" + summary_text(summary)
            raise IPhoneImportError(detail)

        if progress:
            progress("Раскладываю скачанные файлы по архиву...")
        _items, summary = import_files(
            staging,
            dest,
            move=True,
            media_filter=media_filter,
            conversion_mode=conversion_mode,
            progress=progress,
            cancel_check=cancel_event.is_set if cancel_event else None,
            source_type="iphone_windows",
            session_id=session_id,
            staging_path=staging,
            finish_session=False,
        )
        if summary.media_found == 0:
            staging_files = sorted(str(path.relative_to(staging)) for path in staging.rglob("*") if path.is_file())
            sample = "\n".join(staging_files[:30])
            shutil.rmtree(staging, ignore_errors=True)
            detail = result.stdout.strip()
            if sample:
                detail = f"{detail}\n\nФайлы во временной папке:\n{sample}"
            raise IPhoneImportError("Файлы с iPhone скачались, но Мой Архив не нашел среди них фото/видео.\n" + detail)

        shutil.rmtree(staging, ignore_errors=True)
        with ImportStore(dest) as store:
            store.finish_session(session_id, status="completed", summary=summary, staging_path=staging)
        if progress:
            progress("Временная папка очищена.")
        return result.stdout.strip(), summary
    except ImportCancelled as exc:
        with ImportStore(dest) as store:
            store.finish_session(session_id, status="stopped", summary=summary, error_text=str(exc), staging_path=staging)
        raise
    except Exception as exc:
        with ImportStore(dest) as store:
            store.finish_session(session_id, status="error", summary=summary, error_text=str(exc), staging_path=staging)
        raise


def ensure_windows_iphone_helper() -> None:
    if not WINDOWS_HELPER_SOURCE.exists():
        raise IPhoneImportError(f"Не найден Windows iPhone helper: {WINDOWS_HELPER_SOURCE}")


def windows_iphone_command(
    command: str,
    *,
    output: Path | None = None,
    limit: int | None = None,
    media_filter: str = "all",
    skip_manifest: Path | None = None,
) -> list[str]:
    result = [
        "powershell.exe",
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        str(WINDOWS_HELPER_SOURCE),
        command,
    ]
    if output is not None:
        result.extend(["-Output", str(output)])
    if limit is not None:
        result.extend(["-Limit", str(limit)])
    if media_filter != "all":
        result.extend(["-Media", media_filter])
    if skip_manifest is not None:
        result.extend(["-SkipManifest", str(skip_manifest)])
    return result


def ensure_helper() -> None:
    if not HELPER_SOURCE.exists():
        raise IPhoneImportError(f"Не найден Swift-helper: {HELPER_SOURCE}")

    if HELPER_BINARY.exists() and HELPER_BINARY.stat().st_mtime >= HELPER_SOURCE.stat().st_mtime:
        return

    HELPER_BINARY.parent.mkdir(parents=True, exist_ok=True)
    cache_root = PROJECT_ROOT / ".build"
    clang_cache = cache_root / "clang-module-cache"
    swift_cache = cache_root / "swift-module-cache"
    clang_cache.mkdir(parents=True, exist_ok=True)
    swift_cache.mkdir(parents=True, exist_ok=True)

    env = os.environ.copy()
    env["CLANG_MODULE_CACHE_PATH"] = str(clang_cache)
    env["SWIFT_MODULE_CACHE_PATH"] = str(swift_cache)

    result = run_text_command(
        [
            "swiftc",
            str(HELPER_SOURCE),
            "-o",
            str(HELPER_BINARY),
            "-framework",
            "Foundation",
            "-framework",
            "ImageCaptureCore",
        ],
        cwd=PROJECT_ROOT,
        env=env,
    )
    if result.returncode != 0:
        raise IPhoneImportError("Не удалось собрать iPhone-helper:\n" + result.stdout)


def ensure_afc_helper() -> None:
    if not AFC_HELPER_SOURCE.exists():
        raise IPhoneImportError(f"Не найден AFC-helper: {AFC_HELPER_SOURCE}")

    if AFC_HELPER_BINARY.exists() and AFC_HELPER_BINARY.stat().st_mtime >= AFC_HELPER_SOURCE.stat().st_mtime:
        return

    AFC_HELPER_BINARY.parent.mkdir(parents=True, exist_ok=True)
    result = run_text_command(
        [
            "clang",
            str(AFC_HELPER_SOURCE),
            "-o",
            str(AFC_HELPER_BINARY),
            "-framework",
            "CoreFoundation",
            "/System/Library/PrivateFrameworks/MobileDevice.framework/MobileDevice",
        ],
        cwd=PROJECT_ROOT,
    )
    if result.returncode != 0:
        raise IPhoneImportError("Не удалось собрать AFC-helper:\n" + result.stdout)


def _staging_folder(dest: Path) -> Path:
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    return iphone_staging_root() / _archive_key(dest) / stamp


def resume_staging_folder(dest: Path) -> Path | None:
    root = iphone_staging_root() / _archive_key(dest)
    if not root.exists():
        return None

    folders = [path for path in root.glob("*") if path.is_dir() and folder_has_files(path)]
    if not folders:
        return None
    folders.sort(key=lambda path: path.stat().st_mtime, reverse=True)
    return folders[0]


def folder_has_files(folder: Path) -> bool:
    try:
        return any(path.is_file() and not path.name.startswith(".kapa-known-") for path in folder.rglob("*"))
    except OSError:
        return False


def iphone_staging_root() -> Path:
    return Path(tempfile.gettempdir()) / "fotosave" / "iphone-staging"


def _archive_key(dest: Path) -> str:
    return hashlib.sha256(str(dest.expanduser().resolve()).encode("utf-8")).hexdigest()[:16]


def run_text_command(
    command: list[str],
    *,
    cwd: Path | None = None,
    env: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        cwd=cwd,
        env=env,
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        creationflags=subprocess_creation_flags(),
    )


def run_streaming_command(
    command: list[str],
    *,
    progress: ProgressCallback | None = None,
    cancel_event: Event | None = None,
) -> subprocess.CompletedProcess[str]:
    if platform.system() == "Windows":
        return run_streaming_command_threaded(command, progress=progress, cancel_event=cancel_event)

    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        bufsize=1,
        creationflags=subprocess_creation_flags(),
    )
    output_parts: list[str] = []
    assert process.stdout is not None

    while True:
        if cancel_event and cancel_event.is_set():
            process.terminate()
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
            raise ImportCancelled("Импорт остановлен пользователем.")

        ready, _, _ = select.select([process.stdout], [], [], 0.2)
        if ready:
            line = process.stdout.readline()
            if line:
                output_parts.append(line)
                if progress:
                    progress(line.rstrip())
                continue

        if process.poll() is not None:
            remaining = process.stdout.read()
            if remaining:
                output_parts.append(remaining)
                if progress:
                    for line in remaining.splitlines():
                        progress(line)
            break

    return subprocess.CompletedProcess(command, process.returncode, "".join(output_parts), None)


def run_streaming_command_threaded(
    command: list[str],
    *,
    progress: ProgressCallback | None = None,
    cancel_event: Event | None = None,
) -> subprocess.CompletedProcess[str]:
    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        bufsize=1,
        creationflags=subprocess_creation_flags(),
    )
    output_parts: list[str] = []
    lines: queue.Queue[str | None] = queue.Queue()
    assert process.stdout is not None

    def read_stdout() -> None:
        assert process.stdout is not None
        for line in process.stdout:
            lines.put(line)
        lines.put(None)

    reader = Thread(target=read_stdout, daemon=True)
    reader.start()

    stdout_closed = False
    while True:
        if cancel_event and cancel_event.is_set():
            process.terminate()
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
            raise ImportCancelled("Импорт остановлен пользователем.")

        try:
            line = lines.get(timeout=0.2)
        except queue.Empty:
            if process.poll() is not None and stdout_closed:
                break
            continue

        if line is None:
            stdout_closed = True
            if process.poll() is not None:
                break
            continue

        output_parts.append(line)
        if progress:
            progress(line.rstrip())

    process.wait()
    reader.join(timeout=1)
    return subprocess.CompletedProcess(command, process.returncode, "".join(output_parts), None)


def subprocess_creation_flags() -> int:
    if platform.system() == "Windows":
        return WINDOWS_CREATE_NO_WINDOW
    return 0


def command_error(message: str, command: list[str], result: subprocess.CompletedProcess[str]) -> str:
    output = result.stdout.strip()
    command_text = " ".join(command)
    if output:
        return f"{message}\nКод: {result.returncode}\nКоманда: {command_text}\n\n{output}"
    return f"{message}\nКод: {result.returncode}\nКоманда: {command_text}"


def summary_text(summary: ImportSummary) -> str:
    return (
        f"Всего файлов: {summary.total_seen}\n"
        f"Фото и видео: {summary.media_found}\n"
        f"Новых: {summary.new_files}\n"
        f"Дубликатов: {summary.duplicates}\n"
        f"Импортировано: {summary.imported}"
    )
