from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .android import AndroidImportError, import_from_android, list_android_files
from .importer import (
    ImportPlanItem,
    build_plan,
    clear_staging,
    import_files,
    reset_import_journal,
    resort_archive,
)
from .iphone import (
    IPhoneImportError,
    debug_iphone_devices,
    first_iphone_media_path,
    import_from_iphone,
    list_iphone_directory,
    list_iphone_files,
    repair_iphone_connection,
)
from .store import ImportStore


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="moy-archive")
    subparsers = parser.add_subparsers(dest="command", required=True)

    scan_parser = subparsers.add_parser("scan", help="Preview media import plan.")
    add_common_args(scan_parser)
    scan_parser.add_argument("--limit", type=int, default=20, help="Rows to show. Use 0 to show all.")

    import_parser = subparsers.add_parser("import", help="Copy or move media into the archive.")
    add_common_args(import_parser)
    import_parser.add_argument("--move", action="store_true", help="Move files instead of copying.")
    import_parser.add_argument("--limit", type=int, default=20, help="Rows to show after import. Use 0 to show all.")
    add_conversion_arg(import_parser)

    resort_parser = subparsers.add_parser("resort", help="Re-sort an existing archive using embedded metadata.")
    resort_parser.add_argument("--archive", required=True, help="Archive folder to re-sort.")

    reset_journal_parser = subparsers.add_parser("reset-journal", help="Clear duplicate/import journal for an archive.")
    reset_journal_parser.add_argument("--archive", required=True, help="Archive folder.")

    clear_staging_parser = subparsers.add_parser("clear-staging", help="Remove old temporary iPhone staging folders.")
    clear_staging_parser.add_argument("--archive", required=True, help="Archive folder.")

    history_parser = subparsers.add_parser("history-json", help="Print import history as JSON.")
    history_parser.add_argument("--archive", required=True, help="Archive folder.")
    history_parser.add_argument("--limit", type=int, default=50)

    iphone_list_parser = subparsers.add_parser("iphone-list", help="List files visible on a connected iPhone.")
    iphone_list_parser.add_argument("--timeout", type=int, default=60)
    iphone_list_parser.add_argument("--limit", type=int, default=30)

    iphone_debug_parser = subparsers.add_parser("iphone-debug", help="Show ImageCaptureCore device diagnostics.")
    iphone_debug_parser.add_argument("--timeout", type=int, default=10)

    iphone_ls_parser = subparsers.add_parser("iphone-ls", help="List a directory through AFC.")
    iphone_ls_parser.add_argument("--path", default="/")
    iphone_ls_parser.add_argument("--timeout", type=int, default=10)

    iphone_first_parser = subparsers.add_parser("iphone-first", help="Show the first media path found through AFC.")
    iphone_first_parser.add_argument("--timeout", type=int, default=10)

    iphone_import_parser = subparsers.add_parser("iphone-import", help="Download files from iPhone and sort them into archive.")
    iphone_import_parser.add_argument("--dest", required=True, help="Archive destination folder.")
    iphone_import_parser.add_argument("--timeout", type=int, default=600)
    iphone_import_parser.add_argument("--limit", type=int, help="Optional import limit for testing.")
    iphone_import_parser.add_argument(
        "--full-check",
        action="store_true",
        help="Check all device files instead of skipping files already known in the import journal.",
    )
    add_media_filter_arg(iphone_import_parser)
    add_conversion_arg(iphone_import_parser)

    subparsers.add_parser("iphone-repair", help="Restart the macOS iPhone USB connection service.")

    android_list_parser = subparsers.add_parser("android-list", help="List files visible on a connected Android phone.")
    android_list_parser.add_argument("--limit", type=int, default=30)

    android_import_parser = subparsers.add_parser("android-import", help="Download files from Android and sort them into archive.")
    android_import_parser.add_argument("--dest", required=True, help="Archive destination folder.")
    android_import_parser.add_argument("--limit", type=int, help="Optional import limit for testing.")
    android_import_parser.add_argument(
        "--full-check",
        action="store_true",
        help="Check all device files instead of skipping files already known in the import journal.",
    )
    add_media_filter_arg(android_import_parser)
    add_conversion_arg(android_import_parser)

    args = parser.parse_args(argv)

    if args.command == "iphone-list":
        try:
            print(list_iphone_files(timeout=args.timeout, limit=args.limit))
            return 0
        except IPhoneImportError as exc:
            print(str(exc))
            return 1

    if args.command == "resort":
        summary = resort_archive(Path(args.archive))
        print_summary(summary)
        return 0

    if args.command == "reset-journal":
        db_path = reset_import_journal(Path(args.archive))
        print(f"Import journal cleared: {db_path}")
        return 0

    if args.command == "clear-staging":
        staging_path = clear_staging(Path(args.archive))
        print(f"Staging cleared: {staging_path}")
        return 0

    if args.command == "history-json":
        with ImportStore(Path(args.archive)) as store:
            sessions = store.list_sessions(limit=args.limit)
        print(
            json.dumps(
                [
                    {
                        "id": session.id,
                        "started_at": session.started_at,
                        "finished_at": session.finished_at,
                        "source_type": session.source_type,
                        "source_path": session.source_path,
                        "archive_path": session.archive_path,
                        "status": session.status,
                        "media_found": session.media_found,
                        "new_files": session.new_files,
                        "duplicates": session.duplicates,
                        "imported": session.imported,
                        "error_text": session.error_text,
                    }
                    for session in sessions
                ],
                ensure_ascii=False,
            ),
            flush=True,
        )
        return 0

    if args.command == "iphone-debug":
        try:
            print(debug_iphone_devices(timeout=args.timeout))
            return 0
        except IPhoneImportError as exc:
            print(str(exc))
            return 1

    if args.command == "iphone-ls":
        try:
            print(list_iphone_directory(args.path, timeout=args.timeout))
            return 0
        except IPhoneImportError as exc:
            print(str(exc))
            return 1

    if args.command == "iphone-first":
        try:
            print(first_iphone_media_path(timeout=args.timeout))
            return 0
        except IPhoneImportError as exc:
            print(str(exc))
            return 1

    if args.command == "iphone-import":
        try:
            helper_output, summary = import_from_iphone(
                Path(args.dest),
                timeout=args.timeout,
                limit=args.limit,
                media_filter=args.media,
                conversion_mode=args.conversion,
                progress=print_progress,
                full_check=args.full_check,
            )
            if helper_output:
                print(helper_output)
                print()
            print_summary(summary)
            return 0
        except IPhoneImportError as exc:
            print(str(exc))
            return 1

    if args.command == "iphone-repair":
        try:
            print(repair_iphone_connection())
            return 0
        except IPhoneImportError as exc:
            print(str(exc))
            return 1

    if args.command == "android-list":
        try:
            print(list_android_files(limit=args.limit))
            return 0
        except AndroidImportError as exc:
            print(str(exc))
            return 1

    if args.command == "android-import":
        try:
            helper_output, summary = import_from_android(
                Path(args.dest),
                limit=args.limit,
                media_filter=args.media,
                conversion_mode=args.conversion,
                progress=print_progress,
                full_check=args.full_check,
            )
            if helper_output:
                print(helper_output)
                print()
            print_summary(summary)
            return 0
        except AndroidImportError as exc:
            print(str(exc))
            return 1

    source = Path(args.source)
    dest = Path(args.dest)
    if not source.exists() or not source.is_dir():
        parser.error(f"source folder does not exist: {source}")

    if args.command == "scan":
        items, summary = build_plan(source, dest, media_filter=args.media, progress=print_progress)
        print_summary(summary)
        print_items(items, limit=args.limit)
        return 0

    if args.command == "import":
        items, summary = import_files(
            source,
            dest,
            move=args.move,
            media_filter=args.media,
            conversion_mode=args.conversion,
            progress=print_progress,
        )
        print_summary(summary)
        print_items(items, limit=args.limit)
        return 0

    parser.error("unknown command")
    return 2


def add_common_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--source", required=True, help="Folder with source media files.")
    parser.add_argument("--dest", required=True, help="Archive destination folder.")
    add_media_filter_arg(parser)


def print_progress(message: str) -> None:
    try:
        sys.stdout.write(str(message))
        sys.stdout.write("\n")
        sys.stdout.flush()
    except (BrokenPipeError, OSError, ValueError):
        pass


def add_media_filter_arg(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--media", choices=("all", "photo", "video"), default="all", help="Media type to import.")


def add_conversion_arg(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--conversion",
        choices=("original", "heic_jpeg"),
        default="original",
        help="Optional post-import conversion mode.",
    )


def print_summary(summary: object) -> None:
    print("Мой Архив summary")
    for key in ("total_seen", "media_found", "ignored", "new_files", "duplicates", "imported"):
        if hasattr(summary, key):
            print(f"  {key}: {getattr(summary, key)}")


def print_items(items: list[ImportPlanItem], *, limit: int) -> None:
    if not items:
        return

    shown = items if limit == 0 else items[:limit]
    print()
    print("Files")
    for item in shown:
        media = item.media
        print(
            f"  [{item.status}] {media.kind} "
            f"{media.created_at:%Y-%m-%d %H:%M:%S} "
            f"({media.date_source}) "
            f"{media.path.name} -> {item.destination}"
        )

    if limit and len(items) > limit:
        print(f"  ... {len(items) - limit} more")


if __name__ == "__main__":
    raise SystemExit(main())
