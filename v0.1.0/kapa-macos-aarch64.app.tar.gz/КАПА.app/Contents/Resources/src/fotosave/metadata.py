from __future__ import annotations

import platform
import subprocess
import os
from datetime import datetime
from pathlib import Path


PROJECT_ROOT = Path(os.environ.get("FOTOSAVE_PROJECT_ROOT", Path(__file__).resolve().parents[2])).resolve()
MEDIA_DATE_SOURCE = PROJECT_ROOT / "tools" / "FotoSaveMediaDate.swift"
MEDIA_DATE_BINARY = PROJECT_ROOT / "bin" / "FotoSaveMediaDate"

MACOS_DATE_KEYS = (
    "kMDItemEXIFDateTimeOriginal",
    "kMDItemContentCreationDate",
    "kMDItemFSCreationDate",
)


def media_created_at(path: Path) -> tuple[datetime, str]:
    if platform.system() == "Darwin":
        helper_date = _media_date_helper(path)
        if helper_date is not None:
            return helper_date

        sips_date = _sips_creation_date(path)
        if sips_date is not None:
            return sips_date

        mac_date = _macos_metadata_date(path)
        if mac_date is not None:
            return mac_date

    stat = path.stat()
    return datetime.fromtimestamp(stat.st_mtime), "filesystem_mtime"


def _macos_metadata_date(path: Path) -> tuple[datetime, str] | None:
    for key in MACOS_DATE_KEYS:
        value = _mdls_value(path, key)
        parsed = _parse_macos_date(value)
        if parsed is not None:
            return parsed, key
    return None


def _media_date_helper(path: Path) -> tuple[datetime, str] | None:
    if not _ensure_media_date_helper():
        return None

    try:
        result = subprocess.run(
            [str(MEDIA_DATE_BINARY), str(path)],
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
    except OSError:
        return None

    if result.returncode != 0:
        return None

    line = result.stdout.strip()
    if ": " not in line:
        return None
    source, value = line.split(": ", 1)
    parsed = _parse_helper_date(value)
    if parsed is not None:
        return parsed, source
    return None


def _ensure_media_date_helper() -> bool:
    if not MEDIA_DATE_SOURCE.exists():
        return False
    if MEDIA_DATE_BINARY.exists() and MEDIA_DATE_BINARY.stat().st_mtime >= MEDIA_DATE_SOURCE.stat().st_mtime:
        return True

    MEDIA_DATE_BINARY.parent.mkdir(parents=True, exist_ok=True)
    cache_root = PROJECT_ROOT / ".build"
    clang_cache = cache_root / "clang-module-cache"
    swift_cache = cache_root / "swift-module-cache"
    clang_cache.mkdir(parents=True, exist_ok=True)
    swift_cache.mkdir(parents=True, exist_ok=True)

    env = os.environ.copy()
    env["CLANG_MODULE_CACHE_PATH"] = str(clang_cache)
    env["SWIFT_MODULE_CACHE_PATH"] = str(swift_cache)

    result = subprocess.run(
        [
            "swiftc",
            str(MEDIA_DATE_SOURCE),
            "-o",
            str(MEDIA_DATE_BINARY),
            "-framework",
            "Foundation",
            "-framework",
            "ImageIO",
            "-framework",
            "AVFoundation",
        ],
        cwd=PROJECT_ROOT,
        env=env,
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        text=True,
    )
    return result.returncode == 0


def _sips_creation_date(path: Path) -> tuple[datetime, str] | None:
    if path.suffix.lower() not in {".heic", ".heif", ".jpg", ".jpeg", ".png", ".dng", ".tif", ".tiff"}:
        return None

    try:
        result = subprocess.run(
            ["sips", "-g", "creation", str(path)],
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
    except OSError:
        return None

    if result.returncode != 0:
        return None

    for line in result.stdout.splitlines():
        line = line.strip()
        if not line.startswith("creation:"):
            continue
        value = line.removeprefix("creation:").strip()
        parsed = _parse_sips_date(value)
        if parsed is not None:
            return parsed, "sips_creation"
    return None


def _mdls_value(path: Path, key: str) -> str | None:
    try:
        result = subprocess.run(
            ["mdls", "-raw", "-name", key, str(path)],
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
        )
    except OSError:
        return None

    if result.returncode != 0:
        return None

    value = result.stdout.strip()
    if not value or value == "(null)":
        return None
    return value


def _parse_macos_date(value: str | None) -> datetime | None:
    if value is None:
        return None

    for fmt in ("%Y-%m-%d %H:%M:%S %z", "%Y-%m-%d %H:%M:%S"):
        try:
            parsed = datetime.strptime(value, fmt)
        except ValueError:
            continue
        return parsed.replace(tzinfo=None)

    return None


def _parse_helper_date(value: str | None) -> datetime | None:
    if value is None:
        return None

    try:
        return datetime.strptime(value, "%Y-%m-%d %H:%M:%S")
    except ValueError:
        return None


def _parse_sips_date(value: str | None) -> datetime | None:
    if value is None:
        return None

    for fmt in ("%Y:%m:%d %H:%M:%S", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue
    return None
