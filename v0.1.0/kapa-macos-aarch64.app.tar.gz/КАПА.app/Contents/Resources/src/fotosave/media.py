from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path


PHOTO_EXTENSIONS = {
    ".heic",
    ".heif",
    ".jpg",
    ".jpeg",
    ".png",
    ".webp",
    ".dng",
    ".tif",
    ".tiff",
}

VIDEO_EXTENSIONS = {
    ".mov",
    ".mp4",
    ".m4v",
}

IGNORED_EXTENSIONS = {
    ".aae",
    ".thm",
    ".tmp",
    ".plist",
    ".db",
}

MEDIA_EXTENSIONS = PHOTO_EXTENSIONS | VIDEO_EXTENSIONS

RUSSIAN_MONTHS = {
    1: "Январь",
    2: "Февраль",
    3: "Март",
    4: "Апрель",
    5: "Май",
    6: "Июнь",
    7: "Июль",
    8: "Август",
    9: "Сентябрь",
    10: "Октябрь",
    11: "Ноябрь",
    12: "Декабрь",
}


@dataclass(frozen=True)
class MediaFile:
    path: Path
    kind: str
    size: int
    created_at: datetime
    date_source: str

    @property
    def year_folder(self) -> str:
        return f"{self.created_at.year:04d}"

    @property
    def month_folder(self) -> str:
        return RUSSIAN_MONTHS[self.created_at.month]

    @property
    def day_folder(self) -> str:
        return self.created_at.strftime("%Y-%m-%d")


def classify_file(path: Path) -> str | None:
    suffix = path.suffix.lower()
    if suffix in PHOTO_EXTENSIONS:
        return "photo"
    if suffix in VIDEO_EXTENSIONS:
        return "video"
    return None


def should_ignore(path: Path) -> bool:
    return path.suffix.lower() in IGNORED_EXTENSIONS
