from __future__ import annotations

import hashlib
import shutil
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from .converter import convert_heic_to_jpeg, is_heic
from .media import MediaFile, classify_file, should_ignore
from .metadata import media_created_at
from .store import ImportStore

MediaFilter = str
ConversionMode = str
MEDIA_FILTERS = {"all", "photo", "video"}
CONVERSION_MODES = {"original", "heic_jpeg"}


@dataclass(frozen=True)
class ImportPlanItem:
    media: MediaFile
    destination: Path
    sha256: str
    fingerprint: str
    status: str


@dataclass(frozen=True)
class ImportSummary:
    total_seen: int
    media_found: int
    ignored: int
    new_files: int
    duplicates: int
    imported: int


ProgressCallback = Callable[[str], None]
CancelCheck = Callable[[], bool]


class ImportCancelled(RuntimeError):
    pass


def build_plan(
    source: Path,
    dest: Path,
    *,
    media_filter: MediaFilter = "all",
    progress: ProgressCallback | None = None,
    cancel_check: CancelCheck | None = None,
) -> tuple[list[ImportPlanItem], ImportSummary]:
    source = source.expanduser().resolve()
    dest = dest.expanduser().resolve()

    total_seen = 0
    ignored = 0
    media_files: list[MediaFile] = []
    if media_filter not in MEDIA_FILTERS:
        raise ValueError(f"Unknown media_filter: {media_filter}")

    if progress:
        progress(f"Сканирую папку: {source}")

    for path in sorted(source.rglob("*")):
        if cancel_check and cancel_check():
            raise ImportCancelled("Импорт остановлен пользователем.")
        if not path.is_file():
            continue
        if path.name.startswith(".kapa-known-"):
            continue
        total_seen += 1
        if should_ignore(path):
            ignored += 1
            continue

        kind = classify_file(path)
        if kind is None:
            ignored += 1
            continue
        if media_filter != "all" and kind != media_filter:
            ignored += 1
            continue

        created_at, date_source = media_created_at(path)
        media_files.append(
            MediaFile(
                path=path,
                kind=kind,
                size=path.stat().st_size,
                created_at=created_at,
                date_source=date_source,
            )
        )
        if progress and len(media_files) % 25 == 0:
            progress(f"Найдено медиа-файлов: {len(media_files)}")

    if progress:
        progress(
            f"Сканирование готово: файлов {total_seen}, медиа {len(media_files)}, "
            f"пропущено {ignored}. Проверяю дубликаты..."
        )

    items: list[ImportPlanItem] = []
    duplicates = 0
    with ImportStore(dest) as store:
        for index, media in enumerate(media_files, start=1):
            if cancel_check and cancel_check():
                raise ImportCancelled("Импорт остановлен пользователем.")
            sha256 = file_sha256(media.path)
            fingerprint = make_fingerprint(media, sha256)
            status = "new"
            if store.has_fingerprint(fingerprint):
                duplicates += 1
                status = "duplicate"

            items.append(
                ImportPlanItem(
                    media=media,
                    destination=target_path(dest, media),
                    sha256=sha256,
                    fingerprint=fingerprint,
                    status=status,
                )
            )
            if progress and (index % 25 == 0 or index == len(media_files)):
                progress(f"Проверяю дубликаты: {index}/{len(media_files)}")

    if progress:
        progress(
            f"План готов: фото и видео {len(media_files)}, новых {len(media_files) - duplicates}, "
            f"дубликатов {duplicates}."
        )

    summary = ImportSummary(
        total_seen=total_seen,
        media_found=len(media_files),
        ignored=ignored,
        new_files=len(media_files) - duplicates,
        duplicates=duplicates,
        imported=0,
    )
    return items, summary


def import_files(
    source: Path,
    dest: Path,
    *,
    move: bool = False,
    media_filter: MediaFilter = "all",
    conversion_mode: ConversionMode = "original",
    progress: ProgressCallback | None = None,
    cancel_check: CancelCheck | None = None,
    source_type: str = "folder",
    session_id: int | None = None,
    staging_path: Path | None = None,
    finish_session: bool = True,
) -> tuple[list[ImportPlanItem], ImportSummary]:
    source = source.expanduser().resolve()
    dest = dest.expanduser().resolve()
    created_session = False
    active_session_id = session_id
    summary = ImportSummary(0, 0, 0, 0, 0, 0)
    imported = 0

    if active_session_id is None:
        with ImportStore(dest) as store:
            active_session_id = store.create_session(
                source_type=source_type,
                source_path=source,
                archive_path=dest,
                staging_path=staging_path or "",
            )
        created_session = True

    try:
        if conversion_mode not in CONVERSION_MODES:
            raise ValueError(f"Unknown conversion_mode: {conversion_mode}")

        items, summary = build_plan(source, dest, media_filter=media_filter, progress=progress, cancel_check=cancel_check)
        imported = 0
        total_bytes = sum(item.media.size for item in items if item.status == "new")
        copied_bytes = 0
        started_at = time.monotonic()

        if progress:
            progress(f"К импорту: {summary.new_files} файлов, {format_size(total_bytes)}.")

        with ImportStore(dest) as store:
            stable_source_type = stable_import_source_type(source_type)
            for item in items:
                if cancel_check and cancel_check():
                    raise ImportCancelled("Импорт остановлен пользователем.")
                source_key = make_source_key(
                    source_type=stable_source_type,
                    source_root=source,
                    staging_path=staging_path,
                    media_path=item.media.path,
                    size=item.media.size,
                )
                if item.status != "new":
                    store.attach_source_key(
                        fingerprint=item.fingerprint,
                        source_type=stable_source_type,
                        source_key=source_key,
                        source_path=item.media.path,
                    )
                    if progress:
                        progress(f"Пропускаю дубликат: {item.media.path.name}")
                    if active_session_id is not None:
                        store.record_session_file(
                            session_id=active_session_id,
                            source_path=item.media.path,
                            dest_path=item.destination,
                            file_name=item.media.path.name,
                            kind=item.media.kind,
                            status="duplicate",
                            date_taken=f"{item.media.created_at:%Y-%m-%d %H:%M:%S}",
                            date_source=item.media.date_source,
                            size=item.media.size,
                            sha256=item.sha256,
                        )
                    continue

                final_destination = unique_destination(item.destination, item.sha256)
                final_destination.parent.mkdir(parents=True, exist_ok=True)

                if progress:
                    action = "Перемещаю" if move else "Копирую"
                    progress(f"{action}: {item.media.path.name} -> {final_destination.parent}")

                if move:
                    shutil.move(str(item.media.path), str(final_destination))
                else:
                    shutil.copy2(item.media.path, final_destination)

                final_size = item.media.size
                final_name = item.media.path.name
                if conversion_mode == "heic_jpeg" and item.media.kind == "photo" and is_heic(final_destination):
                    if progress:
                        progress(f"Конвертирую HEIC в JPG: {final_destination.name}")
                    converted_destination = convert_heic_to_jpeg(final_destination)
                    if converted_destination is not None:
                        final_destination = converted_destination
                        final_size = final_destination.stat().st_size
                        final_name = final_destination.name
                        if progress:
                            progress(f"Готов JPG: {final_destination.name}")
                    elif progress:
                        progress(f"Не удалось конвертировать HEIC, оставляю оригинал: {final_destination.name}")

                store.record(
                    fingerprint=item.fingerprint,
                    source_path=item.media.path,
                    dest_path=final_destination,
                    size=final_size,
                    sha256=item.sha256,
                    source_type=stable_source_type,
                    source_key=source_key,
                )
                if active_session_id is not None:
                    store.record_session_file(
                            session_id=active_session_id,
                            source_path=item.media.path,
                            dest_path=final_destination,
                            file_name=final_name,
                            kind=item.media.kind,
                            status="imported",
                            date_taken=f"{item.media.created_at:%Y-%m-%d %H:%M:%S}",
                            date_source=item.media.date_source,
                            size=final_size,
                            sha256=item.sha256,
                        )
                imported += 1
                copied_bytes += item.media.size
                if progress:
                    progress(
                        "Прогресс: "
                        f"{imported}/{summary.new_files} файлов, "
                        f"{progress_percent(copied_bytes, total_bytes)}, "
                        f"{format_size(copied_bytes)} из {format_size(total_bytes)}, "
                        f"скорость {format_size(speed_bytes_per_second(copied_bytes, started_at))}/с, "
                        f"осталось {format_eta(copied_bytes, total_bytes, started_at)}."
                    )

        final_summary = ImportSummary(
            total_seen=summary.total_seen,
            media_found=summary.media_found,
            ignored=summary.ignored,
            new_files=summary.new_files,
            duplicates=summary.duplicates,
            imported=imported,
        )
        if finish_session and created_session and active_session_id is not None:
            with ImportStore(dest) as store:
                store.finish_session(active_session_id, status="completed", summary=final_summary)
        return items, final_summary
    except ImportCancelled as exc:
        if finish_session and created_session and active_session_id is not None:
            partial_summary = ImportSummary(
                summary.total_seen,
                summary.media_found,
                summary.ignored,
                summary.new_files,
                summary.duplicates,
                imported,
            )
            with ImportStore(dest) as store:
                store.finish_session(active_session_id, status="stopped", summary=partial_summary, error_text=str(exc))
        raise
    except Exception as exc:
        if finish_session and created_session and active_session_id is not None:
            partial_summary = ImportSummary(
                summary.total_seen,
                summary.media_found,
                summary.ignored,
                summary.new_files,
                summary.duplicates,
                imported,
            )
            with ImportStore(dest) as store:
                store.finish_session(active_session_id, status="error", summary=partial_summary, error_text=str(exc))
        raise


def resort_archive(archive: Path) -> ImportSummary:
    archive = archive.expanduser().resolve()
    moved = 0
    total_seen = 0
    media_found = 0
    ignored = 0

    for path in sorted(archive.rglob("*")):
        if not path.is_file():
            continue
        if ".fotosave" in path.parts:
            continue

        total_seen += 1
        if should_ignore(path):
            ignored += 1
            continue

        kind = classify_file(path)
        if kind is None:
            ignored += 1
            continue

        media_found += 1
        created_at, date_source = media_created_at(path)
        media = MediaFile(
            path=path,
            kind=kind,
            size=path.stat().st_size,
            created_at=created_at,
            date_source=date_source,
        )
        desired = target_path(archive, media)
        if path.resolve() == desired.resolve():
            continue

        final_destination = unique_destination(desired, file_sha256(path))
        final_destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(path), str(final_destination))
        moved += 1

    return ImportSummary(
        total_seen=total_seen,
        media_found=media_found,
        ignored=ignored,
        new_files=0,
        duplicates=0,
        imported=moved,
    )


def reset_import_journal(archive: Path) -> Path:
    archive = archive.expanduser().resolve()
    db_path = archive / ".fotosave" / "imports.sqlite3"
    if db_path.exists():
        db_path.unlink()
    return db_path


def clear_staging(archive: Path) -> Path:
    archive = archive.expanduser().resolve()
    archive_key = hashlib.sha256(str(archive).encode("utf-8")).hexdigest()[:16]
    staging_paths = [
        archive / ".fotosave" / "iphone-staging",
        Path(tempfile.gettempdir()) / "fotosave" / "iphone-staging" / archive_key,
        Path(tempfile.gettempdir()) / "moy-archive" / "android-staging" / archive_key,
    ]
    for staging_path in staging_paths:
        if staging_path.exists():
            shutil.rmtree(staging_path)
    return archive / ".fotosave"


def target_path(dest: Path, media: MediaFile) -> Path:
    return dest / media.year_folder / media.month_folder / media.day_folder / media.path.name


def unique_destination(path: Path, sha256: str) -> Path:
    if not path.exists():
        return path

    if file_sha256(path) == sha256:
        return path

    stem = path.stem
    suffix = path.suffix
    parent = path.parent
    index = 1
    while True:
        candidate = parent / f"{stem}_{index}{suffix}"
        if not candidate.exists():
            return candidate
        if file_sha256(candidate) == sha256:
            return candidate
        index += 1


def make_fingerprint(media: MediaFile, sha256: str) -> str:
    return f"{media.size}:{sha256}"


def stable_import_source_type(source_type: str) -> str:
    if source_type.startswith("iphone"):
        return "iphone"
    if source_type.startswith("android"):
        return "android"
    return source_type or "folder"


def make_source_key(
    *,
    source_type: str,
    source_root: Path,
    staging_path: Path | None,
    media_path: Path,
    size: int,
) -> str:
    if source_type in {"iphone", "android"} and staging_path is not None:
        try:
            relative = media_path.resolve().relative_to(staging_path.resolve()).as_posix()
        except ValueError:
            relative = media_path.name
        return format_source_key(f"/{relative}", size)

    try:
        relative = media_path.resolve().relative_to(source_root.resolve()).as_posix()
    except ValueError:
        relative = str(media_path.resolve()).replace("\\", "/")
    return format_source_key(f"/{relative}", size)


def format_source_key(path: str, size: int) -> str:
    normalized = path.replace("\\", "/").strip()
    if not normalized.startswith("/"):
        normalized = "/" + normalized
    return f"{normalized.lower()}|{max(int(size), 0)}"


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def speed_bytes_per_second(done_bytes: int, started_at: float) -> int:
    elapsed = max(time.monotonic() - started_at, 0.001)
    return int(done_bytes / elapsed)


def progress_percent(done_bytes: int, total_bytes: int) -> str:
    if total_bytes <= 0:
        return "0%"
    return f"{min(done_bytes / total_bytes * 100, 100):.1f}%"


def format_eta(done_bytes: int, total_bytes: int, started_at: float) -> str:
    if total_bytes <= 0:
        return "неизвестно"
    if done_bytes <= 0:
        return "считаю..."
    speed = speed_bytes_per_second(done_bytes, started_at)
    if speed <= 0:
        return "считаю..."
    remaining = max(total_bytes - done_bytes, 0)
    return format_duration(int(remaining / speed))


def format_duration(seconds: int) -> str:
    if seconds <= 0:
        return "меньше минуты"
    minutes, sec = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    if hours:
        return f"{hours} ч {minutes} мин"
    if minutes:
        return f"{minutes} мин {sec} сек"
    return f"{sec} сек"


def format_size(size: int) -> str:
    if size >= 1024 * 1024 * 1024:
        return f"{size / (1024 * 1024 * 1024):.1f} ГБ"
    if size >= 1024 * 1024:
        return f"{size / (1024 * 1024):.1f} МБ"
    if size >= 1024:
        return f"{size / 1024:.1f} КБ"
    return f"{size} Б"
