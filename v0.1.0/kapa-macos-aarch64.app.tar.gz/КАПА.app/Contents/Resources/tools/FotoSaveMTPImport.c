#include <libmtp.h>

#include <ctype.h>
#include <errno.h>
#include <libgen.h>
#include <limits.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include <utime.h>

typedef struct folder_path {
    uint32_t id;
    uint32_t parent_id;
    char *name;
    char *path;
    struct folder_path *next;
} folder_path_t;

typedef struct media_item {
    uint32_t id;
    uint64_t size;
    time_t mtime;
    char *path;
} media_item_t;

typedef struct media_plan {
    media_item_t *items;
    size_t count;
    size_t capacity;
    uint64_t bytes;
} media_plan_t;

static const char *g_command = NULL;
static const char *g_output = NULL;
static const char *g_media_filter = "all";
static int g_limit = 0;
static int g_seen = 0;
static int g_media = 0;
static int g_downloaded = 0;
static int g_skipped = 0;
static int g_failed = 0;
static uint64_t g_total_size = 0;
static uint16_t g_vendor_id = 0;
static uint16_t g_product_id = 0;

static void handle_open_timeout(int signal_number) {
    (void)signal_number;
    fprintf(stderr, "ERROR: MTP_OPEN_TIMEOUT\n");
    fprintf(stderr, "Android найден, но MTP-сессия слишком долго не открывается. Переподключите кабель и выберите «Передача файлов / MTP».\n");
    exit(3);
}

static void usage(void) {
    fprintf(stderr,
            "Usage:\n"
            "  FotoSaveMTPImport list [--limit 30] [--media all|photo|video]\n"
            "  FotoSaveMTPImport download --output /path/to/folder [--limit 0] [--media all|photo|video]\n");
}

static int parse_int(const char *value, int *out) {
    char *end = NULL;
    errno = 0;
    long parsed = strtol(value, &end, 10);
    if (errno != 0 || end == value || *end != '\0' || parsed < 0 || parsed > INT_MAX) {
        return -1;
    }
    *out = (int)parsed;
    return 0;
}

static int is_media_file(const char *name) {
    const char *dot = strrchr(name, '.');
    if (!dot || !dot[1]) {
        return 0;
    }

    char ext[16];
    size_t len = strlen(dot + 1);
    if (len >= sizeof(ext)) {
        return 0;
    }
    for (size_t i = 0; i < len; i++) {
        ext[i] = (char)tolower((unsigned char)dot[1 + i]);
    }
    ext[len] = '\0';

    const char *allowed[] = {
        "heic", "heif", "jpg", "jpeg", "png", "dng", "tif", "tiff",
        "mov", "mp4", "m4v", NULL
    };
    for (int i = 0; allowed[i]; i++) {
        if (strcmp(ext, allowed[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

static int is_photo_file(const char *name) {
    const char *dot = strrchr(name, '.');
    if (!dot || !dot[1]) {
        return 0;
    }
    char ext[16];
    size_t len = strlen(dot + 1);
    if (len >= sizeof(ext)) {
        return 0;
    }
    for (size_t i = 0; i < len; i++) {
        ext[i] = (char)tolower((unsigned char)dot[1 + i]);
    }
    ext[len] = '\0';
    const char *allowed[] = {"heic", "heif", "jpg", "jpeg", "png", "dng", "tif", "tiff", NULL};
    for (int i = 0; allowed[i]; i++) {
        if (strcmp(ext, allowed[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

static int is_video_file(const char *name) {
    const char *dot = strrchr(name, '.');
    if (!dot || !dot[1]) {
        return 0;
    }
    char ext[16];
    size_t len = strlen(dot + 1);
    if (len >= sizeof(ext)) {
        return 0;
    }
    for (size_t i = 0; i < len; i++) {
        ext[i] = (char)tolower((unsigned char)dot[1 + i]);
    }
    ext[len] = '\0';
    const char *allowed[] = {"mov", "mp4", "m4v", NULL};
    for (int i = 0; allowed[i]; i++) {
        if (strcmp(ext, allowed[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

static int matches_media_filter(const char *path) {
    if (strcmp(g_media_filter, "photo") == 0) {
        return is_photo_file(path);
    }
    if (strcmp(g_media_filter, "video") == 0) {
        return is_video_file(path);
    }
    return is_media_file(path);
}

static int is_user_media_path(const char *path) {
    if (strstr(path, "/Android/data/") || strstr(path, "/Android/obb/")) {
        return 0;
    }
    if (strstr(path, "/.thumbnails/") || strstr(path, "/.thumbnail/")) {
        return 0;
    }
    return matches_media_filter(path);
}

static void print_safe_path(FILE *stream, const char *path) {
    for (const unsigned char *p = (const unsigned char *)path; *p; p++) {
        if (*p >= 32 && *p < 127) {
            fputc(*p, stream);
        } else {
            fprintf(stream, "\\x%02x", *p);
        }
    }
}

static int mkdir_p(const char *path) {
    char tmp[PATH_MAX];
    size_t len = strlen(path);
    if (len == 0 || len >= sizeof(tmp)) {
        return -1;
    }
    strcpy(tmp, path);
    if (tmp[len - 1] == '/') {
        tmp[len - 1] = '\0';
    }
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = '\0';
            if (mkdir(tmp, 0755) != 0 && errno != EEXIST) {
                return -1;
            }
            *p = '/';
        }
    }
    if (mkdir(tmp, 0755) != 0 && errno != EEXIST) {
        return -1;
    }
    return 0;
}

static int ensure_parent_dir(const char *path) {
    char copy[PATH_MAX];
    if (strlen(path) >= sizeof(copy)) {
        return -1;
    }
    strcpy(copy, path);
    char *dir = dirname(copy);
    return mkdir_p(dir);
}

static void apply_mtime(const char *local_path, time_t mtime) {
    if (mtime <= 0) {
        return;
    }
    struct utimbuf times;
    times.actime = mtime;
    times.modtime = mtime;
    utime(local_path, &times);
}

static uint64_t local_file_size(const char *path) {
    struct stat st;
    if (stat(path, &st) != 0 || !S_ISREG(st.st_mode)) {
        return UINT64_MAX;
    }
    return (uint64_t)st.st_size;
}

static char *join_path(const char *parent, const char *name) {
    if (!parent || strcmp(parent, "/") == 0 || parent[0] == '\0') {
        size_t len = strlen(name) + 2;
        char *result = malloc(len);
        if (!result) {
            return NULL;
        }
        snprintf(result, len, "/%s", name);
        return result;
    }

    size_t len = strlen(parent) + strlen(name) + 2;
    char *result = malloc(len);
    if (!result) {
        return NULL;
    }
    snprintf(result, len, "%s/%s", parent, name);
    return result;
}

static folder_path_t *find_folder(folder_path_t *folders, uint32_t id) {
    for (folder_path_t *item = folders; item; item = item->next) {
        if (item->id == id) {
            return item;
        }
    }
    return NULL;
}

static void add_folder(folder_path_t **folders, const LIBMTP_folder_t *folder, const char *parent_path) {
    folder_path_t *item = calloc(1, sizeof(folder_path_t));
    if (!item) {
        return;
    }
    item->id = folder->folder_id;
    item->parent_id = folder->parent_id;
    item->name = strdup(folder->name ? folder->name : "");
    item->path = join_path(parent_path, item->name);
    item->next = *folders;
    *folders = item;

    for (LIBMTP_folder_t *child = folder->child; child; child = child->sibling) {
        add_folder(folders, child, item->path ? item->path : "/");
    }
}

static folder_path_t *build_folder_paths(LIBMTP_folder_t *roots) {
    folder_path_t *folders = NULL;
    for (LIBMTP_folder_t *folder = roots; folder; folder = folder->sibling) {
        add_folder(&folders, folder, "/");
    }
    return folders;
}

static void free_folder_paths(folder_path_t *folders) {
    while (folders) {
        folder_path_t *next = folders->next;
        free(folders->name);
        free(folders->path);
        free(folders);
        folders = next;
    }
}

static char *remote_path_for_file(folder_path_t *folders, const LIBMTP_file_t *file) {
    folder_path_t *parent = find_folder(folders, file->parent_id);
    const char *parent_path = parent && parent->path ? parent->path : "/";
    return join_path(parent_path, file->filename ? file->filename : "unnamed");
}

static void local_path_for_remote(const char *remote, char *out, size_t out_size) {
    const char *relative = remote;
    while (*relative == '/') {
        relative++;
    }
    snprintf(out, out_size, "%s/%s", g_output, relative);
}

static LIBMTP_mtpdevice_t *open_first_device(void) {
    LIBMTP_raw_device_t *raw_devices = NULL;
    int device_count = 0;
    LIBMTP_error_number_t detect = LIBMTP_Detect_Raw_Devices(&raw_devices, &device_count);

    if (detect != LIBMTP_ERROR_NONE || device_count < 1) {
        fprintf(stderr, "ERROR: MTP_DEVICE_NOT_FOUND\n");
        fprintf(stderr, "Подключите Android, разблокируйте экран и выберите «Передача файлов / MTP».\n");
        if (raw_devices) {
            free(raw_devices);
        }
        return NULL;
    }

    LIBMTP_mtpdevice_t *device = LIBMTP_Open_Raw_Device_Uncached(&raw_devices[0]);
    if (!device) {
        fprintf(stderr, "ERROR: MTP_OPEN_FAILED\n");
        fprintf(stderr, "Android найден, но MTP-сессия не открылась. Отключите кабель, подключите снова и подтвердите доступ к данным.\n");
        free(raw_devices);
        return NULL;
    }
    g_vendor_id = raw_devices[0].device_entry.vendor_id;
    g_product_id = raw_devices[0].device_entry.product_id;

    char *manufacturer = LIBMTP_Get_Manufacturername(device);
    char *model = LIBMTP_Get_Modelname(device);
    char *friendly = LIBMTP_Get_Friendlyname(device);
    printf("DEVICE: %s %s", manufacturer ? manufacturer : "Android", model ? model : "MTP");
    if (friendly && friendly[0]) {
        printf(" (%s)", friendly);
    }
    printf("\n");
    if (manufacturer) {
        free(manufacturer);
    }
    if (model) {
        free(model);
    }
    if (friendly) {
        free(friendly);
    }

    free(raw_devices);
    return device;
}

static int should_stop_for_limit(void) {
    return g_limit > 0 && g_media >= g_limit;
}

static int should_reset_after_success(void) {
    return g_vendor_id == 0x2717;
}

static void free_media_plan(media_plan_t *plan) {
    if (!plan) {
        return;
    }
    for (size_t i = 0; i < plan->count; i++) {
        free(plan->items[i].path);
    }
    free(plan->items);
    plan->items = NULL;
    plan->count = 0;
    plan->capacity = 0;
    plan->bytes = 0;
}

static int add_media_item(media_plan_t *plan, const LIBMTP_file_t *file, const char *remote_path) {
    if (g_limit > 0 && (int)plan->count >= g_limit) {
        return 0;
    }
    if (plan->count == plan->capacity) {
        size_t next_capacity = plan->capacity ? plan->capacity * 2 : 64;
        media_item_t *next = realloc(plan->items, next_capacity * sizeof(media_item_t));
        if (!next) {
            return -1;
        }
        plan->items = next;
        plan->capacity = next_capacity;
    }

    media_item_t *item = &plan->items[plan->count++];
    item->id = file->item_id;
    item->size = file->filesize;
    item->mtime = file->modificationdate;
    item->path = strdup(remote_path);
    if (!item->path) {
        plan->count--;
        return -1;
    }
    plan->bytes += file->filesize;
    return 0;
}

static int should_stop_for_plan(const media_plan_t *plan) {
    return g_limit > 0 && (int)plan->count >= g_limit;
}

static int collect_folder(LIBMTP_mtpdevice_t *device, uint32_t storage_id, uint32_t parent_id, const char *parent_path, media_plan_t *plan) {
    if (should_stop_for_plan(plan)) {
        return 0;
    }

    LIBMTP_file_t *children = LIBMTP_Get_Files_And_Folders(device, storage_id, parent_id);
    if (!children) {
        LIBMTP_Clear_Errorstack(device);
        return 0;
    }

    int status = 0;
    for (LIBMTP_file_t *item = children; item; item = item->next) {
        if (should_stop_for_plan(plan)) {
            break;
        }

        const char *name = item->filename && item->filename[0] ? item->filename : "unnamed";
        char *remote_path = join_path(parent_path, name);
        if (!remote_path) {
            g_failed++;
            status = 1;
            continue;
        }

        if (item->filetype == LIBMTP_FILETYPE_FOLDER) {
            status |= collect_folder(device, storage_id, item->item_id, remote_path, plan);
            free(remote_path);
            continue;
        }

        g_seen++;
        if (is_user_media_path(remote_path)) {
            if (add_media_item(plan, item, remote_path) != 0) {
                g_failed++;
                status = 1;
            }
        }
        free(remote_path);
    }

    LIBMTP_destroy_file_t(children);
    return status;
}

static int collect_storages(LIBMTP_mtpdevice_t *device, media_plan_t *plan) {
    int storage_status = LIBMTP_Get_Storage(device, LIBMTP_STORAGE_SORTBY_NOTSORTED);
    if (storage_status != 0) {
        fprintf(stderr, "WARNING: MTP_STORAGE_UNAVAILABLE\n");
        LIBMTP_Dump_Errorstack(device);
        LIBMTP_Clear_Errorstack(device);
        return 2;
    }

    if (!device->storage) {
        fprintf(stderr, "ERROR: MTP_STORAGE_LIST_EMPTY\n");
        return 2;
    }

    int status = 0;
    for (LIBMTP_devicestorage_t *storage = device->storage; storage; storage = storage->next) {
        if (should_stop_for_plan(plan)) {
            break;
        }
        const char *storage_name = storage->StorageDescription && storage->StorageDescription[0] ? storage->StorageDescription : "Storage";
        char *storage_path = join_path("/", storage_name);
        if (!storage_path) {
            g_failed++;
            status = 1;
            continue;
        }
        printf("STORAGE: id=%u path=", storage->id);
        print_safe_path(stdout, storage_path);
        printf("\n");
        status |= collect_folder(device, storage->id, LIBMTP_FILES_AND_FOLDERS_ROOT, storage_path, plan);
        free(storage_path);
    }

    return status;
}

static int download_planned_item(LIBMTP_mtpdevice_t *device, const media_item_t *item) {
    char local_path[PATH_MAX];
    local_path_for_remote(item->path, local_path, sizeof(local_path));

    printf("STARTED: ");
    print_safe_path(stdout, item->path);
    printf(" size=%llu\n", (unsigned long long)item->size);
    fflush(stdout);

    if (local_file_size(local_path) == item->size) {
        g_skipped++;
        printf("SKIPPED_EXISTING: ");
        print_safe_path(stdout, item->path);
        printf("\n");
        return 0;
    }

    if (ensure_parent_dir(local_path) != 0) {
        g_failed++;
        fprintf(stderr, "FAILED: cannot create parent folder for ");
        print_safe_path(stderr, local_path);
        fprintf(stderr, "\n");
        return 1;
    }

    int status = LIBMTP_Get_File_To_File(device, item->id, local_path, NULL, NULL);
    if (status != 0) {
        g_failed++;
        fprintf(stderr, "FAILED: ");
        print_safe_path(stderr, item->path);
        fprintf(stderr, "\n");
        LIBMTP_Dump_Errorstack(device);
        LIBMTP_Clear_Errorstack(device);
        return 1;
    }

    apply_mtime(local_path, item->mtime);
    g_downloaded++;
    printf("DOWNLOADED: ");
    print_safe_path(stdout, item->path);
    printf(" -> ");
    print_safe_path(stdout, local_path);
    printf("\n");
    fflush(stdout);
    return 0;
}

static int process_media_file(LIBMTP_mtpdevice_t *device, const LIBMTP_file_t *file, const char *remote_path) {
    g_media++;

    if (strcmp(g_command, "list") == 0) {
        printf("FILE: id=%u size=%llu mtime=%lld path=", file->item_id, (unsigned long long)file->filesize, (long long)file->modificationdate);
        print_safe_path(stdout, remote_path);
        printf("\n");
        return 0;
    }

    g_total_size += file->filesize;
    char local_path[PATH_MAX];
    local_path_for_remote(remote_path, local_path, sizeof(local_path));

    printf("STARTED: ");
    print_safe_path(stdout, remote_path);
    printf(" size=%llu\n", (unsigned long long)file->filesize);
    fflush(stdout);

    if (local_file_size(local_path) == file->filesize) {
        g_skipped++;
        printf("SKIPPED_EXISTING: ");
        print_safe_path(stdout, remote_path);
        printf("\n");
        return 0;
    }

    if (ensure_parent_dir(local_path) != 0) {
        g_failed++;
        fprintf(stderr, "FAILED: cannot create parent folder for ");
        print_safe_path(stderr, local_path);
        fprintf(stderr, "\n");
        return 1;
    }

    int status = LIBMTP_Get_File_To_File(device, file->item_id, local_path, NULL, NULL);
    if (status != 0) {
        g_failed++;
        fprintf(stderr, "FAILED: ");
        print_safe_path(stderr, remote_path);
        fprintf(stderr, "\n");
        LIBMTP_Dump_Errorstack(device);
        LIBMTP_Clear_Errorstack(device);
        return 1;
    }

    apply_mtime(local_path, file->modificationdate);
    g_downloaded++;
    printf("DOWNLOADED: ");
    print_safe_path(stdout, remote_path);
    printf(" -> ");
    print_safe_path(stdout, local_path);
    printf("\n");
    fflush(stdout);
    return 0;
}

static int traverse_folder(LIBMTP_mtpdevice_t *device, uint32_t storage_id, uint32_t parent_id, const char *parent_path) {
    if (should_stop_for_limit()) {
        return 0;
    }

    LIBMTP_file_t *children = LIBMTP_Get_Files_And_Folders(device, storage_id, parent_id);
    if (!children) {
        LIBMTP_Clear_Errorstack(device);
        return 0;
    }

    int status = 0;
    for (LIBMTP_file_t *item = children; item; item = item->next) {
        if (should_stop_for_limit()) {
            break;
        }

        const char *name = item->filename && item->filename[0] ? item->filename : "unnamed";
        char *remote_path = join_path(parent_path, name);
        if (!remote_path) {
            g_failed++;
            status = 1;
            continue;
        }

        if (item->filetype == LIBMTP_FILETYPE_FOLDER) {
            status |= traverse_folder(device, storage_id, item->item_id, remote_path);
            free(remote_path);
            continue;
        }

        g_seen++;
        if (is_user_media_path(remote_path)) {
            status |= process_media_file(device, item, remote_path);
        }
        free(remote_path);
    }

    LIBMTP_destroy_file_t(children);
    return status;
}

static int traverse_storages(LIBMTP_mtpdevice_t *device) {
    int storage_status = LIBMTP_Get_Storage(device, LIBMTP_STORAGE_SORTBY_NOTSORTED);
    if (storage_status != 0) {
        fprintf(stderr, "WARNING: MTP_STORAGE_UNAVAILABLE\n");
        LIBMTP_Dump_Errorstack(device);
        LIBMTP_Clear_Errorstack(device);
        return 2;
    }

    if (!device->storage) {
        fprintf(stderr, "ERROR: MTP_STORAGE_LIST_EMPTY\n");
        return 2;
    }

    int status = 0;
    for (LIBMTP_devicestorage_t *storage = device->storage; storage; storage = storage->next) {
        if (should_stop_for_limit()) {
            break;
        }
        const char *storage_name = storage->StorageDescription && storage->StorageDescription[0] ? storage->StorageDescription : "Storage";
        char *storage_path = join_path("/", storage_name);
        if (!storage_path) {
            g_failed++;
            status = 1;
            continue;
        }
        printf("STORAGE: id=%u path=", storage->id);
        print_safe_path(stdout, storage_path);
        printf("\n");
        status |= traverse_folder(device, storage->id, LIBMTP_FILES_AND_FOLDERS_ROOT, storage_path);
        free(storage_path);
    }

    return status;
}

static int run_list(LIBMTP_mtpdevice_t *device) {
    int status = traverse_storages(device);
    printf("DONE: seen=%d media=%d\n", g_seen, g_media);
    return status;
}

static int run_download(LIBMTP_mtpdevice_t *device) {
    if (!g_output) {
        fprintf(stderr, "ERROR: --output is required\n");
        return 2;
    }
    if (mkdir_p(g_output) != 0) {
        fprintf(stderr, "ERROR: cannot create output folder: %s\n", g_output);
        return 2;
    }

    media_plan_t plan = {0};
    int status = collect_storages(device, &plan);
    g_media = (int)plan.count;
    g_total_size = plan.bytes;
    printf("PLAN: media=%d bytes=%llu\n", g_media, (unsigned long long)g_total_size);
    fflush(stdout);

    if (status == 0) {
        for (size_t i = 0; i < plan.count; i++) {
            status |= download_planned_item(device, &plan.items[i]);
        }
    }

    printf("DONE: seen=%d media=%d downloaded=%d skipped_existing=%d failed=%d bytes=%llu\n",
           g_seen, g_media, g_downloaded, g_skipped, g_failed, (unsigned long long)g_total_size);
    free_media_plan(&plan);
    if (status != 0) {
        return status;
    }
    return g_failed > 0 ? 1 : 0;
}

int main(int argc, char **argv) {
    if (argc < 2) {
        usage();
        return 2;
    }

    g_command = argv[1];
    for (int i = 2; i < argc; i++) {
        if (strcmp(argv[i], "--limit") == 0 && i + 1 < argc) {
            if (parse_int(argv[++i], &g_limit) != 0) {
                fprintf(stderr, "Invalid --limit value\n");
                return 2;
            }
            continue;
        }
        if (strcmp(argv[i], "--output") == 0 && i + 1 < argc) {
            g_output = argv[++i];
            continue;
        }
        if (strcmp(argv[i], "--media") == 0 && i + 1 < argc) {
            g_media_filter = argv[++i];
            if (strcmp(g_media_filter, "all") != 0 && strcmp(g_media_filter, "photo") != 0 && strcmp(g_media_filter, "video") != 0) {
                fprintf(stderr, "Invalid --media value\n");
                return 2;
            }
            continue;
        }
        usage();
        return 2;
    }

    LIBMTP_Init();
    signal(SIGALRM, handle_open_timeout);
    alarm(45);
    LIBMTP_mtpdevice_t *device = open_first_device();
    alarm(0);
    if (!device) {
        return 1;
    }

    int status = 0;
    if (strcmp(g_command, "list") == 0) {
        status = run_list(device);
    } else if (strcmp(g_command, "download") == 0) {
        status = run_download(device);
    } else {
        usage();
        status = 2;
    }

    if (status == 0 && should_reset_after_success()) {
        fprintf(stderr, "INFO: Xiaomi/Redmi MTP cleanup reset VID=%04x PID=%04x\n", g_vendor_id, g_product_id);
        if (LIBMTP_Reset_Device(device) != 0) {
            fprintf(stderr, "WARNING: MTP_RESET_FAILED\n");
            LIBMTP_Dump_Errorstack(device);
            LIBMTP_Clear_Errorstack(device);
        }
    }

    LIBMTP_Release_Device(device);
    return status;
}
