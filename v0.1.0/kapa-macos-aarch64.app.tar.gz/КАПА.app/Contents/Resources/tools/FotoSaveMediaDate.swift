import AVFoundation
import Foundation
import ImageIO

func printUsage() -> Never {
    fputs("Usage: FotoSaveMediaDate /path/to/media\n", stderr)
    exit(64)
}

guard CommandLine.arguments.count == 2 else {
    printUsage()
}

let url = URL(fileURLWithPath: CommandLine.arguments[1])
let ext = url.pathExtension.lowercased()

let dateFormatter = DateFormatter()
dateFormatter.locale = Locale(identifier: "en_US_POSIX")
dateFormatter.timeZone = TimeZone(secondsFromGMT: 0)
dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"

func printDate(_ date: Date, source: String) -> Never {
    print("\(source): \(dateFormatter.string(from: date))")
    exit(0)
}

func parseExifDate(_ value: String) -> Date? {
    let formatter = DateFormatter()
    formatter.locale = Locale(identifier: "en_US_POSIX")
    formatter.dateFormat = "yyyy:MM:dd HH:mm:ss"
    return formatter.date(from: value)
}

if ["heic", "heif", "jpg", "jpeg", "png", "dng", "tif", "tiff"].contains(ext) {
    if let source = CGImageSourceCreateWithURL(url as CFURL, nil),
       let props = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [CFString: Any] {
        if let exif = props[kCGImagePropertyExifDictionary] as? [CFString: Any],
           let original = exif[kCGImagePropertyExifDateTimeOriginal] as? String,
           let date = parseExifDate(original) {
            printDate(date, source: "image_exif_original")
        }
        if let tiff = props[kCGImagePropertyTIFFDictionary] as? [CFString: Any],
           let dateTime = tiff[kCGImagePropertyTIFFDateTime] as? String,
           let date = parseExifDate(dateTime) {
            printDate(date, source: "image_tiff_datetime")
        }
    }
}

if ["mov", "mp4", "m4v"].contains(ext) {
    let asset = AVURLAsset(url: url)
    let metadata = asset.commonMetadata + asset.metadata
    let keys = [
        AVMetadataKey.commonKeyCreationDate.rawValue,
        "creationDate",
        "com.apple.quicktime.creationdate",
    ]

    for item in metadata {
        let key = item.commonKey?.rawValue ?? item.key as? String
        guard let key, keys.contains(key) else {
            continue
        }
        if let date = item.dateValue {
            printDate(date, source: "video_metadata")
        }
        if let value = item.stringValue {
            let formats = [
                "yyyy-MM-dd'T'HH:mm:ssZ",
                "yyyy-MM-dd'T'HH:mm:ss.SSSZ",
                "yyyy-MM-dd HH:mm:ss",
            ]
            for format in formats {
                let formatter = DateFormatter()
                formatter.locale = Locale(identifier: "en_US_POSIX")
                formatter.dateFormat = format
                if let date = formatter.date(from: value) {
                    printDate(date, source: "video_metadata")
                }
            }
        }
    }
}

exit(1)

