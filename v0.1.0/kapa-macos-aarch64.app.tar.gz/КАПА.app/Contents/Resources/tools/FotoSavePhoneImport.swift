import Foundation
import ImageCaptureCore

private let supportedExtensions: Set<String> = [
    "heic", "heif", "jpg", "jpeg", "png", "dng", "tif", "tiff",
    "mov", "mp4", "m4v"
]

private struct Arguments {
    let command: String
    let outputDirectory: URL?
    let timeoutSeconds: TimeInterval
    let limit: Int?

    static func parse() -> Arguments? {
        var command: String?
        var outputDirectory: URL?
        var timeoutSeconds: TimeInterval = 60
        var limit: Int?

        var index = 1
        while index < CommandLine.arguments.count {
            let arg = CommandLine.arguments[index]
            switch arg {
            case "list", "download", "debug":
                command = arg
            case "--output":
                index += 1
                guard index < CommandLine.arguments.count else { return nil }
                outputDirectory = URL(fileURLWithPath: CommandLine.arguments[index], isDirectory: true)
            case "--timeout":
                index += 1
                guard index < CommandLine.arguments.count, let value = TimeInterval(CommandLine.arguments[index]) else { return nil }
                timeoutSeconds = value
            case "--limit":
                index += 1
                guard index < CommandLine.arguments.count, let value = Int(CommandLine.arguments[index]) else { return nil }
                limit = value
            default:
                return nil
            }
            index += 1
        }

        guard let command else { return nil }
        if command == "download" && outputDirectory == nil {
            return nil
        }

        return Arguments(
            command: command,
            outputDirectory: outputDirectory,
            timeoutSeconds: timeoutSeconds,
            limit: limit
        )
    }
}

private final class PhoneImporter: NSObject, ICDeviceBrowserDelegate, ICCameraDeviceDelegate, ICCameraDeviceDownloadDelegate {
    private let arguments: Arguments
    private let browser = ICDeviceBrowser()
    private var camera: ICCameraDevice?
    private var pendingFiles: [ICCameraFile] = []
    private var downloadedCount = 0
    private var failedCount = 0
    private var didFinish = false
    private var exitCode: Int32 = 0

    init(arguments: Arguments) {
        self.arguments = arguments
        super.init()
    }

    func run() -> Int32 {
        browser.delegate = self
        browser.browsedDeviceTypeMask = ICDeviceTypeMask(
            rawValue: ICDeviceTypeMask.camera.rawValue
                | ICDeviceTypeMask.scanner.rawValue
                | ICDeviceLocationTypeMask.local.rawValue
        )!
        browser.start()

        let deadline = Date().addingTimeInterval(arguments.timeoutSeconds)
        while !didFinish && Date() < deadline {
            RunLoop.current.run(mode: .default, before: Date().addingTimeInterval(0.1))
        }

        if !didFinish {
            if arguments.command == "debug" {
                printBrowserDevices()
                return 0
            } else {
                print("ERROR: телефон не найден через системный импорт фото или не успел отдать список файлов. Проверьте кабель, разблокируйте телефон и выберите режим USB «Передача фото/PTP».")
                return 2
            }
        }
        return exitCode != 0 ? exitCode : (failedCount == 0 ? 0 : 3)
    }

    func deviceBrowser(_ browser: ICDeviceBrowser, didAdd device: ICDevice, moreComing: Bool) {
        if arguments.command == "debug" {
            print("ADDED: \(describe(device)) moreComing=\(moreComing)")
        }

        guard camera == nil, let cameraDevice = device as? ICCameraDevice else {
            return
        }

        if arguments.command == "debug" {
            return
        }

        camera = cameraDevice
        cameraDevice.delegate = self
        cameraDevice.mediaPresentation = .originalAssets
        cameraDevice.requestOpenSession()
    }

    func deviceBrowser(_ browser: ICDeviceBrowser, didRemove device: ICDevice, moreGoing: Bool) {
        if device == camera {
            didFinish = true
        }
    }

    func deviceBrowserDidEnumerateLocalDevices(_ browser: ICDeviceBrowser) {
        if arguments.command == "debug" {
            print("ENUMERATED_LOCAL_DEVICES")
            printBrowserDevices()
            didFinish = true
            return
        }
    }

    func device(_ device: ICDevice, didOpenSessionWithError error: Error?) {
        if let error {
            print("ERROR: не удалось открыть сессию с телефоном: \(error.localizedDescription)")
            exitCode = 4
            didFinish = true
        }
    }

    func device(_ device: ICDevice, didCloseSessionWithError error: Error?) {
        didFinish = true
    }

    func didRemove(_ device: ICDevice) {
        didFinish = true
    }

    func deviceDidBecomeReady(_ device: ICDevice) {
        guard let camera = device as? ICCameraDevice else { return }
        handleReadyCamera(camera)
    }

    func deviceDidBecomeReady(withCompleteContentCatalog device: ICCameraDevice) {
        handleReadyCamera(device)
    }

    func cameraDevice(_ camera: ICCameraDevice, didAdd items: [ICCameraItem]) {}

    func cameraDevice(_ camera: ICCameraDevice, didRemove items: [ICCameraItem]) {}

    func cameraDevice(
        _ camera: ICCameraDevice,
        didReceiveThumbnail thumbnail: CGImage?,
        for item: ICCameraItem,
        error: Error?
    ) {}

    func cameraDevice(
        _ camera: ICCameraDevice,
        didReceiveMetadata metadata: [AnyHashable: Any]?,
        for item: ICCameraItem,
        error: Error?
    ) {}

    func cameraDevice(_ camera: ICCameraDevice, didRenameItems items: [ICCameraItem]) {}

    func cameraDeviceDidChangeCapability(_ camera: ICCameraDevice) {}

    func cameraDevice(_ camera: ICCameraDevice, didReceivePTPEvent eventData: Data) {}

    func cameraDeviceDidRemoveAccessRestriction(_ device: ICDevice) {}

    func cameraDeviceDidEnableAccessRestriction(_ device: ICDevice) {
        print("ERROR: телефон заблокирован. Разблокируйте экран и повторите.")
        exitCode = 5
        didFinish = true
    }

    @objc func didDownloadFile(
        _ file: ICCameraFile,
        error: Error?,
        options: [String: Any],
        contextInfo: UnsafeMutableRawPointer?
    ) {
        if let error {
            failedCount += 1
            print("ERROR: не удалось скачать \(file.name ?? "файл"): \(error.localizedDescription)")
        } else {
            downloadedCount += 1
            let savedName = options[ICDownloadOption.savedFilename.rawValue] as? String ?? file.name ?? "файл"
            print("DOWNLOADED: \(savedName)")
        }

        downloadNextFile()
    }

    func didReceiveDownloadProgress(for file: ICCameraFile, downloadedBytes: off_t, maxBytes: off_t) {}

    private func handleReadyCamera(_ camera: ICCameraDevice) {
        let allFiles = (camera.mediaFiles ?? []).compactMap { $0 as? ICCameraFile }
        let mediaFiles = allFiles.filter { file in
            guard let name = file.name else { return false }
            return supportedExtensions.contains(URL(fileURLWithPath: name).pathExtension.lowercased())
        }

        let selectedFiles: [ICCameraFile]
        if let limit = arguments.limit, limit > 0 {
            selectedFiles = Array(mediaFiles.prefix(limit))
        } else {
            selectedFiles = mediaFiles
        }

        let deviceName = camera.name ?? "iPhone"
        print("DEVICE: \(deviceName)")
        print("MEDIA_FOUND: \(mediaFiles.count)")

        if arguments.command == "list" {
            for file in selectedFiles {
                let name = file.name ?? "без имени"
                let date = file.creationDate.map { ISO8601DateFormatter().string(from: $0) } ?? "без даты"
                print("FILE: \(name) \(date)")
            }
            didFinish = true
            return
        }

        pendingFiles = selectedFiles
        print("TO_DOWNLOAD: \(pendingFiles.count)")
        downloadNextFile()
    }

    private func downloadNextFile() {
        guard let camera else {
            exitCode = 6
            didFinish = true
            return
        }

        if pendingFiles.isEmpty {
            print("DONE: downloaded=\(downloadedCount) failed=\(failedCount)")
            camera.requestCloseSession()
            return
        }

        guard let outputDirectory = arguments.outputDirectory else {
            print("ERROR: не указана папка для скачивания.")
            exitCode = 7
            didFinish = true
            return
        }

        let file = pendingFiles.removeFirst()
        let options: [ICDownloadOption: Any] = [
            .downloadsDirectoryURL: outputDirectory,
            .overwrite: false,
            .sidecarFiles: true,
        ]
        camera.requestDownloadFile(
            file,
            options: options,
            downloadDelegate: self,
            didDownloadSelector: #selector(didDownloadFile(_:error:options:contextInfo:)),
            contextInfo: nil
        )
    }

    private func printBrowserDevices() {
        let devices = browser.devices ?? []
        print("BROWSER_DEVICES: \(devices.count)")
        for device in devices {
            print("DEVICE_DEBUG: \(describe(device))")
        }
    }

    private func describe(_ device: ICDevice) -> String {
        let name = device.name ?? "nil"
        let productKind = device.productKind ?? "nil"
        let transport = device.transportType ?? "nil"
        let uuid = device.uuidString ?? "nil"
        return "name=\(name) productKind=\(productKind) transport=\(transport) type=\(device.type.rawValue) uuid=\(uuid)"
    }
}

private func printUsage() {
    print("""
    Usage:
      FotoSavePhoneImport list [--timeout 60] [--limit 20]
      FotoSavePhoneImport download --output /path/to/folder [--timeout 300] [--limit 0]
      FotoSavePhoneImport debug [--timeout 10]
    """)
}

guard let arguments = Arguments.parse() else {
    printUsage()
    exit(64)
}

private let importer = PhoneImporter(arguments: arguments)
exit(importer.run())
