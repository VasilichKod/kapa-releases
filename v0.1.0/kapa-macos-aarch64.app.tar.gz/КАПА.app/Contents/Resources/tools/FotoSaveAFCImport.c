#include <CoreFoundation/CoreFoundation.h>
#include <ctype.h>
#include <errno.h>
#include <libgen.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <utime.h>
#include <unistd.h>

typedef struct am_device *AMDeviceRef;
typedef struct am_device_notification *AMDeviceNotificationRef;
typedef struct afc_connection *AFCConnectionRef;
typedef struct afc_directory *AFCDirectoryRef;
typedef void *AMDServiceConnectionRef;
typedef void *AFCFileRef;

typedef struct {
    AMDeviceRef device;
    uint32_t message;
} AMDeviceNotificationCallbackInfo;

typedef void (*AMDeviceNotificationCallback)(AMDeviceNotificationCallbackInfo *, void *);

extern int AMDeviceNotificationSubscribe(AMDeviceNotificationCallback callback, uint32_t unused1, uint32_t unused2, void *context, AMDeviceNotificationRef *notification);
extern int AMDeviceConnect(AMDeviceRef device);
extern int AMDeviceDisconnect(AMDeviceRef device);
extern int AMDeviceIsPaired(AMDeviceRef device);
extern int AMDeviceValidatePairing(AMDeviceRef device);
extern int AMDeviceStartSession(AMDeviceRef device);
extern int AMDeviceStopSession(AMDeviceRef device);
extern int AMDeviceSecureStartService(AMDeviceRef device, CFStringRef service_name, void *options, void **service);
extern int AMDeviceStartService(AMDeviceRef device, CFStringRef service_name, int *service, uint32_t *unknown);
extern CFTypeRef AMDeviceCopyValue(AMDeviceRef device, CFStringRef domain, CFStringRef key);

extern int AMDServiceConnectionGetSocket(AMDServiceConnectionRef connection);
extern void *AMDServiceConnectionGetSecureIOContext(AMDServiceConnectionRef connection);

extern int AFCConnectionOpen(int service, uint32_t io_timeout, AFCConnectionRef *connection);
extern int AFCConnectionClose(AFCConnectionRef connection);
extern void AFCConnectionSetSecureContext(AFCConnectionRef connection, void *secure_context);
extern int AFCDirectoryOpen(AFCConnectionRef connection, const char *path, AFCDirectoryRef *directory);
extern int AFCDirectoryRead(AFCConnectionRef connection, AFCDirectoryRef directory, char **entry);
extern int AFCDirectoryClose(AFCConnectionRef connection, AFCDirectoryRef directory);
extern int AFCFileRefOpen(AFCConnectionRef connection, const char *path, uint64_t mode, AFCFileRef *file);
extern int AFCFileRefRead(AFCConnectionRef connection, AFCFileRef file, void *buffer, uint64_t *length);
extern int AFCFileRefClose(AFCConnectionRef connection, AFCFileRef file);
extern int AFCFileInfoOpen(AFCConnectionRef connection, const char *path, void **info);
extern int AFCKeyValueRead(void *info, char **key, char **value);
extern int AFCKeyValueClose(void *info);

static AMDeviceRef g_device = NULL;
static int g_discovered = 0;
static int g_limit = 0;
static int g_seen = 0;
static int g_downloaded = 0;
static int g_skipped = 0;
static int g_failed = 0;
static int g_plan_only = 0;
static long long g_total_size = 0;
static const char *g_output = NULL;
static const char *g_command = NULL;
static const char *g_start_path = "/DCIM";
static const char *g_service_name = NULL;
static const char *g_media_filter = "all";
static int g_first_printed = 0;

static void usage(void) {
    fprintf(stderr,
            "Usage:\n"
            "  FotoSaveAFCImport list [--timeout 10] [--limit 20] [--media all|photo|video]\n"
            "  FotoSaveAFCImport download --output /path/to/folder [--timeout 60] [--limit 0] [--media all|photo|video]\n"
            "  FotoSaveAFCImport ls [--path /] [--timeout 10] [--service com.apple.afc]\n"
            "  FotoSaveAFCImport first [--timeout 10]\n"
            "  FotoSaveAFCImport services [--timeout 10]\n");
}

static int extension_for_name(const char *name, char *ext, size_t ext_size) {
    const char *dot = strrchr(name, '.');
    if (!dot || !dot[1]) {
        return 0;
    }
    size_t len = strlen(dot + 1);
    if (len >= ext_size) {
        return 0;
    }
    for (size_t i = 0; i < len; i++) {
        ext[i] = (char)tolower((unsigned char)dot[1 + i]);
    }
    ext[len] = '\0';
    return 1;
}

static int is_photo_extension(const char *ext) {
    const char *allowed[] = {
        "heic", "heif", "jpg", "jpeg", "png", "webp", "dng", "tif", "tiff", NULL
    };
    for (int i = 0; allowed[i]; i++) {
        if (strcmp(ext, allowed[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

static int is_video_extension(const char *ext) {
    const char *allowed[] = {"mov", "mp4", "m4v", NULL};
    for (int i = 0; allowed[i]; i++) {
        if (strcmp(ext, allowed[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

static int is_media_file(const char *name) {
    char ext[16];
    if (!extension_for_name(name, ext, sizeof(ext))) {
        return 0;
    }
    if (strcmp(g_media_filter, "photo") == 0) {
        return is_photo_extension(ext);
    }
    if (strcmp(g_media_filter, "video") == 0) {
        return is_video_extension(ext);
    }
    return is_photo_extension(ext) || is_video_extension(ext);
}

static void device_callback(AMDeviceNotificationCallbackInfo *info, void *context) {
    (void)context;
    if (info && info->message == 1 && info->device) {
        g_device = info->device;
        g_discovered = 1;
        CFRunLoopStop(CFRunLoopGetCurrent());
    }
}

static void print_cf_string(CFTypeRef value) {
    if (!value || CFGetTypeID(value) != CFStringGetTypeID()) {
        printf("unknown");
        return;
    }
    char buffer[512];
    if (CFStringGetCString((CFStringRef)value, buffer, sizeof(buffer), kCFStringEncodingUTF8)) {
        printf("%s", buffer);
    } else {
        printf("unknown");
    }
}

static int mkdir_p(const char *path) {
    char tmp[PATH_MAX];
    size_t len = strlen(path);
    if (len == 0 || len >= sizeof(tmp)) {
        return -1;
    }
    strcpy(tmp, path);
    if (tmp[len - 1] == '/') {
        tmp[len - 1] = '\0';
    }
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = '\0';
            if (mkdir(tmp, 0755) != 0 && errno != EEXIST) {
                return -1;
            }
            *p = '/';
        }
    }
    if (mkdir(tmp, 0755) != 0 && errno != EEXIST) {
        return -1;
    }
    return 0;
}

static int ensure_parent_dir(const char *path) {
    char copy[PATH_MAX];
    if (strlen(path) >= sizeof(copy)) {
        return -1;
    }
    strcpy(copy, path);
    char *dir = dirname(copy);
    return mkdir_p(dir);
}

static time_t remote_mtime(AFCConnectionRef connection, const char *remote_path) {
    void *info = NULL;
    int status = AFCFileInfoOpen(connection, remote_path, &info);
    if (status != 0 || !info) {
        return 0;
    }

    time_t result = 0;
    while (1) {
        char *key = NULL;
        char *value = NULL;
        status = AFCKeyValueRead(info, &key, &value);
        if (status != 0 || key == NULL || value == NULL) {
            break;
        }
        if (strcmp(key, "st_mtime") == 0) {
            long long raw = atoll(value);
            if (raw > 1000000000000LL) {
                raw /= 1000000000LL;
            }
            result = (time_t)raw;
            break;
        }
    }

    AFCKeyValueClose(info);
    return result;
}

static long long remote_size(AFCConnectionRef connection, const char *remote_path) {
    void *info = NULL;
    int status = AFCFileInfoOpen(connection, remote_path, &info);
    if (status != 0 || !info) {
        return -1;
    }

    long long result = -1;
    while (1) {
        char *key = NULL;
        char *value = NULL;
        status = AFCKeyValueRead(info, &key, &value);
        if (status != 0 || key == NULL || value == NULL) {
            break;
        }
        if (strcmp(key, "st_size") == 0) {
            result = atoll(value);
            break;
        }
    }

    AFCKeyValueClose(info);
    return result;
}

static void apply_mtime(const char *local_path, time_t mtime) {
    if (mtime <= 0) {
        return;
    }
    struct utimbuf times;
    times.actime = mtime;
    times.modtime = mtime;
    utime(local_path, &times);
}

static void local_path_for_remote(const char *remote, char *out, size_t out_size) {
    const char *relative = remote;
    while (*relative == '/') {
        relative++;
    }
    snprintf(out, out_size, "%s/%s", g_output, relative);
}

static void print_safe_path(FILE *stream, const char *path) {
    for (const unsigned char *p = (const unsigned char *)path; *p; p++) {
        if (*p >= 32 && *p < 127) {
            fputc(*p, stream);
        } else {
            fprintf(stream, "\\x%02X", *p);
        }
    }
}

enum {
    COPY_FAILED = -1,
    COPY_DOWNLOADED = 1,
    COPY_SKIPPED = 2
};

static int copy_file(AFCConnectionRef connection, const char *remote_path) {
    time_t mtime = remote_mtime(connection, remote_path);
    long long expected_size = remote_size(connection, remote_path);
    char local_path[PATH_MAX];
    local_path_for_remote(remote_path, local_path, sizeof(local_path));

    struct stat existing;
    if (expected_size >= 0 && stat(local_path, &existing) == 0 && S_ISREG(existing.st_mode) && existing.st_size == expected_size) {
        apply_mtime(local_path, mtime);
        printf("SKIPPED_EXISTING: %lld %s\n", expected_size, remote_path);
        return COPY_SKIPPED;
    }

    AFCFileRef file = NULL;
    int status = AFCFileRefOpen(connection, remote_path, 1, &file);
    if (status != 0) {
        fprintf(stderr, "ERROR: не удалось открыть файл на iPhone status=%d path=", status);
        print_safe_path(stderr, remote_path);
        fprintf(stderr, "\n");
        return -1;
    }

    if (ensure_parent_dir(local_path) != 0) {
        fprintf(stderr, "ERROR: не удалось создать папку: %s\n", local_path);
        AFCFileRefClose(connection, file);
        return -1;
    }

    FILE *out = fopen(local_path, "wb");
    if (!out) {
        fprintf(stderr, "ERROR: не удалось создать файл: %s\n", local_path);
        AFCFileRefClose(connection, file);
        return COPY_FAILED;
    }

    unsigned char buffer[1024 * 64];
    long long copied_size = 0;
    CFAbsoluteTime last_progress = CFAbsoluteTimeGetCurrent();
    printf("STARTED: %lld %s\n", expected_size, remote_path);
    while (1) {
        uint64_t bytes_read = (uint64_t)sizeof(buffer);
        status = AFCFileRefRead(connection, file, buffer, &bytes_read);
        if (status != 0) {
            fprintf(stderr, "ERROR: ошибка чтения с iPhone status=%d path=", status);
            print_safe_path(stderr, remote_path);
            fprintf(stderr, "\n");
            fclose(out);
            AFCFileRefClose(connection, file);
            return COPY_FAILED;
        }
        if (bytes_read == 0) {
            break;
        }
        if (fwrite(buffer, 1, (size_t)bytes_read, out) != (size_t)bytes_read) {
            fprintf(stderr, "ERROR: ошибка записи файла: %s\n", local_path);
            fclose(out);
            AFCFileRefClose(connection, file);
            return COPY_FAILED;
        }
        copied_size += (long long)bytes_read;
        CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
        if (now - last_progress >= 1.0) {
            printf("FILE_PROGRESS: %lld %lld %s\n", copied_size, expected_size, remote_path);
            last_progress = now;
        }
    }

    fclose(out);
    AFCFileRefClose(connection, file);
    apply_mtime(local_path, mtime);
    printf("DOWNLOADED: %lld %s\n", copied_size, remote_path);
    return COPY_DOWNLOADED;
}

static void join_remote_path(const char *parent, const char *child, char *out, size_t out_size) {
    if (strcmp(parent, "/") == 0) {
        snprintf(out, out_size, "/%s", child);
    } else {
        snprintf(out, out_size, "%s/%s", parent, child);
    }
}

static int should_stop_for_limit(void) {
    return g_first_printed || (g_limit > 0 && g_seen >= g_limit);
}

static void traverse(AFCConnectionRef connection, const char *path) {
    if (should_stop_for_limit()) {
        return;
    }

    AFCDirectoryRef directory = NULL;
    int status = AFCDirectoryOpen(connection, path, &directory);
    if (status != 0 || !directory) {
        if (is_media_file(path)) {
            g_seen++;
            if (strcmp(g_command, "first") == 0) {
                printf("FIRST: ");
                print_safe_path(stdout, path);
                printf("\n");
                g_first_printed = 1;
            } else if (strcmp(g_command, "list") == 0) {
                printf("FILE: %s\n", path);
            } else if (strcmp(g_command, "download") == 0) {
                if (g_plan_only) {
                    long long planned_size = remote_size(connection, path);
                    if (planned_size > 0) {
                        g_total_size += planned_size;
                    }
                    return;
                }
                int copy_status = copy_file(connection, path);
                if (copy_status == COPY_DOWNLOADED) {
                    g_downloaded++;
                } else if (copy_status == COPY_SKIPPED) {
                    g_skipped++;
                } else {
                    g_failed++;
                }
            }
        }
        return;
    }

    while (!should_stop_for_limit()) {
        char *entry = NULL;
        status = AFCDirectoryRead(connection, directory, &entry);
        if (status != 0 || entry == NULL) {
            break;
        }
        if (strcmp(entry, ".") == 0 || strcmp(entry, "..") == 0) {
            continue;
        }
        char child[PATH_MAX];
        join_remote_path(path, entry, child, sizeof(child));
        traverse(connection, child);
    }
    AFCDirectoryClose(connection, directory);
}

static int list_directory(AFCConnectionRef connection, const char *path) {
    AFCDirectoryRef directory = NULL;
    int status = AFCDirectoryOpen(connection, path, &directory);
    if (status != 0 || !directory) {
        fprintf(stderr, "ERROR: не удалось открыть папку %s status=%d\n", path, status);
        return -1;
    }

    printf("LS: %s\n", path);
    while (1) {
        char *entry = NULL;
        status = AFCDirectoryRead(connection, directory, &entry);
        if (status != 0) {
            fprintf(stderr, "ERROR: чтение папки %s status=%d\n", path, status);
            AFCDirectoryClose(connection, directory);
            return -1;
        }
        if (entry == NULL) {
            break;
        }
        printf("ENTRY: %s\n", entry);
    }

    AFCDirectoryClose(connection, directory);
    return 0;
}

static int parse_args(int argc, char **argv, int *timeout) {
    *timeout = 10;
    g_limit = 0;
    if (argc < 2) {
        return -1;
    }
    g_command = argv[1];
    if (strcmp(g_command, "list") != 0
            && strcmp(g_command, "download") != 0
            && strcmp(g_command, "ls") != 0
            && strcmp(g_command, "first") != 0
            && strcmp(g_command, "services") != 0) {
        return -1;
    }

    for (int i = 2; i < argc; i++) {
        if (strcmp(argv[i], "--timeout") == 0 && i + 1 < argc) {
            *timeout = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--limit") == 0 && i + 1 < argc) {
            g_limit = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--output") == 0 && i + 1 < argc) {
            g_output = argv[++i];
        } else if (strcmp(argv[i], "--path") == 0 && i + 1 < argc) {
            g_start_path = argv[++i];
        } else if (strcmp(argv[i], "--service") == 0 && i + 1 < argc) {
            g_service_name = argv[++i];
        } else if (strcmp(argv[i], "--media") == 0 && i + 1 < argc) {
            g_media_filter = argv[++i];
            if (strcmp(g_media_filter, "all") != 0
                    && strcmp(g_media_filter, "photo") != 0
                    && strcmp(g_media_filter, "video") != 0) {
                return -1;
            }
        } else {
            return -1;
        }
    }

    if (strcmp(g_command, "download") == 0 && !g_output) {
        return -1;
    }
    return 0;
}

static CFStringRef cf_string_from_c(const char *value) {
    return CFStringCreateWithCString(kCFAllocatorDefault, value, kCFStringEncodingUTF8);
}

static int open_afc_service(AMDeviceRef device, const char *service_name, AFCConnectionRef *connection) {
    *connection = NULL;

    CFStringRef service_cf = cf_string_from_c(service_name);
    if (!service_cf) {
        return -100;
    }

    AMDServiceConnectionRef secure_service = NULL;
    int status = AMDeviceSecureStartService(device, service_cf, NULL, &secure_service);
    if (status == 0 && secure_service) {
        int socket = AMDServiceConnectionGetSocket(secure_service);
        status = AFCConnectionOpen(socket, 0, connection);
        if (status == 0 && *connection) {
            void *secure_context = AMDServiceConnectionGetSecureIOContext(secure_service);
            if (secure_context) {
                AFCConnectionSetSecureContext(*connection, secure_context);
            }
        }
        CFRelease(service_cf);
        return status != 0 ? status : 0;
    }

    if (status != 0 || !secure_service) {
        uint32_t unknown = 0;
        int service = 0;
        status = AMDeviceStartService(device, service_cf, &service, &unknown);
        if (status == 0 && service != 0) {
            status = AFCConnectionOpen(service, 0, connection);
            CFRelease(service_cf);
            return status != 0 ? status : 0;
        }
    }
    CFRelease(service_cf);

    if (status != 0) {
        return status != 0 ? status : -101;
    }
    return -101;
}

static int command_services(AMDeviceRef device) {
    const char *services[] = {
        "com.apple.afc",
        "com.apple.crashreportcopymobile",
        "com.apple.mobile.house_arrest",
        "com.apple.mobile_image_mounter",
        "com.apple.mobile.file_relay",
        "com.apple.mobile.notification_proxy",
        NULL
    };

    for (int i = 0; services[i]; i++) {
        AFCConnectionRef connection = NULL;
        int status = open_afc_service(device, services[i], &connection);
        printf("SERVICE: %s status=%d", services[i], status);
        if (status == 0 && connection) {
            AFCDirectoryRef directory = NULL;
            int root_status = AFCDirectoryOpen(connection, "/", &directory);
            printf(" root_status=%d", root_status);
            if (root_status == 0 && directory) {
                AFCDirectoryClose(connection, directory);
            }
            AFCConnectionClose(connection);
        }
        printf("\n");
    }

    return 0;
}

int main(int argc, char **argv) {
    setvbuf(stdout, NULL, _IOLBF, 0);
    setvbuf(stderr, NULL, _IOLBF, 0);

    int timeout = 10;
    if (parse_args(argc, argv, &timeout) != 0) {
        usage();
        return 64;
    }

    AMDeviceNotificationRef notification = NULL;
    int status = AMDeviceNotificationSubscribe(device_callback, 0, 0, NULL, &notification);
    if (status != 0) {
        fprintf(stderr, "ERROR: AMDeviceNotificationSubscribe status=%d\n", status);
        return 2;
    }

    CFAbsoluteTime deadline = CFAbsoluteTimeGetCurrent() + timeout;
    while (!g_discovered && CFAbsoluteTimeGetCurrent() < deadline) {
        CFRunLoopRunInMode(kCFRunLoopDefaultMode, 0.2, false);
    }

    if (!g_device) {
        fprintf(stderr, "ERROR: MobileDevice не увидел iPhone. Finder может видеть устройство, но AFC-доступ пока не открыт.\n");
        return 3;
    }

    status = AMDeviceConnect(g_device);
    if (status != 0) {
        fprintf(stderr, "ERROR: AMDeviceConnect status=%d\n", status);
        return 4;
    }
    if (!AMDeviceIsPaired(g_device)) {
        fprintf(stderr, "ERROR: iPhone не спарен с этим Mac. Разблокируйте iPhone и нажмите 'Доверять'.\n");
        AMDeviceDisconnect(g_device);
        return 5;
    }
    status = AMDeviceValidatePairing(g_device);
    if (status != 0) {
        fprintf(stderr, "ERROR: AMDeviceValidatePairing status=%d\n", status);
        AMDeviceDisconnect(g_device);
        return 6;
    }
    status = AMDeviceStartSession(g_device);
    if (status != 0) {
        fprintf(stderr, "ERROR: AMDeviceStartSession status=%d\n", status);
        AMDeviceDisconnect(g_device);
        return 7;
    }

    printf("DEVICE: ");
    CFTypeRef name = AMDeviceCopyValue(g_device, NULL, CFSTR("DeviceName"));
    print_cf_string(name);
    if (name) {
        CFRelease(name);
    }
    printf("\n");

    if (strcmp(g_command, "services") == 0) {
        int services_status = command_services(g_device);
        AMDeviceStopSession(g_device);
        AMDeviceDisconnect(g_device);
        return services_status;
    }

    const char *service_to_use = g_service_name ? g_service_name : "com.apple.afc";
    AFCConnectionRef connection = NULL;
    status = open_afc_service(g_device, service_to_use, &connection);
    if (status != 0 || !connection) {
        fprintf(stderr, "ERROR: не удалось открыть AFC-сервис %s status=%d\n", service_to_use, status);
        AMDeviceStopSession(g_device);
        AMDeviceDisconnect(g_device);
        return 8;
    }

    if (strcmp(g_command, "ls") == 0) {
        int ls_status = list_directory(connection, g_start_path);
        AFCConnectionClose(connection);
        AMDeviceStopSession(g_device);
        AMDeviceDisconnect(g_device);
        return ls_status == 0 ? 0 : 11;
    }

    if (strcmp(g_command, "download") == 0) {
        g_plan_only = 1;
        g_seen = 0;
        g_total_size = 0;
        traverse(connection, g_start_path);
        printf("PLAN: media=%d bytes=%lld\n", g_seen, g_total_size);
        g_plan_only = 0;
        g_seen = 0;
    }

    traverse(connection, g_start_path);
    printf("DONE: media=%d downloaded=%d skipped=%d failed=%d\n", g_seen, g_downloaded, g_skipped, g_failed);

    AFCConnectionClose(connection);
    AMDeviceStopSession(g_device);
    AMDeviceDisconnect(g_device);
    return g_failed == 0 ? 0 : 10;
}
