param(
  [Parameter(Mandatory = $true)]
  [string]$Version,

  [Parameter(Mandatory = $true)]
  [string]$Url,

  [string]$SignaturePath = "",
  [string]$OutputPath = "desktop/src-tauri/target/release/bundle/nsis/latest.json",
  [string]$Notes = "Новая версия КАПА"
)

$ErrorActionPreference = "Stop"

if (-not $SignaturePath) {
  $nsisDir = "desktop/src-tauri/target/release/bundle/nsis"
  $signatureFile = Get-ChildItem -LiteralPath $nsisDir -Filter "*_$($Version)_x64-setup.exe.sig" | Select-Object -First 1
  if (-not $signatureFile) {
    $signatureFile = Get-ChildItem -LiteralPath $nsisDir -Filter "*.sig" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  }
  if ($signatureFile) {
    $SignaturePath = $signatureFile.FullName
  }
}

if (-not $SignaturePath -or -not (Test-Path -LiteralPath $SignaturePath)) {
  throw "Signature file not found: $SignaturePath"
}

$signature = (Get-Content -Raw -LiteralPath $SignaturePath).Trim()
$publishedAt = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")

$manifest = [ordered]@{
  version = $Version
  notes = $Notes
  pub_date = $publishedAt
  platforms = [ordered]@{
    "windows-x86_64" = [ordered]@{
      signature = $signature
      url = $Url
    }
  }
}

$outputDir = Split-Path -Parent $OutputPath
if ($outputDir) {
  New-Item -ItemType Directory -Force -Path $outputDir | Out-Null
}

$manifest | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $OutputPath -Encoding UTF8
Write-Host "latest.json written to $OutputPath"
