#!/usr/bin/env node
import { existsSync, mkdirSync, readFileSync, readdirSync, statSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const rootDir = resolve(dirname(fileURLToPath(import.meta.url)), "..");

function usage() {
  console.error(`Usage:
  node tools/create_latest_json.mjs --platform darwin-aarch64 --url <update-url> [options]

Options:
  --version <version>       Defaults to desktop/package.json version.
  --signature <path>        Defaults to latest signature for the selected platform.
  --output <path>           Defaults to desktop/src-tauri/target/release/latest.json.
  --merge <path>            Merge platforms from an existing latest.json.
  --notes <text>            Release notes.

Platforms:
  windows-x86_64, darwin-aarch64, darwin-x86_64`);
}

function parseArgs(argv) {
  const result = {};
  for (let index = 0; index < argv.length; index += 1) {
    const key = argv[index];
    if (!key.startsWith("--")) {
      throw new Error(`Unexpected argument: ${key}`);
    }
    const name = key.slice(2);
    const value = argv[index + 1];
    if (!value || value.startsWith("--")) {
      throw new Error(`Missing value for ${key}`);
    }
    result[name] = value;
    index += 1;
  }
  return result;
}

function latestFile(dir, predicate) {
  if (!existsSync(dir)) {
    return "";
  }
  return readdirSync(dir)
    .map((name) => join(dir, name))
    .filter((path) => predicate(path))
    .sort((left, right) => statSync(left).mtimeMs - statSync(right).mtimeMs)
    .at(-1) ?? "";
}

function defaultSignaturePath(platform) {
  if (platform === "windows-x86_64") {
    return latestFile(
      join(rootDir, "desktop/src-tauri/target/release/bundle/nsis"),
      (path) => path.endsWith(".exe.sig"),
    );
  }
  if (platform === "darwin-aarch64" || platform === "darwin-x86_64") {
    return latestFile(
      join(rootDir, "desktop/src-tauri/target/release/bundle/macos"),
      (path) => path.endsWith(".app.tar.gz.sig"),
    );
  }
  throw new Error(`Unsupported platform: ${platform}`);
}

function defaultVersion() {
  const packageJson = JSON.parse(readFileSync(join(rootDir, "desktop/package.json"), "utf8"));
  return packageJson.version;
}

function readExistingManifest(path) {
  if (!path || !existsSync(path)) {
    return null;
  }
  return JSON.parse(readFileSync(path, "utf8"));
}

try {
  const args = parseArgs(process.argv.slice(2));
  if (!args.platform || !args.url) {
    usage();
    process.exit(64);
  }

  const outputPath = resolve(rootDir, args.output ?? "desktop/src-tauri/target/release/latest.json");
  const mergePath = args.merge ? resolve(rootDir, args.merge) : outputPath;
  const signaturePath = resolve(rootDir, args.signature ?? defaultSignaturePath(args.platform));
  if (!existsSync(signaturePath)) {
    throw new Error(`Signature file not found: ${signaturePath}`);
  }

  const existing = readExistingManifest(mergePath);
  const manifest = {
    version: args.version ?? existing?.version ?? defaultVersion(),
    notes: args.notes ?? existing?.notes ?? "Новая версия КАПА",
    pub_date: new Date().toISOString(),
    platforms: {
      ...(existing?.platforms ?? {}),
      [args.platform]: {
        signature: readFileSync(signaturePath, "utf8").trim(),
        url: args.url,
      },
    },
  };

  mkdirSync(dirname(outputPath), { recursive: true });
  writeFileSync(outputPath, `${JSON.stringify(manifest, null, 2)}\n`, "utf8");
  console.log(`latest.json written to ${outputPath}`);
  console.log(`platform: ${args.platform}`);
  console.log(`signature: ${signaturePath}`);
} catch (error) {
  console.error(error instanceof Error ? error.message : String(error));
  process.exit(1);
}
