#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MTP_SOURCE="$ROOT_DIR/tools/FotoSaveMTPImport.c"
MTP_HELPER="$ROOT_DIR/bin/FotoSaveMTPImport"
LIB_DIR="$ROOT_DIR/bin/lib"

brew_prefix() {
  if command -v brew >/dev/null 2>&1; then
    brew --prefix "$1" 2>/dev/null || true
  fi
}

default_prefix() {
  local formula="$1"
  local brew_found
  brew_found="$(brew_prefix "$formula")"
  if [[ -n "$brew_found" ]]; then
    echo "$brew_found"
    return
  fi

  if [[ -d "/opt/homebrew/opt/$formula" ]]; then
    echo "/opt/homebrew/opt/$formula"
    return
  fi

  if [[ -d "/usr/local/opt/$formula" ]]; then
    echo "/usr/local/opt/$formula"
    return
  fi
}

patch_dependency() {
  local target="$1"
  local old_name="$2"
  local new_name="$3"

  if [[ -n "$old_name" && "$old_name" != "$new_name" ]]; then
    install_name_tool -change "$old_name" "$new_name" "$target"
  fi
}

LIBMTP_PREFIX="${LIBMTP_PREFIX:-$(default_prefix libmtp)}"
LIBUSB_PREFIX="${LIBUSB_PREFIX:-$(default_prefix libusb)}"
LIBMTP_DYLIB="${LIBMTP_DYLIB:-$LIBMTP_PREFIX/lib/libmtp.9.dylib}"
LIBUSB_DYLIB="${LIBUSB_DYLIB:-$LIBUSB_PREFIX/lib/libusb-1.0.0.dylib}"

if [[ ! -f "$MTP_SOURCE" ]]; then
  echo "Не найден исходник MTP-helper: $MTP_SOURCE"
  exit 1
fi

if [[ ! -f "$LIBMTP_DYLIB" || ! -f "$LIBMTP_PREFIX/include/libmtp.h" ]]; then
  echo "Не найден libmtp: $LIBMTP_DYLIB"
  echo "Установите libmtp через Homebrew: brew install libmtp"
  exit 1
fi

if [[ ! -f "$LIBUSB_DYLIB" ]]; then
  echo "Не найден libusb: $LIBUSB_DYLIB"
  echo "Установите libusb через Homebrew: brew install libusb"
  exit 1
fi

if [[ ! -f "$MTP_HELPER" || "$MTP_SOURCE" -nt "$MTP_HELPER" ]]; then
  mkdir -p "$(dirname "$MTP_HELPER")"
  clang "$MTP_SOURCE" \
    -I "$LIBMTP_PREFIX/include" \
    -L "$LIBMTP_PREFIX/lib" \
    -lmtp \
    -o "$MTP_HELPER"
fi

mkdir -p "$LIB_DIR"
cp -f "$LIBMTP_DYLIB" "$LIB_DIR/libmtp.9.dylib"
cp -f "$LIBUSB_DYLIB" "$LIB_DIR/libusb-1.0.0.dylib"
chmod 755 "$LIB_DIR/libmtp.9.dylib" "$LIB_DIR/libusb-1.0.0.dylib" "$MTP_HELPER"

HELPER_LIBMTP_DEP="$(otool -L "$MTP_HELPER" | awk '/libmtp.*\.dylib/ {print $1; exit}')"
LIBMTP_LIBUSB_DEP="$(otool -L "$LIB_DIR/libmtp.9.dylib" | awk '/libusb.*\.dylib/ {print $1; exit}')"

install_name_tool -id "@loader_path/libmtp.9.dylib" "$LIB_DIR/libmtp.9.dylib"
install_name_tool -id "@loader_path/libusb-1.0.0.dylib" "$LIB_DIR/libusb-1.0.0.dylib"
patch_dependency "$LIB_DIR/libmtp.9.dylib" "$LIBMTP_LIBUSB_DEP" "@loader_path/libusb-1.0.0.dylib"
patch_dependency "$MTP_HELPER" "$HELPER_LIBMTP_DEP" "@loader_path/lib/libmtp.9.dylib"

codesign --force --sign - "$LIB_DIR/libusb-1.0.0.dylib"
codesign --force --sign - "$LIB_DIR/libmtp.9.dylib"
codesign --force --sign - "$MTP_HELPER"

echo "MTP dependencies vendored into $LIB_DIR"
