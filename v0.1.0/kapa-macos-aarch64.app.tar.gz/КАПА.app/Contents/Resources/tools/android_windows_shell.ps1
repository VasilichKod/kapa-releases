param(
    [Parameter(Mandatory = $true, Position = 0)]
    [ValidateSet("list", "download")]
    [string]$Command,

    [string]$Output,
    [int]$Limit = 0,
    [ValidateSet("all", "photo", "video")]
    [string]$Media = "all",
    [string]$SkipManifest
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new()
$OutputEncoding = [System.Text.UTF8Encoding]::new()

$PhotoExtensions = @(".heic", ".heif", ".jpg", ".jpeg", ".png", ".webp", ".dng", ".tif", ".tiff")
$VideoExtensions = @(".mov", ".mp4", ".m4v")
$MediaExtensions = $PhotoExtensions + $VideoExtensions
$CopyOptions = 1556
$SkippedPathParts = @(
    "/Android/data/",
    "/Android/obb/",
    "/.thumbnails/",
    "/.thumbnail/",
    "/Cache/",
    "/Caches/",
    "/cache/",
    "/cached/",
    "/Backups/",
    "/Databases/",
    "/Stickers/",
    "/.Statuses/"
)

function Test-AndroidDeviceCandidate([object]$Item) {
    if (-not $Item.IsFolder) {
        return $false
    }

    $name = [string]$Item.Name
    $path = [string]$Item.Path
    if ($name -match "iPhone|iPad|iPod|Apple" -or $path -match "vid_05ac") {
        return $false
    }

    $knownAndroidName = $name -match "Android|Galaxy|Samsung|Redmi|Xiaomi|Pixel|Motorola|Moto|OnePlus|OPPO|Realme|Vivo|Huawei|Honor|Sony|Nokia|Nothing"
    $knownAndroidPath = $path -match "mtp|samsung_android|android|vid_04e8|vid_2717|vid_18d1|vid_22b8|vid_2a70|vid_12d1|vid_22d9|vid_2d95|vid_0fce|vid_1004|vid_0421|vid_2e17"
    if ($knownAndroidName -or $knownAndroidPath) {
        return $true
    }

    try {
        $storageNames = @($Item.GetFolder.Items() | Where-Object { $_.IsFolder } | ForEach-Object { [string]$_.Name })
        return ($storageNames | Where-Object { $_ -match "Phone|Internal storage|Internal Storage|SD card|Card|Внутрен" } | Select-Object -First 1) -ne $null
    } catch {
        return $false
    }
}

function Get-AndroidFolderPriority([string]$Name) {
    if ($Name -match "^DCIM$") { return 0 }
    if ($Name -match "^Pictures$|^Изображения$") { return 1 }
    if ($Name -match "^Movies$|^Video$|^Videos$|^Видео$") { return 2 }
    if ($Name -match "^Download$|^Downloads$|^Загрузки$") { return 3 }
    if ($Name -match "^WhatsApp$|^WhatsApp Business$|^Telegram$|^Viber$") { return 4 }
    if ($Name -match "^Android$|^Samsung$|^Music$|^Podcasts$|^Ringtones$|^Alarms$|^Notifications$") { return 50 }
    return 20
}

function Get-AndroidStorage {
    $shell = New-Object -ComObject Shell.Application
    $thisPc = $shell.Namespace(17)
    if ($null -eq $thisPc) {
        throw "Could not open This PC through Windows Shell."
    }

    $device = $thisPc.Items() |
        Where-Object { Test-AndroidDeviceCandidate $_ } |
        Select-Object -First 1

    if ($null -eq $device) {
        throw "Android device not found. Unlock the phone and select File transfer / MTP."
    }

    $storage = $device.GetFolder.Items() |
        Where-Object { $_.IsFolder -and ([string]$_.Name -match "Phone|Internal storage|Internal Storage|SD card|Card|Внутрен") } |
        Select-Object -First 1

    if ($null -eq $storage) {
        $storage = $device.GetFolder.Items() | Where-Object { $_.IsFolder } | Select-Object -First 1
    }

    if ($null -eq $storage) {
        throw "Android device was found, but storage is not available. Unlock the phone and allow data access."
    }

    [pscustomobject]@{
        Shell = $shell
        Device = $device
        Storage = $storage
    }
}

function Get-ExtensionFromType([object]$Item) {
    $nameExtension = [System.IO.Path]::GetExtension([string]$Item.Name).ToLowerInvariant()
    if (-not [string]::IsNullOrWhiteSpace($nameExtension)) {
        return $nameExtension
    }

    $type = [string]$Item.Type
    if ($type -match '"([^"]+)"') {
        return "." + $Matches[1].ToLowerInvariant()
    }

    $typeLower = $type.ToLowerInvariant()
    if ($typeLower.Contains("jpeg") -or $typeLower.Contains("jpg")) { return ".jpg" }
    if ($typeLower.Contains("png")) { return ".png" }
    if ($typeLower.Contains("heic")) { return ".heic" }
    if ($typeLower.Contains("heif")) { return ".heif" }
    if ($typeLower.Contains("webp")) { return ".webp" }
    if ($typeLower.Contains("dng")) { return ".dng" }
    if ($typeLower.Contains("tiff")) { return ".tiff" }
    if ($typeLower.Contains("tif")) { return ".tif" }
    if ($typeLower.Contains("mp4")) { return ".mp4" }
    if ($typeLower.Contains("quicktime")) { return ".mov" }
    if ($typeLower.Contains("mov")) { return ".mov" }
    if ($typeLower.Contains("m4v")) { return ".m4v" }

    return ""
}

function Get-DetailValue([object]$Folder, [object]$Item, [int]$Index) {
    try {
        return [string]$Folder.GetDetailsOf($Item, $Index)
    } catch {
        return ""
    }
}

function Convert-SizeToBytes([string]$Value) {
    if ([string]::IsNullOrWhiteSpace($Value)) {
        return 0
    }

    $normalized = $Value.Trim().Replace([char]0x00A0, " ")
    if ($normalized -notmatch "([\d\s]+(?:[,.]\d+)?)\s*([^\d\s]+)") {
        return 0
    }

    $number = $Matches[1].Replace(" ", "").Replace(",", ".")
    $unit = $Matches[2].ToUpperInvariant()
    $valueNumber = 0.0
    if (-not [double]::TryParse($number, [System.Globalization.NumberStyles]::Float, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$valueNumber)) {
        return 0
    }

    $kbRu = [string][char]0x041A + [string][char]0x0411
    $mbRu = [string][char]0x041C + [string][char]0x0411
    $gbRu = [string][char]0x0413 + [string][char]0x0411
    $tbRu = [string][char]0x0422 + [string][char]0x0411

    $multiplier = 1
    if ($unit -in @($kbRu, "KB")) { $multiplier = 1KB }
    elseif ($unit -in @($mbRu, "MB")) { $multiplier = 1MB }
    elseif ($unit -in @($gbRu, "GB")) { $multiplier = 1GB }
    elseif ($unit -in @($tbRu, "TB")) { $multiplier = 1TB }

    return [int64]($valueNumber * $multiplier)
}

function Test-MediaExtension([string]$Extension) {
    if ($MediaExtensions -notcontains $Extension) {
        return $false
    }
    if ($Media -eq "photo") {
        return $PhotoExtensions -contains $Extension
    }
    if ($Media -eq "video") {
        return $VideoExtensions -contains $Extension
    }
    return $true
}

function Normalize-SourceKey([string]$RemotePath, [int64]$Size) {
    $normalized = $RemotePath.Replace("\", "/").Trim().TrimEnd("/").ToLowerInvariant()
    if (-not $normalized.StartsWith("/")) {
        $normalized = "/" + $normalized
    }
    return "$normalized|$Size"
}

function Read-SkipManifest([string]$Path) {
    $set = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    if (-not [string]::IsNullOrWhiteSpace($Path) -and (Test-Path -LiteralPath $Path)) {
        foreach ($line in Get-Content -LiteralPath $Path -Encoding UTF8) {
            $key = [string]$line
            if (-not [string]::IsNullOrWhiteSpace($key)) {
                [void]$set.Add($key.Trim())
            }
        }
    }
    return $set
}

function Test-SkippedPath([string]$RemotePath) {
    $normalized = $RemotePath.Replace("\", "/")
    if ($normalized -match "\.crypt\d*($|/)|\.db($|/)|\.tmp($|/)|\.temp($|/)|\.nomedia($|/)|\.part($|/)") {
        return $true
    }
    foreach ($part in $SkippedPathParts) {
        if ($normalized.Contains($part)) {
            return $true
        }
    }
    return $false
}

function Get-MatchingLocalFile([string]$FolderPath, [string]$FileName) {
    $exactPath = Join-Path $FolderPath $FileName
    if (Test-Path -LiteralPath $exactPath) {
        return Get-Item -LiteralPath $exactPath
    }

    $baseName = [System.IO.Path]::GetFileNameWithoutExtension($FileName)
    $matches = Get-ChildItem -LiteralPath $FolderPath -File -ErrorAction SilentlyContinue | Where-Object {
        [System.IO.Path]::GetFileNameWithoutExtension($_.Name) -eq $baseName -and
        $MediaExtensions -contains $_.Extension.ToLowerInvariant()
    } | Sort-Object LastWriteTime -Descending

    return $matches | Select-Object -First 1
}

function Get-SafePathPart([string]$Name) {
    $invalid = [System.IO.Path]::GetInvalidFileNameChars()
    $chars = $Name.ToCharArray() | ForEach-Object {
        if ($invalid -contains $_) { "_" } else { $_ }
    }
    return -join $chars
}

function Get-AndroidMediaItems {
    param(
        [object]$FolderItem,
        [string]$RemotePrefix = ""
    )

    if ($RemotePrefix -and (($RemotePrefix -split "/").Count -le 3)) {
        [Console]::Out.WriteLine("SCANNING: Android $RemotePrefix")
    }

    $result = New-Object System.Collections.Generic.List[object]
    $folder = $FolderItem.GetFolder
    $children = @($folder.Items()) | Sort-Object `
        @{ Expression = { if ($_.IsFolder) { Get-AndroidFolderPriority ([string]$_.Name) } else { 10 } }; Ascending = $true },
        @{ Expression = { [string]$_.Name }; Ascending = $true }

    foreach ($item in $children) {
        $name = [string]$item.Name
        $remotePath = "$RemotePrefix/$name"

        if ($item.IsFolder) {
            if (Test-SkippedPath "$remotePath/") {
                continue
            }
            foreach ($child in Get-AndroidMediaItems -FolderItem $item -RemotePrefix $remotePath) {
                $result.Add($child)
                if ($Limit -gt 0 -and $result.Count -ge $Limit) {
                    return $result
                }
            }
            continue
        }

        if (Test-SkippedPath $remotePath) {
            continue
        }

        $extension = Get-ExtensionFromType $item
        if (-not (Test-MediaExtension $extension)) {
            continue
        }

        $fileName = if ([System.IO.Path]::GetExtension($name)) { $name } else { "$name$extension" }
        $fileRemotePath = "$RemotePrefix/$fileName"
        $sizeText = Get-DetailValue $folder $item 2
        $modifiedText = Get-DetailValue $folder $item 3

        $result.Add([pscustomobject]@{
            FileName = $fileName
            RemotePath = $fileRemotePath
            Size = Convert-SizeToBytes $sizeText
            ModifiedText = $modifiedText
            Item = $item
        })

        if ($Limit -gt 0 -and $result.Count -ge $Limit) {
            return $result
        }
    }

    return $result
}

function Wait-CopiedFile([string]$FolderPath, [string]$FileName, [int64]$ExpectedSize = 0) {
    $deadline = (Get-Date).AddMinutes(30)
    $missingDeadline = (Get-Date).AddSeconds(20)
    $lastSize = -1
    $stableCount = 0
    $lastProgress = (Get-Date).AddSeconds(-1)
    $lastSizeChange = Get-Date

    while ((Get-Date) -lt $deadline) {
        $now = Get-Date
        $file = Get-MatchingLocalFile -FolderPath $FolderPath -FileName $FileName
        if ($null -ne $file) {
            if (($now - $lastProgress).TotalMilliseconds -ge 700) {
                [Console]::Out.WriteLine("FILE_PROGRESS: $($file.Length) $ExpectedSize $($file.FullName)")
                $lastProgress = $now
            }

            if ($ExpectedSize -gt 0 -and $file.Length -lt [int64]($ExpectedSize * 0.9)) {
                if ($file.Length -ne $lastSize) {
                    $lastSizeChange = $now
                } elseif (($now - $lastSizeChange).TotalSeconds -gt 30) {
                    throw "Copied file stopped growing: $FileName"
                }
                $stableCount = 0
                $lastSize = $file.Length
                Start-Sleep -Milliseconds 200
                continue
            }

            if ($file.Length -eq $lastSize -and $file.Length -gt 0) {
                $stableCount += 1
                if ($stableCount -ge 2) {
                    return $file
                }
            } else {
                $stableCount = 0
                $lastSize = $file.Length
                $lastSizeChange = $now
            }
        } elseif ($now -gt $missingDeadline) {
            throw "Copied file did not appear: $FileName"
        }
        Start-Sleep -Milliseconds 200
    }

    throw "Timed out waiting for copied file: $FileName"
}

$context = Get-AndroidStorage
$mediaItems = @(Get-AndroidMediaItems -FolderItem $context.Storage -RemotePrefix "/$($context.Storage.Name)")

if ($Command -eq "list") {
    Write-Output "DEVICE: Android: $($context.Device.Name)"
    Write-Output "PLAN: media=$($mediaItems.Count) bytes=$(($mediaItems | Measure-Object -Property Size -Sum).Sum)"
    foreach ($mediaItem in $mediaItems) {
        Write-Output "$($mediaItem.Size) $($mediaItem.RemotePath)"
    }
    exit 0
}

if ([string]::IsNullOrWhiteSpace($Output)) {
    throw "The download command requires -Output."
}

New-Item -ItemType Directory -Force -Path $Output | Out-Null
$destinationRoot = (Resolve-Path -LiteralPath $Output).Path
$destinationShellFolder = $context.Shell.Namespace($destinationRoot)
if ($null -eq $destinationShellFolder) {
    throw "Could not open staging folder: $destinationRoot"
}

$totalBytes = ($mediaItems | Measure-Object -Property Size -Sum).Sum
if ($null -eq $totalBytes) {
    $totalBytes = 0
}

Write-Output "DEVICE: Android: $($context.Device.Name)"
Write-Output "PLAN: media=$($mediaItems.Count) bytes=$totalBytes"

$downloaded = 0
$skipped = 0
$skippedImported = 0
$failed = 0
$downloadedBytes = 0
$knownImported = Read-SkipManifest $SkipManifest

foreach ($mediaItem in $mediaItems) {
    $relativeFolder = Split-Path -Parent ($mediaItem.RemotePath.TrimStart("/") -replace "/", "\")
    $safeRelativeFolder = ($relativeFolder -split "\\") | ForEach-Object { Get-SafePathPart $_ }
    $folderPath = Join-Path $destinationRoot ($safeRelativeFolder -join "\")
    New-Item -ItemType Directory -Force -Path $folderPath | Out-Null
    $folderShell = $context.Shell.Namespace($folderPath)
    $fileName = [string]$mediaItem.FileName
    $remotePath = [string]$mediaItem.RemotePath
    $expectedSize = [int64]$mediaItem.Size
    $sourceKey = Normalize-SourceKey -RemotePath $remotePath -Size $expectedSize

    if ($knownImported.Contains($sourceKey)) {
        $skippedImported += 1
        Write-Output "SKIPPED_IMPORTED: $expectedSize $remotePath"
        continue
    }

    $existing = Get-MatchingLocalFile -FolderPath $folderPath -FileName $fileName
    if ($null -ne $existing) {
        if ($expectedSize -gt 0 -and $existing.Length -lt [int64]($expectedSize * 0.9)) {
            Write-Output "RETRY_INCOMPLETE: $($existing.Length) $remotePath"
            Remove-Item -LiteralPath $existing.FullName -Force
        } else {
            $skipped += 1
            Write-Output "SKIPPED_EXISTING: $($existing.Length) $remotePath"
            continue
        }
    }

    try {
        Write-Output "STARTED: $expectedSize $remotePath"
        $folderShell.CopyHere($mediaItem.Item, $CopyOptions)
        $copied = Wait-CopiedFile -FolderPath $folderPath -FileName $fileName -ExpectedSize $expectedSize
        $downloaded += 1
        $downloadedBytes += $copied.Length
        Write-Output "DOWNLOADED: $($copied.Length) $remotePath"
    } catch {
        $failed += 1
        Write-Output "ERROR: ${remotePath}: $($_.Exception.Message)"
    }
}

Write-Output "DONE: media=$($mediaItems.Count) downloaded=$downloaded skipped_existing=$skipped skipped_imported=$skippedImported failed=$failed bytes=$downloadedBytes"
if ($failed -gt 0) {
    exit 1
}
