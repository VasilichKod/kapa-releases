#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEFAULT_VENV_PYTHON="$ROOT_DIR/.build/pyinstaller-venv/bin/python"
PYTHON_BIN="${PYTHON_BIN:-}"

if [[ -z "$PYTHON_BIN" && -x "$DEFAULT_VENV_PYTHON" ]]; then
  PYTHON_BIN="$DEFAULT_VENV_PYTHON"
fi

PYTHON_BIN="${PYTHON_BIN:-python3}"
OUTPUT_DIR="$ROOT_DIR/desktop/src-tauri/bundled-bin"
WORK_DIR="$ROOT_DIR/.build/pyinstaller-macos"
ENTRY="$ROOT_DIR/tools/fotosave_backend_entry.py"
SRC_PATH="$ROOT_DIR/src"
BACKEND="$OUTPUT_DIR/fotosave-backend"

if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo "Python не найден: $PYTHON_BIN"
  exit 1
fi

if ! "$PYTHON_BIN" -m PyInstaller --version >/dev/null 2>&1; then
  echo "PyInstaller не найден для $PYTHON_BIN."
  echo "Создайте локальное окружение и установите PyInstaller:"
  echo "  python3 -m venv .build/pyinstaller-venv"
  echo "  .build/pyinstaller-venv/bin/pip install pyinstaller"
  exit 1
fi

mkdir -p "$OUTPUT_DIR" "$WORK_DIR"
rm -rf "$OUTPUT_DIR/fotosave-backend"

"$PYTHON_BIN" -m PyInstaller \
  --clean \
  --noconfirm \
  --onefile \
  --name fotosave-backend \
  --paths "$SRC_PATH" \
  --distpath "$OUTPUT_DIR" \
  --workpath "$WORK_DIR" \
  --specpath "$WORK_DIR" \
  "$ENTRY"

if [[ ! -f "$BACKEND" ]]; then
  echo "Bundled backend не создан: $BACKEND"
  exit 1
fi

chmod 755 "$BACKEND"
echo "Bundled backend written to $BACKEND"
