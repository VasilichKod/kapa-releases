$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
$outputDir = Join-Path $root "desktop\src-tauri\bundled-bin"
$workDir = Join-Path $root ".build\pyinstaller"
$entry = Join-Path $root "tools\fotosave_backend_entry.py"
$srcPath = Join-Path $root "src"
$backendDir = Join-Path $outputDir "fotosave-backend"
$legacyBackend = Join-Path $outputDir "fotosave-backend.exe"

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
  throw "Python is required on the build machine to create the bundled backend."
}

python -m PyInstaller --version | Out-Null

New-Item -ItemType Directory -Force -Path $outputDir | Out-Null
New-Item -ItemType Directory -Force -Path $workDir | Out-Null
if (Test-Path -LiteralPath $backendDir) {
  Remove-Item -LiteralPath $backendDir -Recurse -Force
}
if (Test-Path -LiteralPath $legacyBackend) {
  Remove-Item -LiteralPath $legacyBackend -Force
}

python -m PyInstaller `
  --clean `
  --noconfirm `
  --onedir `
  --name fotosave-backend `
  --paths $srcPath `
  --distpath $outputDir `
  --workpath $workDir `
  --specpath $workDir `
  $entry

$backend = Join-Path $backendDir "fotosave-backend.exe"
if (-not (Test-Path -LiteralPath $backend)) {
  throw "Bundled backend was not created: $backend"
}

Write-Host "Bundled backend written to $backend"
