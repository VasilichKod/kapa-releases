param(
    [Parameter(Mandatory = $true, Position = 0)]
    [ValidateSet("list", "download")]
    [string]$Command,

    [string]$Output,
    [int]$Limit = 0,
    [ValidateSet("all", "photo", "video")]
    [string]$Media = "all",
    [string]$SkipManifest
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new()
$OutputEncoding = [System.Text.UTF8Encoding]::new()

$PhotoExtensions = @(".heic", ".heif", ".jpg", ".jpeg", ".png", ".webp", ".dng", ".tif", ".tiff")
$VideoExtensions = @(".mov", ".mp4", ".m4v")
$MediaExtensions = $PhotoExtensions + $VideoExtensions
$CopyOptions = 1556

function Get-IPhoneStorage {
    $shell = New-Object -ComObject Shell.Application
    $thisPc = $shell.Namespace(17)
    if ($null -eq $thisPc) {
        throw "Could not open This PC through Windows Shell."
    }

    $iphone = $thisPc.Items() | Where-Object { $_.Name -like "*iPhone*" } | Select-Object -First 1
    if ($null -eq $iphone) {
        throw "iPhone not found. Unlock the phone, trust this computer, and check the cable."
    }

    $storage = $iphone.GetFolder.Items() | Where-Object { $_.Name -eq "Internal Storage" } | Select-Object -First 1
    if ($null -eq $storage) {
        throw "iPhone was found, but Internal Storage is not available. Unlock iPhone and allow photo access."
    }

    [pscustomobject]@{
        Shell = $shell
        Device = $iphone
        Storage = $storage
    }
}

function Get-ExtensionFromType([object]$Item) {
    $nameExtension = [System.IO.Path]::GetExtension([string]$Item.Name).ToLowerInvariant()
    if (-not [string]::IsNullOrWhiteSpace($nameExtension)) {
        return $nameExtension
    }

    $type = [string]$Item.Type
    if ($type -match '"([^"]+)"') {
        return "." + $Matches[1].ToLowerInvariant()
    }

    $typeLower = $type.ToLowerInvariant()
    if ($typeLower.Contains("jpeg") -or $typeLower.Contains("jpg")) { return ".jpg" }
    if ($typeLower.Contains("png")) { return ".png" }
    if ($typeLower.Contains("heic")) { return ".heic" }
    if ($typeLower.Contains("heif")) { return ".heif" }
    if ($typeLower.Contains("webp")) { return ".webp" }
    if ($typeLower.Contains("dng")) { return ".dng" }
    if ($typeLower.Contains("tiff")) { return ".tiff" }
    if ($typeLower.Contains("tif")) { return ".tif" }
    if ($typeLower.Contains("mov")) { return ".mov" }
    if ($typeLower.Contains("mp4")) { return ".mp4" }
    if ($typeLower.Contains("m4v")) { return ".m4v" }

    return ""
}

function Get-DetailValue([object]$Folder, [object]$Item, [int]$Index) {
    try {
        return [string]$Folder.GetDetailsOf($Item, $Index)
    } catch {
        return ""
    }
}

function Convert-SizeToBytes([string]$Value) {
    if ([string]::IsNullOrWhiteSpace($Value)) {
        return 0
    }

    $normalized = $Value.Trim().Replace([char]0x00A0, " ")
    if ($normalized -notmatch "([\d\s]+(?:[,.]\d+)?)\s*([^\d\s]+)") {
        return 0
    }

    $number = $Matches[1].Replace(" ", "").Replace(",", ".")
    $unit = $Matches[2].ToUpperInvariant()
    $valueNumber = 0.0
    if (-not [double]::TryParse($number, [System.Globalization.NumberStyles]::Float, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$valueNumber)) {
        return 0
    }

    $multiplier = 1
    $kbRu = [string][char]0x041A + [string][char]0x0411
    $mbRu = [string][char]0x041C + [string][char]0x0411
    $gbRu = [string][char]0x0413 + [string][char]0x0411
    $tbRu = [string][char]0x0422 + [string][char]0x0411

    if ($unit -in @($kbRu, "KB")) { $multiplier = 1KB }
    elseif ($unit -in @($mbRu, "MB")) { $multiplier = 1MB }
    elseif ($unit -in @($gbRu, "GB")) { $multiplier = 1GB }
    elseif ($unit -in @($tbRu, "TB")) { $multiplier = 1TB }

    return [int64]($valueNumber * $multiplier)
}

function Test-MediaExtension([string]$Extension) {
    if ($MediaExtensions -notcontains $Extension) {
        return $false
    }
    if ($Media -eq "photo") {
        return $PhotoExtensions -contains $Extension
    }
    if ($Media -eq "video") {
        return $VideoExtensions -contains $Extension
    }
    return $true
}

function Normalize-SourceKey([string]$RemotePath, [int64]$Size) {
    $normalized = $RemotePath.Replace("\", "/").Trim().TrimEnd("/").ToLowerInvariant()
    if (-not $normalized.StartsWith("/")) {
        $normalized = "/" + $normalized
    }
    return "$normalized|$Size"
}

function Read-SkipManifest([string]$Path) {
    $set = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    if (-not [string]::IsNullOrWhiteSpace($Path) -and (Test-Path -LiteralPath $Path)) {
        foreach ($line in Get-Content -LiteralPath $Path -Encoding UTF8) {
            $key = [string]$line
            if (-not [string]::IsNullOrWhiteSpace($key)) {
                [void]$set.Add($key.Trim())
            }
        }
    }
    return $set
}

function Get-MatchingLocalFile([string]$FolderPath, [string]$FileName) {
    $exactPath = Join-Path $FolderPath $FileName
    if (Test-Path -LiteralPath $exactPath) {
        return Get-Item -LiteralPath $exactPath
    }

    $baseName = [System.IO.Path]::GetFileNameWithoutExtension($FileName)
    $matches = Get-ChildItem -LiteralPath $FolderPath -File -ErrorAction SilentlyContinue | Where-Object {
        [System.IO.Path]::GetFileNameWithoutExtension($_.Name) -eq $baseName -and
        $MediaExtensions -contains $_.Extension.ToLowerInvariant()
    } | Sort-Object LastWriteTime -Descending

    return $matches | Select-Object -First 1
}

function Get-IPhoneMediaItems {
    param([object]$Storage)

    $items = New-Object System.Collections.Generic.List[object]
    $folders = $Storage.GetFolder.Items() | Where-Object { $_.IsFolder } | Sort-Object Name -Descending

    foreach ($folderItem in $folders) {
        $folderName = [string]$folderItem.Name
        [Console]::Out.WriteLine("SCANNING: iPhone /$folderName")
        $folder = $folderItem.GetFolder

        foreach ($item in $folder.Items()) {
            if ($item.IsFolder) {
                continue
            }

            $extension = Get-ExtensionFromType $item
            if (-not (Test-MediaExtension $extension)) {
                continue
            }

            $sizeText = Get-DetailValue $folder $item 2
            $modifiedText = Get-DetailValue $folder $item 3
            $name = [string]$item.Name
            $fileName = if ([System.IO.Path]::GetExtension($name)) { $name } else { "$name$extension" }
            $remotePath = "/$folderName/$fileName"

            $items.Add([pscustomobject]@{
                FolderName = $folderName
                FileName = $fileName
                RemotePath = $remotePath
                Size = Convert-SizeToBytes $sizeText
                ModifiedText = $modifiedText
                Item = $item
            })

            if ($Limit -gt 0 -and $items.Count -ge $Limit) {
                return $items
            }
        }
    }

    return $items
}

function Wait-CopiedFile([string]$FolderPath, [string]$FileName, [int64]$ExpectedSize = 0) {
    $deadline = (Get-Date).AddMinutes(30)
    $lastSize = -1
    $stableCount = 0
    $lastProgress = (Get-Date).AddSeconds(-1)

    while ((Get-Date) -lt $deadline) {
        $file = Get-MatchingLocalFile $FolderPath $FileName
        if ($null -ne $file) {
            $now = Get-Date
            if (($now - $lastProgress).TotalMilliseconds -ge 700) {
                [Console]::Out.WriteLine("FILE_PROGRESS: $($file.Length) $ExpectedSize $($file.FullName)")
                $lastProgress = $now
            }

            if ($ExpectedSize -gt 0 -and $file.Length -lt [int64]($ExpectedSize * 0.9)) {
                $stableCount = 0
                $lastSize = $file.Length
                Start-Sleep -Milliseconds 200
                continue
            }

            if ($file.Length -eq $lastSize -and $file.Length -gt 0) {
                $stableCount += 1
                if ($stableCount -ge 2) {
                    return $file
                }
            } else {
                $stableCount = 0
                $lastSize = $file.Length
            }
        }
        Start-Sleep -Milliseconds 200
    }

    throw "Timed out waiting for copied file: $FileName"
}

$context = Get-IPhoneStorage

if ($Command -eq "list") {
    $mediaItems = @(Get-IPhoneMediaItems -Storage $context.Storage)
    Write-Output "DEVICE: $($context.Device.Name)"
    Write-Output "PLAN: media=$($mediaItems.Count) bytes=$(($mediaItems | Measure-Object -Property Size -Sum).Sum)"
    foreach ($mediaItem in $mediaItems) {
        Write-Output "$($mediaItem.Size) $($mediaItem.RemotePath)"
    }
    exit 0
}

if ([string]::IsNullOrWhiteSpace($Output)) {
    throw "The download command requires -Output."
}

New-Item -ItemType Directory -Force -Path $Output | Out-Null
$destinationRoot = (Resolve-Path -LiteralPath $Output).Path
$destinationShellFolder = $context.Shell.Namespace($destinationRoot)
if ($null -eq $destinationShellFolder) {
    throw "Could not open staging folder: $destinationRoot"
}

Write-Output "DEVICE: $($context.Device.Name)"

$mediaItems = @(Get-IPhoneMediaItems -Storage $context.Storage)
$totalBytes = ($mediaItems | Measure-Object -Property Size -Sum).Sum
if ($null -eq $totalBytes) {
    $totalBytes = 0
}
Write-Output "PLAN: media=$($mediaItems.Count) bytes=$totalBytes"

$seen = 0
$downloaded = 0
$skipped = 0
$skippedImported = 0
$failed = 0
$downloadedBytes = 0
$knownImported = Read-SkipManifest $SkipManifest

function Copy-IPhoneMediaItem([object]$MediaItem) {
    $script:seen += 1

    $folderName = [string]$MediaItem.FolderName
    $fileName = [string]$MediaItem.FileName
    $remotePath = [string]$MediaItem.RemotePath
    $expectedSize = [int64]$MediaItem.Size
    $sourceKey = Normalize-SourceKey -RemotePath $remotePath -Size $expectedSize

    if ($knownImported.Contains($sourceKey)) {
        $script:skippedImported += 1
        Write-Output "SKIPPED_IMPORTED: $expectedSize $remotePath"
        return
    }

    $folderPath = Join-Path $destinationRoot $folderName
    New-Item -ItemType Directory -Force -Path $folderPath | Out-Null
    $folderShell = $context.Shell.Namespace($folderPath)

    $existing = Get-MatchingLocalFile -FolderPath $folderPath -FileName $fileName
    if ($null -ne $existing) {
        if ($expectedSize -gt 0 -and $existing.Length -lt [int64]($expectedSize * 0.9)) {
            Write-Output "RETRY_INCOMPLETE: $($existing.Length) $remotePath"
            Remove-Item -LiteralPath $existing.FullName -Force
        } else {
        $script:skipped += 1
        Write-Output "SKIPPED_EXISTING: $($existing.Length) $remotePath"
        return
        }
    }

    try {
        Write-Output "STARTED: $expectedSize $remotePath"
        $folderShell.CopyHere($MediaItem.Item, $CopyOptions)
        $copied = Wait-CopiedFile -FolderPath $folderPath -FileName $fileName -ExpectedSize $expectedSize
        $script:downloaded += 1
        $script:downloadedBytes += $copied.Length
        Write-Output "DOWNLOADED: $($copied.Length) $remotePath"
    } catch {
        $script:failed += 1
        Write-Output "ERROR: ${remotePath}: $($_.Exception.Message)"
    }
}

try {
    $folders = @($context.Storage.GetFolder.Items() | Where-Object { $_.IsFolder } | Sort-Object Name -Descending)
} catch {
    throw "iPhone stopped responding while opening Internal Storage. Reconnect the phone, unlock it, and start import again."
}

foreach ($folderItem in $folders) {
    $folderName = [string]$folderItem.Name
    Write-Output "SCANNING: iPhone /$folderName"

    try {
        $folder = $folderItem.GetFolder
        $children = @($folder.Items())
    } catch {
        $script:failed += 1
        Write-Output "ERROR: /${folderName}: iPhone stopped responding while opening this folder."
        continue
    }

    foreach ($item in $children) {
        if ($Limit -gt 0 -and $seen -ge $Limit) {
            break
        }

        try {
            if ($item.IsFolder) {
                continue
            }

            $extension = Get-ExtensionFromType $item
            if (-not (Test-MediaExtension $extension)) {
                continue
            }

            $sizeText = Get-DetailValue $folder $item 2
            $name = [string]$item.Name
            $fileName = if ([System.IO.Path]::GetExtension($name)) { $name } else { "$name$extension" }
            $mediaItem = [pscustomobject]@{
                FolderName = $folderName
                FileName = $fileName
                RemotePath = "/$folderName/$fileName"
                Size = Convert-SizeToBytes $sizeText
                Item = $item
            }
            Copy-IPhoneMediaItem $mediaItem
        } catch {
            $script:failed += 1
            Write-Output "ERROR: /${folderName}: $($_.Exception.Message)"
        }
    }

    if ($Limit -gt 0 -and $seen -ge $Limit) {
        break
    }
}

Write-Output "DONE: media=$seen downloaded=$downloaded skipped_existing=$skipped skipped_imported=$skippedImported failed=$failed bytes=$downloadedBytes"
if ($failed -gt 0) {
    exit 1
}
