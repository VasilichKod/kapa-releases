#include <libusb.h>

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>

static int parse_hex16(const char *value, uint16_t *out) {
    char *end = NULL;
    errno = 0;
    unsigned long parsed = strtoul(value, &end, 16);
    if (errno != 0 || end == value || *end != '\0' || parsed > 0xffffUL) {
        return -1;
    }
    *out = (uint16_t)parsed;
    return 0;
}

static void print_config(libusb_device *device, uint8_t index) {
    struct libusb_config_descriptor *config = NULL;
    int rc = libusb_get_config_descriptor(device, index, &config);
    if (rc != LIBUSB_SUCCESS) {
        printf("  config[%u]: error=%s\n", index, libusb_error_name(rc));
        return;
    }

    printf(
        "  config[%u]: value=%u interfaces=%u attributes=0x%02x max_power_ma=%u\n",
        index,
        config->bConfigurationValue,
        config->bNumInterfaces,
        config->bmAttributes,
        config->MaxPower * 2
    );

    for (uint8_t iface_index = 0; iface_index < config->bNumInterfaces; iface_index++) {
        const struct libusb_interface *iface = &config->interface[iface_index];
        for (int alt_index = 0; alt_index < iface->num_altsetting; alt_index++) {
            const struct libusb_interface_descriptor *alt = &iface->altsetting[alt_index];
            printf(
                "    interface=%u alt=%u class=0x%02x subclass=0x%02x protocol=0x%02x endpoints=%u\n",
                alt->bInterfaceNumber,
                alt->bAlternateSetting,
                alt->bInterfaceClass,
                alt->bInterfaceSubClass,
                alt->bInterfaceProtocol,
                alt->bNumEndpoints
            );

            for (uint8_t endpoint_index = 0; endpoint_index < alt->bNumEndpoints; endpoint_index++) {
                const struct libusb_endpoint_descriptor *endpoint = &alt->endpoint[endpoint_index];
                printf(
                    "      endpoint=0x%02x attributes=0x%02x max_packet=%u interval=%u\n",
                    endpoint->bEndpointAddress,
                    endpoint->bmAttributes,
                    endpoint->wMaxPacketSize,
                    endpoint->bInterval
                );
            }
        }
    }

    libusb_free_config_descriptor(config);
}

int main(int argc, char **argv) {
    uint16_t filter_vid = 0;
    uint16_t filter_pid = 0;
    int has_filter = 0;

    if (argc == 3) {
        if (parse_hex16(argv[1], &filter_vid) != 0 || parse_hex16(argv[2], &filter_pid) != 0) {
            fprintf(stderr, "Usage: %s [vid_hex pid_hex]\n", argv[0]);
            return 2;
        }
        has_filter = 1;
    } else if (argc != 1) {
        fprintf(stderr, "Usage: %s [vid_hex pid_hex]\n", argv[0]);
        return 2;
    }

    int rc = libusb_init(NULL);
    if (rc != LIBUSB_SUCCESS) {
        fprintf(stderr, "libusb_init: %s\n", libusb_error_name(rc));
        return 1;
    }

    libusb_device **devices = NULL;
    ssize_t count = libusb_get_device_list(NULL, &devices);
    if (count < 0) {
        fprintf(stderr, "libusb_get_device_list: %s\n", libusb_error_name((int)count));
        libusb_exit(NULL);
        return 1;
    }

    int matches = 0;
    for (ssize_t i = 0; i < count; i++) {
        libusb_device *device = devices[i];
        struct libusb_device_descriptor desc;
        rc = libusb_get_device_descriptor(device, &desc);
        if (rc != LIBUSB_SUCCESS) {
            continue;
        }

        if (has_filter && (desc.idVendor != filter_vid || desc.idProduct != filter_pid)) {
            continue;
        }

        matches++;
        printf(
            "device bus=%u address=%u vid=0x%04x pid=0x%04x class=0x%02x subclass=0x%02x protocol=0x%02x configs=%u\n",
            libusb_get_bus_number(device),
            libusb_get_device_address(device),
            desc.idVendor,
            desc.idProduct,
            desc.bDeviceClass,
            desc.bDeviceSubClass,
            desc.bDeviceProtocol,
            desc.bNumConfigurations
        );

        for (uint8_t config_index = 0; config_index < desc.bNumConfigurations; config_index++) {
            print_config(device, config_index);
        }
    }

    libusb_free_device_list(devices, 1);
    libusb_exit(NULL);

    if (has_filter && matches == 0) {
        printf("No matching devices found for vid=0x%04x pid=0x%04x\n", filter_vid, filter_pid);
        return 3;
    }

    return 0;
}
