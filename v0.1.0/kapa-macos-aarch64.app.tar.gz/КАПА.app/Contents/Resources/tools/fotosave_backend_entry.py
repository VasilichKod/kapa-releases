from __future__ import annotations

import os
import sys

from fotosave.cli import main


os.environ.setdefault("PYTHONUTF8", "1")
os.environ.setdefault("PYTHONIOENCODING", "utf-8:replace")


class SafeTextStream:
    def __init__(self, stream):
        self._stream = stream

    def write(self, value):
        try:
            return self._stream.write(value)
        except (BrokenPipeError, OSError, ValueError):
            return 0

    def flush(self):
        try:
            self._stream.flush()
        except (BrokenPipeError, OSError, ValueError):
            pass

    def __getattr__(self, name):
        return getattr(self._stream, name)


for stream in (sys.stdout, sys.stderr):
    if hasattr(stream, "reconfigure"):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace", line_buffering=True)
        except OSError:
            pass

sys.stdout = SafeTextStream(sys.stdout)
sys.stderr = SafeTextStream(sys.stderr)


if __name__ == "__main__":
    raise SystemExit(main())
