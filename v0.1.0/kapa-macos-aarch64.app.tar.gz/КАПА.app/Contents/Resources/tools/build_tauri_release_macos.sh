#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
KEY_FILE="$ROOT_DIR/desktop/src-tauri/kapa-update.key"
ENV_FILE="$ROOT_DIR/desktop/src-tauri/kapa-update.env"

if [[ ! -f "$KEY_FILE" ]]; then
  echo "Не найден updater-ключ: $KEY_FILE"
  echo "Скопируйте этот же kapa-update.key с Windows в desktop/src-tauri/ на Mac."
  exit 1
fi

if [[ -f "$ENV_FILE" ]]; then
  # Supported local format:
  # TAURI_SIGNING_PRIVATE_KEY_PASSWORD='password'
  # or
  # KAPA_UPDATE_KEY_PASSWORD='password'
  while IFS='=' read -r key value; do
    case "$key" in
      TAURI_SIGNING_PRIVATE_KEY_PASSWORD|KAPA_UPDATE_KEY_PASSWORD)
        value="${value%$'\r'}"
        value="${value#\"}"
        value="${value%\"}"
        value="${value#\'}"
        value="${value%\'}"
        export TAURI_SIGNING_PRIVATE_KEY_PASSWORD="$value"
        ;;
    esac
  done < "$ENV_FILE"
fi

if [[ -z "${TAURI_SIGNING_PRIVATE_KEY_PASSWORD:-}" ]]; then
  echo "Не задан пароль updater-ключа."
  echo "Создайте desktop/src-tauri/kapa-update.env или задайте TAURI_SIGNING_PRIVATE_KEY_PASSWORD."
  exit 1
fi

export TAURI_SIGNING_PRIVATE_KEY="$(cat "$KEY_FILE")"

cd "$ROOT_DIR/desktop"
MACOS_BUNDLES="${KAPA_MACOS_BUNDLES:-app,dmg}"
npm run tauri -- build --bundles "$MACOS_BUNDLES"

MACOS_BUNDLE_DIR="$ROOT_DIR/desktop/src-tauri/target/release/bundle/macos"
DMG_BUNDLE_DIR="$ROOT_DIR/desktop/src-tauri/target/release/bundle/dmg"
UPDATER_ARCHIVE="$(find "$MACOS_BUNDLE_DIR" -maxdepth 1 -name "*.app.tar.gz" -type f | sort | tail -n 1)"
UPDATER_SIGNATURE="$(find "$MACOS_BUNDLE_DIR" -maxdepth 1 -name "*.app.tar.gz.sig" -type f | sort | tail -n 1)"

if [[ -z "$UPDATER_ARCHIVE" || -z "$UPDATER_SIGNATURE" ]]; then
  echo "macOS updater-артефакты не найдены."
  echo "Ожидались файлы в $MACOS_BUNDLE_DIR:"
  echo "  *.app.tar.gz"
  echo "  *.app.tar.gz.sig"
  exit 1
fi

echo
echo "macOS release собран."
echo "Updater archive: $UPDATER_ARCHIVE"
echo "Updater signature: $UPDATER_SIGNATURE"

DMG_FILE="$(find "$DMG_BUNDLE_DIR" -maxdepth 1 -name "*.dmg" -type f 2>/dev/null | sort | tail -n 1 || true)"
if [[ -n "$DMG_FILE" ]]; then
  echo "Installer DMG: $DMG_FILE"
else
  echo "DMG не найден. Для первой установки можно собрать DMG отдельно или задать KAPA_MACOS_BUNDLES=app,dmg."
fi
