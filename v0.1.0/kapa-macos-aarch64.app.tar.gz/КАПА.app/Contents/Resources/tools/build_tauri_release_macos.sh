#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
KEY_FILE="$ROOT_DIR/desktop/src-tauri/kapa-update.key"
ENV_FILE="$ROOT_DIR/desktop/src-tauri/kapa-update.env"

if [[ ! -f "$KEY_FILE" ]]; then
  echo "Не найден updater-ключ: $KEY_FILE"
  echo "Скопируйте этот же kapa-update.key с Windows в desktop/src-tauri/ на Mac."
  exit 1
fi

if [[ -f "$ENV_FILE" ]]; then
  # Supported local format:
  # TAURI_SIGNING_PRIVATE_KEY_PASSWORD='password'
  # or
  # KAPA_UPDATE_KEY_PASSWORD='password'
  while IFS='=' read -r key value; do
    case "$key" in
      TAURI_SIGNING_PRIVATE_KEY_PASSWORD|KAPA_UPDATE_KEY_PASSWORD)
        value="${value%$'\r'}"
        value="${value#\"}"
        value="${value%\"}"
        value="${value#\'}"
        value="${value%\'}"
        export TAURI_SIGNING_PRIVATE_KEY_PASSWORD="$value"
        ;;
    esac
  done < "$ENV_FILE"
fi

if [[ -z "${TAURI_SIGNING_PRIVATE_KEY_PASSWORD:-}" ]]; then
  echo "Не задан пароль updater-ключа."
  echo "Создайте desktop/src-tauri/kapa-update.env или задайте TAURI_SIGNING_PRIVATE_KEY_PASSWORD."
  exit 1
fi

export TAURI_SIGNING_PRIVATE_KEY="$(cat "$KEY_FILE")"

cd "$ROOT_DIR/desktop"
MACOS_BUNDLES="${KAPA_MACOS_BUNDLES:-app,dmg}"
MACOS_BUNDLE_DIR="$ROOT_DIR/desktop/src-tauri/target/release/bundle/macos"
DMG_BUNDLE_DIR="$ROOT_DIR/desktop/src-tauri/target/release/bundle/dmg"
rm -rf "$MACOS_BUNDLE_DIR" "$DMG_BUNDLE_DIR"
npm run tauri -- build --bundles "$MACOS_BUNDLES"

APP_BUNDLE="$(find "$MACOS_BUNDLE_DIR" -maxdepth 1 -name "*.app" -type d | sort | tail -n 1)"

if [[ -z "$APP_BUNDLE" ]]; then
  echo "macOS .app bundle не найден в $MACOS_BUNDLE_DIR."
  exit 1
fi

echo "Переподписываю .app ad-hoc после упаковки ресурсов..."
codesign --force --deep --sign - "$APP_BUNDLE"
codesign --verify --deep --strict --verbose=2 "$APP_BUNDLE"

APP_NAME="$(basename "$APP_BUNDLE")"
UPDATER_ARCHIVE="$MACOS_BUNDLE_DIR/$APP_NAME.tar.gz"
UPDATER_SIGNATURE="$UPDATER_ARCHIVE.sig"
rm -f "$UPDATER_ARCHIVE" "$UPDATER_SIGNATURE"
(cd "$MACOS_BUNDLE_DIR" && tar -czf "$APP_NAME.tar.gz" "$APP_NAME")
npm run tauri -- signer sign "src-tauri/target/release/bundle/macos/$APP_NAME.tar.gz"

if [[ ! -f "$UPDATER_ARCHIVE" || ! -f "$UPDATER_SIGNATURE" ]]; then
  echo "Не удалось создать macOS updater-артефакты:"
  echo "  $UPDATER_ARCHIVE"
  echo "  $UPDATER_SIGNATURE"
  exit 1
fi

DMG_FILE="$(find "$DMG_BUNDLE_DIR" -maxdepth 1 -name "*.dmg" -type f 2>/dev/null | sort | tail -n 1 || true)"
DMG_SCRIPT="$DMG_BUNDLE_DIR/bundle_dmg.sh"
if [[ -n "$DMG_FILE" && -x "$DMG_SCRIPT" ]]; then
  DMG_SOURCE="$(mktemp -d /private/tmp/kapa-release-dmg.XXXXXX)"
  cp -R "$APP_BUNDLE" "$DMG_SOURCE/"
  rm -f "$DMG_FILE"
  "$DMG_SCRIPT" \
    --volname "КАПА" \
    --window-size 520 330 \
    --icon-size 96 \
    --text-size 13 \
    --icon "$APP_NAME" 145 155 \
    --hide-extension "$APP_NAME" \
    --app-drop-link 375 155 \
    "$DMG_FILE" \
    "$DMG_SOURCE"
  hdiutil verify "$DMG_FILE"
fi

echo
echo "macOS release собран."
echo "App bundle: $APP_BUNDLE"
echo "Updater archive: $UPDATER_ARCHIVE"
echo "Updater signature: $UPDATER_SIGNATURE"

if [[ -n "$DMG_FILE" ]]; then
  echo "Installer DMG: $DMG_FILE"
else
  echo "DMG не найден. Для первой установки можно собрать DMG отдельно или задать KAPA_MACOS_BUNDLES=app,dmg."
fi
